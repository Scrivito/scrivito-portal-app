(function(){"use strict";try{if(typeof document<"u"){var t=document.createElement("style");t.appendChild(document.createTextNode(`[data-tooltip]{position:relative;z-index:11111}[data-tooltip]:after{line-height:1;font-size:12px;pointer-events:none;position:absolute;box-sizing:border-box;opacity:0;transition:all ease-in-out .2s}[data-tooltip]:after{content:attr(data-tooltip);text-align:center;min-width:100px;max-width:240px;line-height:1.5;padding:4px 8px;border-radius:8px;background:#272727;color:#fff;z-index:99;font-size:14px;font-style:normal}[data-tooltip]:hover:after{opacity:1}[data-tooltip][data-flow=top]:before{bottom:100%;border-bottom-width:0;border-top-color:#4d4d4d}[data-tooltip][data-flow=top]:after{bottom:calc(100% - 4px)}[tooltip]:not([data-flow]):after,[data-tooltip][data-flow=top]:after{left:50%;transform:translate(-50%,-4px)}[data-tooltip][data-flow=bottom]:after{top:calc(100% - 5px)}[data-tooltip][data-flow=bottom]:after{left:50%;transform:translate(-50%,8px)}[data-tooltip][data-flow=left]:after{top:50%;right:calc(100% + 5px);transform:translate(-8px,-50%)}[data-tooltip][data-flow=right]:after{top:50%;left:calc(100% + 5px);transform:translate(8px,-50%)}[data-tooltip=""]:after{display:none!important}[data-tooltip]:not([data-flow]):after,[data-tooltip][data-flow=topleft]:after{bottom:calc(100% + 5px)}[tooltip]:not([data-flow]):after,[data-tooltip][data-flow=topleft]:after{left:0}.jr-ai-assist-icon-chevron-down{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='32'%20height='32'%20viewBox='0%200%2032%2032'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M10%2013.1035L15.2929%2018.3964C15.6262%2018.7297%2015.7929%2018.8964%2016%2018.8964C16.2071%2018.8964%2016.3738%2018.7297%2016.7071%2018.3964L22%2013.1035'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-min{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='32'%20height='32'%20viewBox='0%200%2032%2032'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M23%2014L18%2014L18%209'%20stroke='%23141B34'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M9%2018L14%2018L14%2023'%20stroke='%23141B34'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M18%2014L25%207'%20stroke='%23141B34'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M7%2025L14%2018'%20stroke='%23141B34'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-max{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='32'%20height='32'%20viewBox='0%200%2032%2032'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M20%207L25%207L25%2012'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M12%2025L7%2025L7%2020'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M25%207L18%2014'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M14%2018L7%2025'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-help{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='20'%20height='20'%20viewBox='0%200%2020%2020'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M9.99643%201.0415C14.944%201.0415%2018.9548%205.05229%2018.9548%209.99984C18.9548%2014.9474%2014.944%2018.9582%209.99643%2018.9582C5.04887%2018.9582%201.03809%2014.9474%201.03809%209.99984C1.03809%205.05229%205.04887%201.0415%209.99643%201.0415ZM9.99643%202.2915C5.73923%202.2915%202.28809%205.74265%202.28809%209.99984C2.28809%2014.257%205.73923%2017.7082%209.99643%2017.7082C14.2536%2017.7082%2017.7048%2014.257%2017.7048%209.99984C17.7048%205.74265%2014.2536%202.2915%209.99643%202.2915ZM10.0038%2013.4178C10.4179%2013.4178%2010.7541%2013.7539%2010.7541%2014.1682C10.7541%2014.5823%2010.4179%2014.9184%2010.0038%2014.9184H9.99643C9.58218%2014.9184%209.24609%2014.5823%209.24609%2014.1682C9.24609%2013.7539%209.58218%2013.4178%209.99643%2013.4178H10.0038ZM9.99643%205.20817C11.4922%205.20817%2012.7048%206.42073%2012.7048%207.9165C12.7048%208.84542%2012.2368%209.66509%2011.5263%2010.152C11.2593%2010.3351%2011.0201%2010.5272%2010.8518%2010.7298C10.6858%2010.9296%2010.6214%2011.0987%2010.6214%2011.2498C10.6214%2011.595%2010.3416%2011.8748%209.99643%2011.8748C9.65126%2011.8748%209.37143%2011.595%209.37143%2011.2498C9.37143%2010.7107%209.61076%2010.2684%209.89059%209.9315C10.168%209.59759%2010.5169%209.32809%2010.8192%209.12092C11.2041%208.85709%2011.4548%208.41584%2011.4548%207.9165C11.4548%207.1111%2010.8018%206.45817%209.99643%206.45817C9.19101%206.45817%208.53809%207.1111%208.53809%207.9165C8.53809%208.26168%208.25826%208.5415%207.91309%208.5415C7.56791%208.5415%207.28809%208.26168%207.28809%207.9165C7.28809%206.42073%208.50068%205.20817%209.99643%205.20817Z'%20fill='black'%20fill-opacity='0.95'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-history{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='20'%20height='20'%20viewBox='0%200%2020%2020'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M11.9552%202.55746C8.35768%201.59746%204.67851%203.31413%203.05101%206.47579L4.24518%206.54829C4.58935%206.56913%204.85185%206.86579%204.83101%207.20996C4.81018%207.55496%204.51351%207.81663%204.16935%207.79579L2.07685%207.66913C1.87851%207.65663%201.69851%207.55079%201.59018%207.38413C1.48268%207.21746%201.46018%207.00913%201.53101%206.82329C3.14351%202.56663%207.77018%200.146625%2012.2777%201.34996C17.0785%202.63246%2019.9368%207.54329%2018.651%2012.3233C17.366%2017.1033%2012.4285%2019.9316%207.62851%2018.65C4.06268%2017.6975%201.57018%2014.745%201.04935%2011.3316C0.996847%2010.99%201.23101%2010.6716%201.57268%2010.6191C1.91351%2010.5675%202.23268%2010.8016%202.28518%2011.1425C2.73351%2014.08%204.87851%2016.6216%207.95101%2017.4425C12.091%2018.5475%2016.3393%2016.1066%2017.4435%2011.9991C18.5477%207.89246%2016.0952%203.66329%2011.9552%202.55746ZM10.6252%206.66663V9.74079L12.1093%2011.225C12.3535%2011.4691%2012.3535%2011.8641%2012.1093%2012.1083C11.8652%2012.3525%2011.4693%2012.3525%2011.2252%2012.1083L9.55851%2010.4416C9.44101%2010.325%209.37518%2010.1658%209.37518%209.99996V6.66663C9.37518%206.32163%209.65518%206.04163%2010.0002%206.04163C10.346%206.04163%2010.6252%206.32163%2010.6252%206.66663Z'%20fill='black'%20fill-opacity='0.95'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-reset{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='20'%20height='20'%20viewBox='0%200%2020%2020'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M10.4828%201.48975C10.7796%201.49054%2011.038%201.4945%2011.2604%201.51429C11.5556%201.54041%2011.8308%201.59741%2012.098%201.73437C12.2044%201.789%2012.3052%201.85154%2012.4004%201.922C12.642%202.10012%2012.8132%202.3202%2012.966%202.57195C13.11%202.80866%2013.2556%203.10712%2013.4276%203.45783L13.8212%204.26058H17.4004C17.7316%204.26058%2018.0004%204.52658%2018.0004%204.85433C18.0004%205.18208%2017.7316%205.44808%2017.4004%205.44808H16.7644L16.3012%2012.8581C16.2396%2013.8461%2016.1908%2014.6298%2016.0908%2015.256C15.9876%2015.8981%2015.8228%2016.4332%2015.4932%2016.9011C15.1916%2017.3286%2014.8036%2017.6904%2014.3532%2017.9612C13.8612%2018.258%2013.3116%2018.3879%2012.6572%2018.4504C12.0196%2018.5106%2011.226%2018.5106%2010.2252%2018.5106H10.1636C9.16199%2018.5106%208.36759%2018.5106%207.72839%2018.4504C7.07399%2018.3879%206.52359%2018.258%206.03159%2017.9604C5.58039%2017.6888%205.19239%2017.327%204.89079%2016.898C4.56119%2016.4293%204.39719%2015.8941%204.29479%2015.2505C4.19559%2014.6235%204.14759%2013.839%204.08679%2012.8494L3.63559%205.44808H3.00039C2.66919%205.44808%202.40039%205.18208%202.40039%204.85433C2.40039%204.52658%202.66919%204.26058%203.00039%204.26058H6.65719L6.99239%203.53304C7.15959%203.16887%207.30199%202.86012%207.44359%202.6147C7.59399%202.35425%207.76439%202.12466%208.00919%201.93941C8.10519%201.86658%208.20759%201.80087%208.31559%201.74466C8.58759%201.60137%208.86839%201.54279%209.17079%201.51508C9.45479%201.48975%209.79799%201.48975%2010.202%201.48975H10.4828ZM15.562%205.44808H4.83799L5.28279%2012.7472C5.34599%2013.774%205.39079%2014.5024%205.48039%2015.0668C5.56839%2015.621%205.69159%2015.9582%205.87559%2016.2203C6.08199%2016.5132%206.34759%2016.761%206.65639%2016.947C6.93079%2017.1125%207.27879%2017.2146%207.84359%2017.2677C8.41799%2017.3223%209.15479%2017.3231%2010.1948%2017.3231C11.2324%2017.3231%2011.9692%2017.3223%2012.5428%2017.2685C13.1068%2017.2146%2013.454%2017.1133%2013.7284%2016.947C14.0372%2016.7618%2014.3028%2016.5148%2014.5092%2016.2219C14.6932%2015.9606%2014.8164%2015.6242%2014.9052%2015.07C14.9956%2014.5063%2015.042%2013.7796%2015.106%2012.7544L15.562%205.44808ZM8.20039%208.21891C8.53159%208.21891%208.80039%208.48491%208.80039%208.81266V13.5627C8.80039%2013.8904%208.53159%2014.1564%208.20039%2014.1564C7.86919%2014.1564%207.60039%2013.8904%207.60039%2013.5627V8.81266C7.60039%208.48491%207.86919%208.21891%208.20039%208.21891ZM12.2004%208.21891C12.5316%208.21891%2012.8004%208.48491%2012.8004%208.81266V13.5627C12.8004%2013.8904%2012.5316%2014.1564%2012.2004%2014.1564C11.8692%2014.1564%2011.6004%2013.8904%2011.6004%2013.5627V8.81266C11.6004%208.48491%2011.8692%208.21891%2012.2004%208.21891ZM10.5596%202.67804H9.92679C9.65079%202.67883%209.44679%202.68279%209.27959%202.69783C9.06679%202.71683%208.95879%202.75087%208.87879%202.79283C8.82999%202.81895%208.78359%202.84825%208.73959%202.8815C8.66759%202.93612%208.59159%203.02004%208.48599%203.20291C8.37479%203.39608%208.25479%203.65495%208.07319%204.04841L7.97559%204.26058H12.4876L12.3588%203.99854C12.1732%203.61854%2012.05%203.36916%2011.9372%203.18312C11.83%203.00658%2011.7548%202.92662%2011.6828%202.87358C11.6396%202.84191%2011.594%202.81341%2011.546%202.78808C11.4668%202.7477%2011.3604%202.71525%2011.1532%202.69704C10.9972%202.68358%2010.81%202.67883%2010.5596%202.67804Z'%20fill='black'%20fill-opacity='0.95'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-dots{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='32'%20height='32'%20viewBox='0%200%2032%2032'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3ccircle%20cx='16'%20cy='16'%20r='1.5'%20fill='%233A3A3A'/%3e%3ccircle%20cx='9.5'%20cy='16'%20r='1.5'%20fill='%233A3A3A'/%3e%3ccircle%20cx='22.5'%20cy='16'%20r='1.5'%20fill='%233A3A3A'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-dots.active{background:#ddd url("data:image/svg+xml,%3csvg%20width='32'%20height='32'%20viewBox='0%200%2032%2032'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3ccircle%20cx='16'%20cy='16'%20r='1.5'%20fill='%233A3A3A'/%3e%3ccircle%20cx='9.5'%20cy='16'%20r='1.5'%20fill='%233A3A3A'/%3e%3ccircle%20cx='22.5'%20cy='16'%20r='1.5'%20fill='%233A3A3A'/%3e%3c/svg%3e") no-repeat center / contain;border-radius:6px}.jr-ai-assist-icon-sticky-on{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='32'%20height='32'%20viewBox='0%200%2032%2032'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M7%2025L12%2020'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M17.2585%2022.8714C13.5152%2022.0215%209.97844%2018.4848%209.12853%2014.7415C8.99399%2014.1489%208.92672%2013.8527%209.12161%2013.372C9.3165%2012.8913%209.55457%2012.7426%2010.0307%2012.4451C11.107%2011.7727%2012.2725%2011.5589%2013.4821%2011.6659C15.1793%2011.816%2016.0279%2011.891%2016.4512%2011.6705C16.8746%2011.4499%2017.1622%2010.9342%2017.7376%209.90269L18.4664%208.59604C18.9465%207.73528%2019.1866%207.3049%2019.7513%207.10202C20.316%206.89913%2020.6558%207.02199%2021.3355%207.26771C22.9249%207.84236%2024.1576%209.07505%2024.7323%2010.6645C24.978%2011.3442%2025.1009%2011.684%2024.898%2012.2487C24.6951%2012.8134%2024.2647%2013.0535%2023.4039%2013.5336L22.0672%2014.2792C21.0376%2014.8534%2020.5229%2015.1406%2020.3024%2015.568C20.0819%2015.9955%2020.162%2016.8256%2020.3221%2018.4859C20.4399%2019.7068%2020.2369%2020.88%2019.5555%2021.9697C19.2577%2022.4458%2019.1088%2022.6839%2018.6283%2022.8786C18.1477%2023.0733%2017.8513%2023.006%2017.2585%2022.8714Z'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-sticky-off{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='32'%20height='32'%20viewBox='0%200%2032%2032'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M11.5%2012C10.9586%2012.1281%2010.4993%2012.1424%209.99268%2012.4589C9.07234%2013.0339%208.85108%2013.7167%209.08821%2014.7612C9.94028%2018.5139%2013.486%2022.0596%2017.2388%2022.9117C18.2834%2023.1489%2018.9661%2022.928%2019.5416%2022.0077C19.8411%2021.5288%2019.8716%2021.0081%2020%2020.5'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M16%2011.7991C16.1776%2011.7779%2016.3182%2011.7403%2016.4295%2011.6823C17.3997%2011.1769%2017.9291%209.53361%2018.4498%208.60009C18.9311%207.73715%2019.1718%207.30567%2019.7379%207.10227C20.3041%206.89888%2020.6448%207.02205%2021.3262%207.26839C22.9197%207.8445%2024.1555%209.08032%2024.7316%2010.6738C24.9779%2011.3552%2025.1011%2011.6959%2024.8977%2012.262C24.6943%2012.8282%2024.2628%2013.0688%2023.3999%2013.5502C22.4608%2014.074%2020.7954%2014.6108%2020.2905%2015.5898C20.2345%2015.6983%2020.1978%2015.8327%2020.1769%2016'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M7%2025L12%2020'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M7%207L25%2025'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-refresh{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='24'%20height='24'%20viewBox='0%200%2024%2024'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M20.0092%202V5.13219C20.0092%205.42605%2019.6418%205.55908%2019.4537%205.33333C17.6226%203.2875%2014.9617%202%2012%202C6.47715%202%202%206.47715%202%2012C2%2017.5228%206.47715%2022%2012%2022C17.5228%2022%2022%2017.5228%2022%2012'%20stroke='%23141B34'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-share{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='20'%20height='20'%20viewBox='0%200%2020%2020'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20fill-rule='evenodd'%20clip-rule='evenodd'%20d='M9.40326%2012.4952C9.40326%2012.8368%209.6866%2013.1202%2010.0283%2013.1202H10.0448C10.3865%2013.1202%2010.6698%2012.8368%2010.6698%2012.4952V3.71181C11.5101%204.57397%2012.5489%205.83969%2012.8034%206.14976C12.8392%206.19335%2012.8595%206.21805%2012.8615%206.2201C13.0782%206.48677%2013.4698%206.52848%2013.7365%206.31181C14.0032%206.09515%2014.0449%205.70349%2013.8283%205.43682C13.8231%205.43068%2013.8115%205.41655%2013.794%205.39523C13.5267%205.06947%2011.8814%203.06483%2010.9116%202.22011C10.6616%202.00344%2010.3698%201.88679%2010.0615%201.87013C9.71151%201.85346%209.38651%201.97844%209.10318%202.22011C8.09731%203.0892%206.38427%205.19388%206.20026%205.41996C6.19371%205.428%206.18911%205.43367%206.18653%205.43682C5.96986%205.70349%206.01157%206.09515%206.27824%206.31181C6.54491%206.52848%206.93656%206.48677%207.15322%206.2201C7.15523%206.2181%207.17536%206.19362%207.21091%206.15039C7.47056%205.83465%208.55293%204.51841%209.40326%203.65347V12.4952ZM7.50358%2018.1201H12.5036L12.4953%2018.1284C14.5619%2018.1284%2015.7036%2018.1284%2016.4953%2017.3367C17.2869%2016.5451%2017.2869%2015.4034%2017.2869%2013.3367V12.5034C17.2869%2011.2369%2017.2869%2010.6034%2016.9953%2010.0201C16.7369%209.51175%2016.3286%209.09508%2015.8119%208.83675C15.2369%208.54508%2014.6037%208.54508%2013.3372%208.54508C12.9955%208.54508%2012.7119%208.82841%2012.7119%209.17008C12.7119%209.51175%2012.9953%209.79508%2013.3369%209.79508C14.3619%209.79508%2014.9369%209.79508%2015.2453%209.95341C15.5286%2010.0951%2015.7453%2010.3201%2015.8869%2010.5951C16.0453%2010.9034%2016.0453%2011.4701%2016.0453%2012.5034V13.3367C16.0453%2015.2534%2016.0286%2016.0451%2015.6203%2016.4534C15.2119%2016.8617%2014.4119%2016.8784%2012.5036%2016.8784H7.50358C5.58691%2016.8784%204.79526%2016.8617%204.38692%2016.4534C3.97859%2016.0451%203.96191%2015.2451%203.96191%2013.3367V12.5034C3.96191%2011.4784%203.96192%2010.9034%204.12026%2010.5951C4.26192%2010.3117%204.48693%2010.0951%204.76193%209.95341C5.07026%209.79508%205.63691%209.79508%206.67025%209.79508C7.01191%209.79508%207.29525%209.51175%207.29525%209.17008C7.29525%208.82841%207.01191%208.54508%206.67025%208.54508C5.40376%208.54508%204.77022%208.54508%204.18693%208.83675C3.6786%209.09508%203.2619%209.50341%203.00356%2010.0201C2.71191%2010.5951%202.71191%2011.2283%202.71191%2012.4948V13.3284C2.71191%2015.3951%202.71193%2016.5367%203.5036%2017.3284C4.29526%2018.1201%205.43691%2018.1201%207.50358%2018.1201Z'%20fill='black'%20fill-opacity='0.95'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-x{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='24'%20height='24'%20viewBox='0%200%2024%2024'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M19.0005%204.99988L5.00049%2018.9999M5.00049%204.99988L19.0005%2018.9999'%20stroke='%23141B34'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-arrow{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='25'%20height='24'%20viewBox='0%200%2025%2024'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M18.3965%209.79297L13.1036%204.50007C12.7703%204.16677%2012.6036%204.00007%2012.3965%204.00007C12.1894%204.00007%2012.0227%204.16677%2011.6894%204.50007L6.39648%209.79297'%20stroke='white'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M12.293%204L12.293%2020'%20stroke='white'%20stroke-width='1.5'%20stroke-linecap='round'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-bubble-grey{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20viewBox='0%200%2030%2030'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M5.70789%2025.6344C4.952%2025.7962%204.3062%2025.0758%204.54933%2024.3421L5.21695%2022.3271C5.31422%2022.0335%205.26681%2021.7133%205.10976%2021.4469C4.12478%2019.7758%203.78892%2017.8537%204.16477%2015.9856C4.57213%2013.9609%205.78784%2012.1374%207.58585%2010.8541C9.38386%209.57082%2011.6418%208.91508%2013.9399%209.00882C16.238%209.10256%2018.4198%209.9394%2020.0797%2011.3637C21.7396%2012.7881%2022.7647%2014.703%2022.9642%2016.7525C23.1638%2018.8019%2022.5243%2020.8465%2021.1646%2022.5059C19.805%2024.1654%2017.8177%2025.3268%2015.5723%2025.7744C13.442%2026.1989%2011.2169%2025.9535%209.27022%2025.0851C9.06584%2024.9939%208.83832%2024.9644%208.61947%2025.0112L5.70789%2025.6344Z'%20fill='%23333333'/%3e%3cpath%20d='M15.5%204C15.5%204.39782%2015.658%204.77936%2015.9393%205.06066C16.2206%205.34196%2016.6022%205.5%2017%205.5C16.6022%205.5%2016.2206%205.65804%2015.9393%205.93934C15.658%206.22064%2015.5%206.60218%2015.5%207C15.5%206.60218%2015.342%206.22064%2015.0607%205.93934C14.7794%205.65804%2014.3978%205.5%2014%205.5C14.3978%205.5%2014.7794%205.34196%2015.0607%205.06066C15.342%204.77936%2015.5%204.39782%2015.5%204Z'%20stroke='%23333333'%20stroke-width='2'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M24%206C24%206.79565%2024.3161%207.55871%2024.8787%208.12132C25.4413%208.68393%2026.2044%209%2027%209C26.2044%209%2025.4413%209.31607%2024.8787%209.87868C24.3161%2010.4413%2024%2011.2044%2024%2012C24%2011.2044%2023.6839%2010.4413%2023.1213%209.87868C22.5587%209.31607%2021.7956%209%2021%209C21.7956%209%2022.5587%208.68393%2023.1213%208.12132C23.6839%207.55871%2024%206.79565%2024%206Z'%20fill='%23333333%20'%20stroke='%23333333'%20stroke-width='2'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e") no-repeat center / contain}@keyframes animation_left{0%,to{opacity:1;transform:translate3d(50%,-50%,0)}50%{opacity:1;transform:translate3d(-150%,-50%,0)}}@keyframes animation_right{0%,to{opacity:1;transform:translate3d(-50%,-50%,0)}50%{opacity:1;transform:translate3d(150%,-50%,0)}}.jr-ai-assist-loader{display:block;width:100%;min-width:30px;min-height:30px;position:relative;top:0;left:0;z-index:998}.jr-ai-assist-loader:before,.jr-ai-assist-loader:after{content:"";display:block;width:8px;height:8px;border-radius:50%;position:absolute;top:50%;opacity:0}.jr-ai-assist-loader:before{background-color:#000c;left:50%;animation:animation_left 2s infinite ease-in-out}.jr-ai-assist-loader:after{background-color:#969696cc;right:50%;animation:animation_right 2s infinite ease-in-out}.jr-ai-assist-modal-wrapper{position:relative;inset:0}.jr-ai-assist-modal-backdrop{position:fixed;height:100%;width:100%;background:#00000080;top:0;left:0;opacity:0;z-index:-1;transition:all ease-in-out .5s}.jr-ai-assist-modal-wrapper.jr-ai-assist-overlay .jr-ai-assist-modal-backdrop{z-index:1;opacity:1}.jr-ai-assist-modal{--jr-ai-assist-bg-color-bubble-me: #eaeaea;--jr-ai-assist-text-color-bubble-me: #4a2205;--bg-color-button: #fff;--text-color-button: #141414;--bg-color-bubble-error: #d03131;--text-color-bubble-error: #fff;--focus-input-color: #888}.jr-ai-assist-modal{font-family:Inter,sans-serif;font-weight:400;font-size:16px;border:1px solid rgba(0,0,0,.2);display:flex;flex-direction:column;color:#333;visibility:visible;box-shadow:0 0 55px #00000026;background:#fff;outline:0;transition:all .5s ease-in-out;transition-behavior:allow-discrete;width:500px;height:calc(100% - 30px);border-radius:24px;position:fixed!important;z-index:11112;position:fixed;bottom:0;right:0;transform:translateY(110%);opacity:0}.jr-ai-assist-modal-wrapper.jr-ai-assist-floating .jr-ai-assist-modal{height:calc(100% - 30px);width:500px;transform:translateY(-15px);margin:auto 15px;opacity:1}.jr-ai-assist-floating .btn-chat-min{display:none!important}.jr-ai-assist-modal-wrapper.jr-ai-assist-docked .jr-ai-assist-modal{height:100%;width:500px;transform:translateY(0);opacity:1;border-radius:0;border-width:0 0 0 1px;box-shadow:none}.jr-ai-assist-docked .btn-chat-docked{display:none!important}.jr-ai-assist-modal-wrapper.jr-ai-assist-overlay .jr-ai-assist-modal{width:min(80%,1400px);height:calc(90% - 30px);border-radius:24px 24px 0 0;font-size:20px;margin:auto auto 0;right:50%;transform:translate(50%);opacity:1}.jr-ai-assist-overlay .btn-chat-max{display:none!important}.jr-ai-assist-overlay button,.jr-ai-assist-overlay .form-group .textarea{font-size:20px!important}.jr-ai-assist-modal-wrapper.jr-ai-assist-inline{width:100%;height:auto;overflow:visible}.jr-ai-assist-modal-wrapper.jr-ai-assist-inline .jr-ai-assist-modal{position:relative!important;width:100%;height:auto;bottom:auto;right:auto;transform:none;opacity:1;border-radius:0;box-shadow:none;border:none;display:block}.jr-ai-assist-modal-wrapper.jr-ai-assist-inline .jr-ai-assist-modal-header{display:none}.jr-ai-assist-modal-wrapper.jr-ai-assist-inline .jr-ai-assist-modal-footer{border-radius:0}.jr-ai-assist-modal-wrapper.jr-ai-assist-inline .jr-ai-assist-modal-backdrop{display:none}.jr-ai-assist-modal-header{color:#333!important;display:flex;align-items:center;justify-content:space-between;padding:16px 16px 10px;z-index:11111}.jr-ai-assist-modal-header button{background:transparent!important;margin:0!important;border:none!important;box-shadow:none!important}.jr-ai-assist-modal-header .jr-ai-assist-modal-title{display:flex;align-items:center;justify-content:space-between;width:100%;gap:8px;position:relative}.jr-ai-assist-modal-header .headline-5{font-size:20px;font-weight:500;flex:1}.jr-ai-assist-modal-header button{border:none;background:transparent;padding:0!important}.jr-ai-assist-modal-header button i{color:#555;margin:auto;opacity:.7;cursor:pointer;transition:all .2s ease-in-out}.jr-ai-assist-modal-header button:hover i{opacity:1;transform:scale(1.1)}.jr-ai-assist-modal-body{display:flex;flex-grow:1;padding:5px 16px;overflow-y:auto;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;overflow-scrolling:touch;background-image:linear-gradient(to top,#fff,#fff),linear-gradient(to top,#fff,#fff),linear-gradient(to top,#00000040,#74747400),linear-gradient(to bottom,#00000040,#74747400);background-position:bottom center,top center,bottom center,top center;background-color:#fff;background-repeat:no-repeat;background-size:100% 2px,100% 2px,100% 2px,100% 2px;background-attachment:local,local,scroll,scroll}.jr-ai-assist-modal-footer{border-radius:0 0 24px 24px;display:flex;align-items:center;justify-content:space-between;padding:10px 16px;flex-direction:column}.jr-ai-assist-disclaimer{font-size:12px;line-height:150%;margin:10px 0 0;color:#000000b3;text-align:center;max-width:70%}.jr-ai-assist-disclaimer a{color:#141414}.jr-ai-assist-modal button{line-height:1.4;display:inline-flex;border-radius:8px;padding:8px 16px;background:var(--bg-color-button);border:1px solid rgba(0,0,0,.2);box-shadow:0 0 6px #0000000d;color:var(--text-color-button)!important;font-size:16px;font-weight:600;cursor:pointer;transition:all .2s ease-in-out;width:fit-content}.jr-ai-assist-modal button:hover{background:var(--bg-color-button);transform:scale(1.02)}.jr-ai-assist-overlay.jr-ai-assist-modal button{font-size:20px}.jr-ai-assist-modal .form-group{position:relative;z-index:1111;display:flex;flex-wrap:wrap;align-items:stretch;background:#fff;width:100%;border-radius:22px;padding:5px 0;box-shadow:0 4px 8px #1111110d;border:1px solid rgba(0,0,0,.2);transition:all .4s ease-in-out}.jr-ai-assist-modal .form-group:focus-within{box-shadow:0 0 0 2px var(--focus-input-color) inset}.jr-ai-assist-modal .form-group .textarea{font-family:Inter,sans-serif;font-weight:400;color:#141414;font-size:16px;line-height:1.6;position:relative;flex:1 1 auto;width:1%;min-width:0;border:none;padding:0 8px 0 14px;margin:auto 0;min-height:24px;max-height:75px;background:transparent;overflow-x:hidden;overflow-y:auto;resize:none;overflow-wrap:break-word}.jr-ai-assist-modal .form-group .textarea:focus-visible{outline:none}.jr-ai-assist-modal .form-group .textarea[contenteditable]:empty:before{content:var(--placeholder-text);color:gray}.jr-ai-assist-modal .form-group textarea:focus{box-shadow:none;outline:none}.jr-ai-assist-modal .form-group button{position:relative;z-index:2;border:none;box-shadow:none;background:transparent;display:flex;cursor:pointer;border-radius:50%;padding:4px;height:32px;width:32px}.jr-ai-assist-modal .form-group button i{color:#141414;height:24px;width:24px;margin:auto;transition:all .2s ease-in-out}.jr-ai-assist-modal .form-group button:hover i{opacity:1;transform:scale(1.1);transform-origin:center}.jr-ai-assist-modal .form-group .form-group-add{display:flex;flex-flow:column-reverse;position:relative;padding-right:6px}.jr-ai-assist-modal .form-group button:has(i.jr-ai-assist-icon-arrow){background:#000;border-radius:50%;padding:4px;height:32px;width:32px;opacity:1}.jr-ai-assist-modal button:disabled,.jr-ai-assist-overlay button:disabled,.jr-ai-assist-chat-form .form-group button:disabled{cursor:not-allowed;opacity:.4!important;transition:all ease-in-out .2s}.jr-ai-assist-modal .form-group:has(.textarea:not([contenteditable])){background:#eee;opacity:.8}.jr-ai-assist-overlay .form-group{padding:7px 0;border-radius:28px}.jr-ai-assist-overlay .form-group .form-group-add{padding-right:8px}.jr-ai-assist-overlay .form-group button{width:40px!important;height:40px!important}.jr-ai-assist-overlay .form-group .textarea{padding:0 12px 0 20px;min-height:30px}.jr-ai-assist-dropdown-menu{min-width:200px;max-width:300px;padding:3px;margin:0;font-size:14px;border-radius:10px;color:#333;background:#fffc;background-clip:border-box;backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border:1px solid rgba(0,0,0,.2);box-shadow:0 0 55px #00000026,0 8px 9px -5px #1414140f;position:absolute;right:0;overflow:hidden;transition:all .1s ease-out;height:auto;transform-origin:top;top:100%;transform:scaleY(0);opacity:0;z-index:1000}.jr-ai-assist-dropdown-menu.show{transform:scaleY(1);opacity:1}.form-group .jr-ai-assist-dropdown-menu{transform-origin:bottom;top:auto;bottom:100%}.jr-ai-assist-dropdown-item{cursor:pointer;display:flex;padding:0;font-weight:500;color:#333;border-radius:8px!important;white-space:nowrap;width:100%!important;opacity:1!important;padding:0!important;background:transparent!important;height:auto!important}.jr-ai-assist-dropdown-item:hover{color:#111;background:#ddd!important;text-shadow:0 0 1px #fff}.jr-ai-assist-dropdown-item i{display:flex;flex-flow:column;flex:0;font-size:19px;min-width:25px;padding:0 0 0 10px;margin:auto 0!important;opacity:.7!important}.jr-ai-assist-dropdown-item span{color:#555;flex:1;min-width:min-content;text-wrap:balance;padding:8px 5px 8px 2px;font-size:16px;margin:auto;line-height:1.5em;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-box-orient:vertical;line-clamp:3;-webkit-line-clamp:2;text-align:left}.jr-ai-assist-dropdown-item:hover i,.jr-ai-assist-dropdown-item:hover span{color:#111;opacity:1!important}.jr-ai-assist-list-bubble{list-style:none;padding:0;width:100%;display:flex;flex-flow:column;gap:5px;text-align:center;margin:0 auto;max-width:700px}.jr-ai-assist-list-bubble>li{display:flex;flex-flow:row-reverse;margin:0 0 0 auto;padding:0;text-align:left;width:max-content;max-width:80%;min-width:150px}@media(max-width:600px){.jr-ai-assist-list-bubble>li{max-width:95%}}.jr-ai-assist-list-bubble .arrow-box{color:var(--jr-ai-assist-text-color-bubble-me, #222);gap:10px;position:relative;display:flex;flex-direction:column;flex:max-content;min-width:0;background:var(--jr-ai-assist-bg-color-bubble-me, #eee);border-radius:10px;padding:12px 20px;margin:0 0 10px;line-height:1.6;word-break:break-word}.jr-ai-assist-list-bubble .arrow-box pre,.jr-ai-assist-list-bubble .arrow-box code{text-wrap:auto;font-size:15px}.jr-ai-assist-list-bubble li .arrow-box-header{color:var(--jr-ai-assist-text-color-bubble-me, #222);opacity:.8;display:flex;margin:-6px 0}.jr-ai-assist-list-bubble li.ai .arrow-box-header{color:var(--text-color-bubble-ai)}.jr-ai-assist-list-bubble .arrow-box-header .user{flex-grow:1;opacity:.7;font-size:12px;font-weight:700;display:flex;margin:0 auto}.jr-ai-assist-list-bubble .arrow-box-header .action i{flex-grow:0;display:flex;margin:0 auto;opacity:.7;cursor:pointer;width:20px;height:20px;transition:all .2s ease-in-out}.jr-ai-assist-list-bubble .arrow-box-header .action:hover i{opacity:1;transform:scale(1.1)}.jr-ai-assist-list-bubble .arrow-box strong{font-weight:600}.jr-ai-assist-list-bubble .arrow-box p{line-height:1.6;margin:0;gap:15px}.jr-ai-assist-list-bubble .arrow-box ul{padding-left:25px}.jr-ai-assist-list-bubble .arrow-box ul:has(button){list-style-type:none;gap:5px;display:flex;flex-direction:column}.jr-ai-assist-list-bubble .arrow-box p .btn,.jr-ai-assist-list-bubble .arrow-box p button{margin-bottom:10px}.jr-ai-assist-list-bubble .arrow-box p .btn:last-child,.jr-ai-assist-list-bubble .arrow-box p button:last-child{margin-bottom:5px}.jr-ai-assist-list-bubble li.ai{flex-flow:row;margin:0 auto 0 0;max-width:100%}.jr-ai-assist-list-bubble li.ai .arrow-box{margin:0 0 10px;padding:0 4px;background:var(--bg-color-bubble-ai);border:none;box-shadow:none}.jr-ai-assist-list-bubble li.ai .arrow-box,.jr-ai-assist-list-bubble li.ai .arrow-box p,.jr-ai-assist-list-bubble li.ai .arrow-box *{color:var(--text-color-bubble-ai)}.jr-ai-assist-list-bubble li.error .arrow-box{background:var(--bg-color-bubble-error);color:#fff}.jr-ai-assist-list-bubble li.error .arrow-box,.jr-ai-assist-list-bubble li.error .arrow-box p,.jr-ai-assist-list-bubble li.error .arrow-box *{color:var(--text-color-bubble-error)}.jr-ai-assist-list-bubble .arrow-box a{text-decoration:underline}.jr-ai-assist-list-bubble .arrow-box table{display:block;max-width:100%;overflow-x:auto;border-collapse:collapse}.jr-ai-assist-list-bubble .arrow-box th,.jr-ai-assist-list-bubble .arrow-box td{border:1px solid currentcolor;padding:4px 8px;word-break:normal;overflow-wrap:normal;-webkit-hyphens:none;hyphens:none}@media(min-width:1000px){.jr-ai-assist-overlay .jr-ai-assist-modal-body .jr-ai-assist-list-bubble,.jr-ai-assist-overlay .jr-ai-assist-modal-footer .form-group{max-width:700px;margin:0 auto}}@media(max-width:1100px){.jr-ai-assist-modal-wrapper.jr-ai-assist-overlay .jr-ai-assist-modal{width:90%;height:90%}}@media(max-width:576px){.jr-ai-assist-modal-wrapper.jr-ai-assist-overlay .jr-ai-assist-modal,.jr-ai-assist-modal-wrapper.jr-ai-assist-floating .jr-ai-assist-modal{width:calc(100% - 30px)}.jr-ai-assist-modal-wrapper.jr-ai-assist-docked .jr-ai-assist-modal{width:100%}.jr-ai-assist-modal-wrapper.jr-ai-assist-overlay .jr-ai-assist-modal{width:95%;height:98%;margin:auto;border-radius:20px 20px 0 0;font-size:16px}.jr-ai-assist-modal-wrapper.jr-ai-assist-overlay button,.jr-ai-assist-modal-wrapper.jr-ai-assist-overlay .form-group .textarea{font-size:16px!important}.jr-ai-assist-overlay .form-group{padding:5px 0;border-radius:22px}.jr-ai-assist-overlay .form-group .form-group-add{padding-right:6px}.jr-ai-assist-overlay .form-group button{width:32px!important;height:32px!important}.jr-ai-assist-overlay .form-group .textarea{padding:0 8px 0 14px;min-height:24px}}`)),document.head.appendChild(t)}}catch(i){console.error("vite-plugin-css-injected-by-js",i)}})();
import { load as Ae, Binary as wa, ClientError as ya, performWithIamToken as ba, getInstanceId as _a, provideDataClass as ka, currentLanguage as Qr, connect as it, LinkTag as xa, currentUser as Ca } from "scrivito";
import { z as R } from "zod";
import { jsx as C, Fragment as et, jsxs as J } from "react/jsx-runtime";
import { useState as ve, useRef as Re, useEffect as we, createContext as Sa, useContext as Gr, useCallback as xe, useMemo as va } from "react";
import Aa from "react-markdown";
function dh(n) {
  return n;
}
function Ra(n) {
  const e = /* @__PURE__ */ new Map();
  for (const t of n ?? [])
    t.render && e.set(t.type, t.render);
  return e;
}
const yt = 100;
async function Ia(n) {
  const { systemData: e, customData: t } = n.getExternalData();
  return {
    _id: e._id,
    // TODO abstract, don't hardcode for activity
    _summary: `${t.activityType}: ${t.subject}`
  };
}
async function $t(n) {
  const e = n.getExternalData();
  return {
    _id: e.systemData._id,
    // _url: await load(() => urlForDataItem(item)),
    ...e.customData
  };
}
function $a(n) {
  const e = n.map((r) => r.name()).filter((r) => r !== null);
  return [
    me({
      name: "list",
      description: `Get a list of data for the given data class. Returns at most ${yt} items per call. If the user asks for "all" items, inform them that you can only show a limited number at a time.`,
      parameters: R.object({
        dataClass: R.enum(e).describe("The kind of data to fetch."),
        limit: R.number().describe(`how many items to fetch (default: 10, max: ${yt})`).optional(),
        filter: R.object({
          attribute: R.string().describe("the attribute which must have the given value"),
          value: R.union([R.string(), R.boolean()]).describe("the value that the attribute must have")
        }).optional(),
        order: R.object({
          attribute: R.string().describe("the attribute to sort on"),
          direction: R.enum(["asc", "desc"])
        }).optional(),
        search: R.string().describe("search for keywords in the full text.").optional()
      }),
      run: async (r) => {
        const s = t(r.dataClass), i = r.order, a = r.filter, o = s.all().transform({
          filters: a && { [a.attribute]: a.value },
          order: i && [[i.attribute, i.direction]],
          limit: r.limit ? Math.min(r.limit, yt) : 10,
          search: r.search
        }), l = await Ae(() => o.take()), c = await Promise.all(l.map($t));
        return console.log(c), c;
      }
    }),
    me({
      name: "count",
      description: "Count items of the given data class, optionally filtered or searched.",
      parameters: R.object({
        dataClass: R.enum(e).describe("The kind of data to count."),
        filter: R.object({
          attribute: R.string().describe("the attribute which must have the given value"),
          value: R.union([R.string(), R.boolean()]).describe("the value that the attribute must have")
        }).optional(),
        search: R.string().describe("search for keywords in the full text.").optional()
      }),
      run: async ({ dataClass: r, filter: s, search: i }) => {
        const o = t(r).all().transform({
          filters: s && { [s.attribute]: s.value },
          search: i
        }), l = await Ae(() => o.count());
        return l === null ? `The data backend for '${r}' does not support counting.` : { count: l };
      }
    }),
    me({
      name: "create",
      description: "Create a new item of the given data class.",
      parameters: R.object({
        dataClass: R.enum(e).describe("The data class to create an item for."),
        data: R.array(
          R.object({
            attribute: R.string().describe("the name of the attribute"),
            value: R.string().describe("the value to set for the attribute")
          })
        ).describe(
          "an list of attribute values that should be set for the new item."
        )
      }),
      run: async (r) => {
        const s = t(r.dataClass), i = Object.fromEntries(
          r.data.map(({ attribute: o, value: l }) => [o, l])
        ), a = await s.create(i);
        return $t(a);
      }
    })
  ];
  function t(r) {
    const s = n.find((i) => i.name() === r);
    if (!s)
      throw new Error(`unknown data class ${r}`);
    return s;
  }
}
function Ea(n) {
  const e = n.map((r) => r.name()).filter((r) => r !== null);
  return [
    me({
      name: "get",
      description: "Get the details of a specific data item",
      parameters: R.object({
        dataClass: R.enum(e).describe("The kind of data to fetch."),
        ids: R.array(R.string()).describe("a list of ids for the items to get.")
      }),
      run: async (r) => {
        const s = t(r.dataClass), { ids: i } = r, a = await Promise.all(
          i.map((l) => Ae(() => s.get(l)))
        ), o = await Promise.all(
          a.filter((l) => !!l).map($t)
        );
        return console.log(o), o;
      }
    }),
    me({
      name: "find",
      description: `
        Find data for the given data class.
        The results contain a summary for each item.
        In order to get the details of a specific item, use the 'get' tool.
      `,
      parameters: R.object({
        dataClass: R.enum(e).describe("The kind of data to fetch."),
        filter: R.object({
          attribute: R.string().describe("the attribute which must have the given value"),
          value: R.union([R.string(), R.boolean()]).describe("the value that the attribute must have")
        }).optional(),
        order: R.object({
          attribute: R.string().describe("the attribute to sort on"),
          direction: R.enum(["asc", "desc"])
        }).optional(),
        search: R.string().describe("search for keywords in the full text.").optional()
      }),
      run: async (r) => {
        const s = t(r.dataClass), i = r.order, a = r.filter, o = s.all().transform({
          filters: a && { [a.attribute]: a.value },
          order: i && [[i.attribute, i.direction]],
          limit: yt,
          search: r.search
        }), l = await Ae(() => o.take()), c = await Promise.all(l.map(Ia));
        return console.log(c), c;
      }
    }),
    me({
      name: "create",
      description: "Create a new item of the given data class.",
      parameters: R.object({
        dataClass: R.enum(e).describe("The data class to create an item for."),
        data: R.array(
          R.object({
            attribute: R.string().describe("the name of the attribute"),
            value: R.string().describe("the value to set for the attribute")
          })
        ).describe(
          "an list of attribute values that should be set for the new item."
        )
      }),
      run: async (r) => {
        const s = t(r.dataClass), i = Object.fromEntries(
          r.data.map(({ attribute: o, value: l }) => [o, l])
        ), a = await s.create(i);
        return $t(a);
      }
    })
  ];
  function t(r) {
    const s = n.find((i) => i.name() === r);
    if (!s)
      throw new Error(`unknown data class ${r}`);
    return s;
  }
}
async function Pa(n) {
  const e = n._widget_pool ?? {};
  return await Yr(e, n);
}
async function Yr(n, e) {
  const t = (await Promise.all(
    Object.entries(e).map(async ([r, s]) => {
      if (r.startsWith("_") || !Array.isArray(s)) return;
      const [i, a] = s;
      switch (i) {
        case "binary":
          return Ae(
            () => (
              // eslint-disable-next-line @typescript-eslint/ban-ts-comment
              // @ts-ignore private API
              new wa(a.id).raw().metadata().get("text")
            )
          );
        case "html":
        case "string": {
          const o = String(a);
          return o.length < 4 ? void 0 : o;
        }
        case "widgetlist":
          return Array.isArray(a) ? (await Promise.all(
            a.map(async (o) => {
              if (typeof o != "string")
                throw Error("Expected widget ID to be a string");
              return Ta(n, o);
            })
          )).join(`
`) : void 0;
      }
    })
  )).filter(Boolean);
  return t.length === 0 ? "" : t.length === 1 ? t[0] : t.join(`
`);
}
async function Ta(n, e) {
  const t = n[e];
  return t === null || typeof t != "object" ? "" : Yr(n, t);
}
async function Oa(n) {
  return (await Promise.all(
    n.map(async (t) => {
      const r = Ma(
        await Ae(() => t.attributeDefinitions())
      );
      return `Data class ${t.name()} with the attributes:
      ${JSON.stringify(r)}

      `;
    })
  )).join(`
`);
}
function Ma(n) {
  const e = {};
  for (const [t, [r, s]] of Object.entries(n))
    if (s?.values) {
      const { _values: i, ...a } = s;
      e[t] = [r, a];
    } else
      e[t] = [r, s];
  return e;
}
function Da(n) {
  return me({
    name: "site-search",
    description: "Search various corporate websites for information. ",
    parameters: R.object({
      site: R.enum(Object.keys(n)),
      searchTerm: R.string().describe("The search term should be in english."),
      alternativeSearchTerms: R.array(R.string())
    }),
    run: async ({ searchTerm: e, site: t }) => {
      const r = n[t];
      if (!r)
        throw new Error(`Invalid website ${t}`);
      const s = r.instanceId, i = await fetch(
        `https://beta-api.scrivito.com/tenants/${s}/perform`,
        {
          method: "PUT",
          headers: { "content-type": "application/json; charset=utf-8" },
          body: JSON.stringify({
            path: "workspaces/published/objs/search",
            verb: "GET",
            params: {
              query: [
                {
                  field: "_site_id",
                  operator: "equals",
                  value: [r.siteId]
                },
                { field: "*", operator: "matches", value: [e] }
              ],
              options: { site_aware: !0 },
              size: 10,
              include_objs: !0
            }
          }),
          mode: "cors",
          credentials: "omit"
        }
      ), { objs: a } = await i.json(), o = await Promise.all(
        a.map(async (l) => {
          const { _id: c, ...h } = l;
          return {
            _url: `${r.baseUrl}/${c}`,
            text: await Pa({ ...h })
          };
        })
      );
      return console.log("pages", o), o;
    }
  });
}
function me({
  name: n,
  run: e,
  parameters: t,
  description: r,
  explanation: s
}) {
  return {
    name: n,
    description: r,
    explanation: (i) => {
      try {
        const a = t.parse(JSON.parse(i || "{}"));
        return s?.(a);
      } catch {
        return;
      }
    },
    parameters: La(t),
    function: async (i) => {
      console.log(`[model performs '${n}' with ${i}]`);
      try {
        const a = t.parse(JSON.parse(i || "{}")), o = await e(a);
        return typeof o == "string" ? o : JSON.stringify(o);
      } catch (a) {
        if (!(a instanceof ya)) {
          const l = `Error: ${a}`;
          return console.log("some error", a), l;
        }
        const o = `Error: ${a.message}, ${a.code}, ${JSON.stringify(a.details)}`;
        return console.log("client error", o), o;
      }
    }
  };
}
function La(n) {
  return R.toJSONSchema(n);
}
function Fa(n, e) {
  return n === "v1" ? $a(e) : Ea(e);
}
function I(n, e, t, r, s) {
  if (typeof e == "function" ? n !== e || !0 : !e.has(n))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return e.set(n, t), t;
}
function d(n, e, t, r) {
  if (t === "a" && !r)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof e == "function" ? n !== e || !r : !e.has(n))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return t === "m" ? r : t === "a" ? r.call(n) : r ? r.value : e.get(n);
}
let Zr = function() {
  const { crypto: n } = globalThis;
  if (n?.randomUUID)
    return Zr = n.randomUUID.bind(n), n.randomUUID();
  const e = new Uint8Array(1), t = n ? () => n.getRandomValues(e)[0] : () => Math.random() * 255 & 255;
  return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, (r) => (+r ^ t() & 15 >> +r / 4).toString(16));
};
function wn(n) {
  return typeof n == "object" && n !== null && // Spec-compliant fetch implementations
  ("name" in n && n.name === "AbortError" || // Expo fetch
  "message" in n && String(n.message).includes("FetchRequestCanceledException"));
}
const yn = (n) => {
  if (n instanceof Error)
    return n;
  if (typeof n == "object" && n !== null) {
    try {
      if (Object.prototype.toString.call(n) === "[object Error]") {
        const e = new Error(n.message, n.cause ? { cause: n.cause } : {});
        return n.stack && (e.stack = n.stack), n.cause && !e.cause && (e.cause = n.cause), n.name && (e.name = n.name), e;
      }
    } catch {
    }
    try {
      return new Error(JSON.stringify(n));
    } catch {
    }
  }
  return new Error(n);
};
class v extends Error {
}
class z extends v {
  constructor(e, t, r, s) {
    super(`${z.makeMessage(e, t, r)}`), this.status = e, this.headers = s, this.requestID = s?.get("x-request-id"), this.error = t;
    const i = t;
    this.code = i?.code, this.param = i?.param, this.type = i?.type;
  }
  static makeMessage(e, t, r) {
    const s = t?.message ? typeof t.message == "string" ? t.message : JSON.stringify(t.message) : t ? JSON.stringify(t) : r;
    return e && s ? `${e} ${s}` : e ? `${e} status code (no body)` : s || "(no status code or body)";
  }
  static generate(e, t, r, s) {
    if (!e || !s)
      return new Ut({ message: r, cause: yn(t) });
    const i = t?.error;
    return e === 400 ? new es(e, i, r, s) : e === 401 ? new ts(e, i, r, s) : e === 403 ? new ns(e, i, r, s) : e === 404 ? new rs(e, i, r, s) : e === 409 ? new ss(e, i, r, s) : e === 422 ? new is(e, i, r, s) : e === 429 ? new as(e, i, r, s) : e >= 500 ? new os(e, i, r, s) : new z(e, i, r, s);
  }
}
class Y extends z {
  constructor({ message: e } = {}) {
    super(void 0, void 0, e || "Request was aborted.", void 0);
  }
}
class Ut extends z {
  constructor({ message: e, cause: t }) {
    super(void 0, void 0, e || "Connection error.", void 0), t && (this.cause = t);
  }
}
class Mn extends Ut {
  constructor({ message: e } = {}) {
    super({ message: e ?? "Request timed out." });
  }
}
class es extends z {
}
class ts extends z {
}
class ns extends z {
}
class rs extends z {
}
class ss extends z {
}
class is extends z {
}
class as extends z {
}
class os extends z {
}
class ls extends v {
  constructor() {
    super("Could not parse response content as the length limit was reached");
  }
}
class cs extends v {
  constructor() {
    super("Could not parse response content as the request was rejected by the content filter");
  }
}
class We extends Error {
  constructor(e) {
    super(e);
  }
}
const Na = /^[a-z][a-z0-9+.-]*:/i, ja = (n) => Na.test(n);
let K = (n) => (K = Array.isArray, K(n)), ur = K;
function us(n) {
  return typeof n != "object" ? {} : n ?? {};
}
function hr(n) {
  if (!n)
    return !0;
  for (const e in n)
    return !1;
  return !0;
}
function Ba(n, e) {
  return Object.prototype.hasOwnProperty.call(n, e);
}
function rn(n) {
  return n != null && typeof n == "object" && !Array.isArray(n);
}
const Ua = (n, e) => {
  if (typeof e != "number" || !Number.isInteger(e))
    throw new v(`${n} must be an integer`);
  if (e < 0)
    throw new v(`${n} must be a positive integer`);
  return e;
}, Wa = (n) => {
  try {
    return JSON.parse(n);
  } catch {
    return;
  }
}, at = (n) => new Promise((e) => setTimeout(e, n)), Oe = "6.33.0", za = () => (
  // @ts-ignore
  typeof window < "u" && // @ts-ignore
  typeof window.document < "u" && // @ts-ignore
  typeof navigator < "u"
);
function qa() {
  return typeof Deno < "u" && Deno.build != null ? "deno" : typeof EdgeRuntime < "u" ? "edge" : Object.prototype.toString.call(typeof globalThis.process < "u" ? globalThis.process : 0) === "[object process]" ? "node" : "unknown";
}
const Ha = () => {
  const n = qa();
  if (n === "deno")
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": Oe,
      "X-Stainless-OS": dr(Deno.build.os),
      "X-Stainless-Arch": fr(Deno.build.arch),
      "X-Stainless-Runtime": "deno",
      "X-Stainless-Runtime-Version": typeof Deno.version == "string" ? Deno.version : Deno.version?.deno ?? "unknown"
    };
  if (typeof EdgeRuntime < "u")
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": Oe,
      "X-Stainless-OS": "Unknown",
      "X-Stainless-Arch": `other:${EdgeRuntime}`,
      "X-Stainless-Runtime": "edge",
      "X-Stainless-Runtime-Version": globalThis.process.version
    };
  if (n === "node")
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": Oe,
      "X-Stainless-OS": dr(globalThis.process.platform ?? "unknown"),
      "X-Stainless-Arch": fr(globalThis.process.arch ?? "unknown"),
      "X-Stainless-Runtime": "node",
      "X-Stainless-Runtime-Version": globalThis.process.version ?? "unknown"
    };
  const e = Ja();
  return e ? {
    "X-Stainless-Lang": "js",
    "X-Stainless-Package-Version": Oe,
    "X-Stainless-OS": "Unknown",
    "X-Stainless-Arch": "unknown",
    "X-Stainless-Runtime": `browser:${e.browser}`,
    "X-Stainless-Runtime-Version": e.version
  } : {
    "X-Stainless-Lang": "js",
    "X-Stainless-Package-Version": Oe,
    "X-Stainless-OS": "Unknown",
    "X-Stainless-Arch": "unknown",
    "X-Stainless-Runtime": "unknown",
    "X-Stainless-Runtime-Version": "unknown"
  };
};
function Ja() {
  if (typeof navigator > "u" || !navigator)
    return null;
  const n = [
    { key: "edge", pattern: /Edge(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "ie", pattern: /MSIE(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "ie", pattern: /Trident(?:.*rv\:(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "chrome", pattern: /Chrome(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "firefox", pattern: /Firefox(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "safari", pattern: /(?:Version\W+(\d+)\.(\d+)(?:\.(\d+))?)?(?:\W+Mobile\S*)?\W+Safari/ }
  ];
  for (const { key: e, pattern: t } of n) {
    const r = t.exec(navigator.userAgent);
    if (r) {
      const s = r[1] || 0, i = r[2] || 0, a = r[3] || 0;
      return { browser: e, version: `${s}.${i}.${a}` };
    }
  }
  return null;
}
const fr = (n) => n === "x32" ? "x32" : n === "x86_64" || n === "x64" ? "x64" : n === "arm" ? "arm" : n === "aarch64" || n === "arm64" ? "arm64" : n ? `other:${n}` : "unknown", dr = (n) => (n = n.toLowerCase(), n.includes("ios") ? "iOS" : n === "android" ? "Android" : n === "darwin" ? "MacOS" : n === "win32" ? "Windows" : n === "freebsd" ? "FreeBSD" : n === "openbsd" ? "OpenBSD" : n === "linux" ? "Linux" : n ? `Other:${n}` : "Unknown");
let pr;
const Ka = () => pr ?? (pr = Ha());
function Xa() {
  if (typeof fetch < "u")
    return fetch;
  throw new Error("`fetch` is not defined as a global; Either pass `fetch` to the client, `new OpenAI({ fetch })` or polyfill the global, `globalThis.fetch = fetch`");
}
function hs(...n) {
  const e = globalThis.ReadableStream;
  if (typeof e > "u")
    throw new Error("`ReadableStream` is not defined as a global; You will need to polyfill it, `globalThis.ReadableStream = ReadableStream`");
  return new e(...n);
}
function fs(n) {
  let e = Symbol.asyncIterator in n ? n[Symbol.asyncIterator]() : n[Symbol.iterator]();
  return hs({
    start() {
    },
    async pull(t) {
      const { done: r, value: s } = await e.next();
      r ? t.close() : t.enqueue(s);
    },
    async cancel() {
      await e.return?.();
    }
  });
}
function ds(n) {
  if (n[Symbol.asyncIterator])
    return n;
  const e = n.getReader();
  return {
    async next() {
      try {
        const t = await e.read();
        return t?.done && e.releaseLock(), t;
      } catch (t) {
        throw e.releaseLock(), t;
      }
    },
    async return() {
      const t = e.cancel();
      return e.releaseLock(), await t, { done: !0, value: void 0 };
    },
    [Symbol.asyncIterator]() {
      return this;
    }
  };
}
async function Va(n) {
  if (n === null || typeof n != "object")
    return;
  if (n[Symbol.asyncIterator]) {
    await n[Symbol.asyncIterator]().return?.();
    return;
  }
  const e = n.getReader(), t = e.cancel();
  e.releaseLock(), await t;
}
const Qa = ({ headers: n, body: e }) => ({
  bodyHeaders: {
    "content-type": "application/json"
  },
  body: JSON.stringify(e)
}), ps = "RFC3986", ms = (n) => String(n), mr = {
  RFC1738: (n) => String(n).replace(/%20/g, "+"),
  RFC3986: ms
}, Ga = "RFC1738";
let bn = (n, e) => (bn = Object.hasOwn ?? Function.prototype.call.bind(Object.prototype.hasOwnProperty), bn(n, e));
const te = /* @__PURE__ */ (() => {
  const n = [];
  for (let e = 0; e < 256; ++e)
    n.push("%" + ((e < 16 ? "0" : "") + e.toString(16)).toUpperCase());
  return n;
})(), sn = 1024, Ya = (n, e, t, r, s) => {
  if (n.length === 0)
    return n;
  let i = n;
  if (typeof n == "symbol" ? i = Symbol.prototype.toString.call(n) : typeof n != "string" && (i = String(n)), t === "iso-8859-1")
    return escape(i).replace(/%u[0-9a-f]{4}/gi, function(o) {
      return "%26%23" + parseInt(o.slice(2), 16) + "%3B";
    });
  let a = "";
  for (let o = 0; o < i.length; o += sn) {
    const l = i.length >= sn ? i.slice(o, o + sn) : i, c = [];
    for (let h = 0; h < l.length; ++h) {
      let u = l.charCodeAt(h);
      if (u === 45 || // -
      u === 46 || // .
      u === 95 || // _
      u === 126 || // ~
      u >= 48 && u <= 57 || // 0-9
      u >= 65 && u <= 90 || // a-z
      u >= 97 && u <= 122 || // A-Z
      s === Ga && (u === 40 || u === 41)) {
        c[c.length] = l.charAt(h);
        continue;
      }
      if (u < 128) {
        c[c.length] = te[u];
        continue;
      }
      if (u < 2048) {
        c[c.length] = te[192 | u >> 6] + te[128 | u & 63];
        continue;
      }
      if (u < 55296 || u >= 57344) {
        c[c.length] = te[224 | u >> 12] + te[128 | u >> 6 & 63] + te[128 | u & 63];
        continue;
      }
      h += 1, u = 65536 + ((u & 1023) << 10 | l.charCodeAt(h) & 1023), c[c.length] = te[240 | u >> 18] + te[128 | u >> 12 & 63] + te[128 | u >> 6 & 63] + te[128 | u & 63];
    }
    a += c.join("");
  }
  return a;
};
function Za(n) {
  return !n || typeof n != "object" ? !1 : !!(n.constructor && n.constructor.isBuffer && n.constructor.isBuffer(n));
}
function gr(n, e) {
  if (K(n)) {
    const t = [];
    for (let r = 0; r < n.length; r += 1)
      t.push(e(n[r]));
    return t;
  }
  return e(n);
}
const gs = {
  brackets(n) {
    return String(n) + "[]";
  },
  comma: "comma",
  indices(n, e) {
    return String(n) + "[" + e + "]";
  },
  repeat(n) {
    return String(n);
  }
}, ws = function(n, e) {
  Array.prototype.push.apply(n, K(e) ? e : [e]);
};
let wr;
const j = {
  addQueryPrefix: !1,
  allowDots: !1,
  allowEmptyArrays: !1,
  arrayFormat: "indices",
  charset: "utf-8",
  charsetSentinel: !1,
  delimiter: "&",
  encode: !0,
  encodeDotInKeys: !1,
  encoder: Ya,
  encodeValuesOnly: !1,
  format: ps,
  formatter: ms,
  /** @deprecated */
  indices: !1,
  serializeDate(n) {
    return (wr ?? (wr = Function.prototype.call.bind(Date.prototype.toISOString)))(n);
  },
  skipNulls: !1,
  strictNullHandling: !1
};
function eo(n) {
  return typeof n == "string" || typeof n == "number" || typeof n == "boolean" || typeof n == "symbol" || typeof n == "bigint";
}
const an = {};
function ys(n, e, t, r, s, i, a, o, l, c, h, u, p, f, m, y, x, _) {
  let b = n, A = _, $ = 0, P = !1;
  for (; (A = A.get(an)) !== void 0 && !P; ) {
    const g = A.get(n);
    if ($ += 1, typeof g < "u") {
      if (g === $)
        throw new RangeError("Cyclic object value");
      P = !0;
    }
    typeof A.get(an) > "u" && ($ = 0);
  }
  if (typeof c == "function" ? b = c(e, b) : b instanceof Date ? b = p?.(b) : t === "comma" && K(b) && (b = gr(b, function(g) {
    return g instanceof Date ? p?.(g) : g;
  })), b === null) {
    if (i)
      return l && !y ? (
        // @ts-expect-error
        l(e, j.encoder, x, "key", f)
      ) : e;
    b = "";
  }
  if (eo(b) || Za(b)) {
    if (l) {
      const g = y ? e : l(e, j.encoder, x, "key", f);
      return [
        m?.(g) + "=" + // @ts-expect-error
        m?.(l(b, j.encoder, x, "value", f))
      ];
    }
    return [m?.(e) + "=" + m?.(String(b))];
  }
  const T = [];
  if (typeof b > "u")
    return T;
  let M;
  if (t === "comma" && K(b))
    y && l && (b = gr(b, l)), M = [{ value: b.length > 0 ? b.join(",") || null : void 0 }];
  else if (K(c))
    M = c;
  else {
    const g = Object.keys(b);
    M = h ? g.sort(h) : g;
  }
  const O = o ? String(e).replace(/\./g, "%2E") : String(e), D = r && K(b) && b.length === 1 ? O + "[]" : O;
  if (s && K(b) && b.length === 0)
    return D + "[]";
  for (let g = 0; g < M.length; ++g) {
    const L = M[g], ae = (
      // @ts-ignore
      typeof L == "object" && typeof L.value < "u" ? L.value : b[L]
    );
    if (a && ae === null)
      continue;
    const fe = u && o ? L.replace(/\./g, "%2E") : L, $e = K(b) ? typeof t == "function" ? t(D, fe) : D : D + (u ? "." + fe : "[" + fe + "]");
    _.set(n, $);
    const ye = /* @__PURE__ */ new WeakMap();
    ye.set(an, _), ws(T, ys(
      ae,
      $e,
      t,
      r,
      s,
      i,
      a,
      o,
      // @ts-ignore
      t === "comma" && y && K(b) ? null : l,
      c,
      h,
      u,
      p,
      f,
      m,
      y,
      x,
      ye
    ));
  }
  return T;
}
function to(n = j) {
  if (typeof n.allowEmptyArrays < "u" && typeof n.allowEmptyArrays != "boolean")
    throw new TypeError("`allowEmptyArrays` option can only be `true` or `false`, when provided");
  if (typeof n.encodeDotInKeys < "u" && typeof n.encodeDotInKeys != "boolean")
    throw new TypeError("`encodeDotInKeys` option can only be `true` or `false`, when provided");
  if (n.encoder !== null && typeof n.encoder < "u" && typeof n.encoder != "function")
    throw new TypeError("Encoder has to be a function.");
  const e = n.charset || j.charset;
  if (typeof n.charset < "u" && n.charset !== "utf-8" && n.charset !== "iso-8859-1")
    throw new TypeError("The charset option must be either utf-8, iso-8859-1, or undefined");
  let t = ps;
  if (typeof n.format < "u") {
    if (!bn(mr, n.format))
      throw new TypeError("Unknown format option provided.");
    t = n.format;
  }
  const r = mr[t];
  let s = j.filter;
  (typeof n.filter == "function" || K(n.filter)) && (s = n.filter);
  let i;
  if (n.arrayFormat && n.arrayFormat in gs ? i = n.arrayFormat : "indices" in n ? i = n.indices ? "indices" : "repeat" : i = j.arrayFormat, "commaRoundTrip" in n && typeof n.commaRoundTrip != "boolean")
    throw new TypeError("`commaRoundTrip` must be a boolean, or absent");
  const a = typeof n.allowDots > "u" ? n.encodeDotInKeys ? !0 : j.allowDots : !!n.allowDots;
  return {
    addQueryPrefix: typeof n.addQueryPrefix == "boolean" ? n.addQueryPrefix : j.addQueryPrefix,
    // @ts-ignore
    allowDots: a,
    allowEmptyArrays: typeof n.allowEmptyArrays == "boolean" ? !!n.allowEmptyArrays : j.allowEmptyArrays,
    arrayFormat: i,
    charset: e,
    charsetSentinel: typeof n.charsetSentinel == "boolean" ? n.charsetSentinel : j.charsetSentinel,
    commaRoundTrip: !!n.commaRoundTrip,
    delimiter: typeof n.delimiter > "u" ? j.delimiter : n.delimiter,
    encode: typeof n.encode == "boolean" ? n.encode : j.encode,
    encodeDotInKeys: typeof n.encodeDotInKeys == "boolean" ? n.encodeDotInKeys : j.encodeDotInKeys,
    encoder: typeof n.encoder == "function" ? n.encoder : j.encoder,
    encodeValuesOnly: typeof n.encodeValuesOnly == "boolean" ? n.encodeValuesOnly : j.encodeValuesOnly,
    filter: s,
    format: t,
    formatter: r,
    serializeDate: typeof n.serializeDate == "function" ? n.serializeDate : j.serializeDate,
    skipNulls: typeof n.skipNulls == "boolean" ? n.skipNulls : j.skipNulls,
    // @ts-ignore
    sort: typeof n.sort == "function" ? n.sort : null,
    strictNullHandling: typeof n.strictNullHandling == "boolean" ? n.strictNullHandling : j.strictNullHandling
  };
}
function no(n, e = {}) {
  let t = n;
  const r = to(e);
  let s, i;
  typeof r.filter == "function" ? (i = r.filter, t = i("", t)) : K(r.filter) && (i = r.filter, s = i);
  const a = [];
  if (typeof t != "object" || t === null)
    return "";
  const o = gs[r.arrayFormat], l = o === "comma" && r.commaRoundTrip;
  s || (s = Object.keys(t)), r.sort && s.sort(r.sort);
  const c = /* @__PURE__ */ new WeakMap();
  for (let p = 0; p < s.length; ++p) {
    const f = s[p];
    r.skipNulls && t[f] === null || ws(a, ys(
      t[f],
      f,
      // @ts-expect-error
      o,
      l,
      r.allowEmptyArrays,
      r.strictNullHandling,
      r.skipNulls,
      r.encodeDotInKeys,
      r.encode ? r.encoder : null,
      r.filter,
      r.sort,
      r.allowDots,
      r.serializeDate,
      r.format,
      r.formatter,
      r.encodeValuesOnly,
      r.charset,
      c
    ));
  }
  const h = a.join(r.delimiter);
  let u = r.addQueryPrefix === !0 ? "?" : "";
  return r.charsetSentinel && (r.charset === "iso-8859-1" ? u += "utf8=%26%2310003%3B&" : u += "utf8=%E2%9C%93&"), h.length > 0 ? u + h : "";
}
function ro(n) {
  return no(n, { arrayFormat: "brackets" });
}
function so(n) {
  let e = 0;
  for (const s of n)
    e += s.length;
  const t = new Uint8Array(e);
  let r = 0;
  for (const s of n)
    t.set(s, r), r += s.length;
  return t;
}
let yr;
function Dn(n) {
  let e;
  return (yr ?? (e = new globalThis.TextEncoder(), yr = e.encode.bind(e)))(n);
}
let br;
function _r(n) {
  let e;
  return (br ?? (e = new globalThis.TextDecoder(), br = e.decode.bind(e)))(n);
}
var V, Q;
class Wt {
  constructor() {
    V.set(this, void 0), Q.set(this, void 0), I(this, V, new Uint8Array()), I(this, Q, null);
  }
  decode(e) {
    if (e == null)
      return [];
    const t = e instanceof ArrayBuffer ? new Uint8Array(e) : typeof e == "string" ? Dn(e) : e;
    I(this, V, so([d(this, V, "f"), t]));
    const r = [];
    let s;
    for (; (s = io(d(this, V, "f"), d(this, Q, "f"))) != null; ) {
      if (s.carriage && d(this, Q, "f") == null) {
        I(this, Q, s.index);
        continue;
      }
      if (d(this, Q, "f") != null && (s.index !== d(this, Q, "f") + 1 || s.carriage)) {
        r.push(_r(d(this, V, "f").subarray(0, d(this, Q, "f") - 1))), I(this, V, d(this, V, "f").subarray(d(this, Q, "f"))), I(this, Q, null);
        continue;
      }
      const i = d(this, Q, "f") !== null ? s.preceding - 1 : s.preceding, a = _r(d(this, V, "f").subarray(0, i));
      r.push(a), I(this, V, d(this, V, "f").subarray(s.index)), I(this, Q, null);
    }
    return r;
  }
  flush() {
    return d(this, V, "f").length ? this.decode(`
`) : [];
  }
}
V = /* @__PURE__ */ new WeakMap(), Q = /* @__PURE__ */ new WeakMap();
Wt.NEWLINE_CHARS = /* @__PURE__ */ new Set([`
`, "\r"]);
Wt.NEWLINE_REGEXP = /\r\n|[\n\r]/g;
function io(n, e) {
  for (let s = e ?? 0; s < n.length; s++) {
    if (n[s] === 10)
      return { preceding: s, index: s + 1, carriage: !1 };
    if (n[s] === 13)
      return { preceding: s, index: s + 1, carriage: !0 };
  }
  return null;
}
function ao(n) {
  for (let r = 0; r < n.length - 1; r++) {
    if (n[r] === 10 && n[r + 1] === 10 || n[r] === 13 && n[r + 1] === 13)
      return r + 2;
    if (n[r] === 13 && n[r + 1] === 10 && r + 3 < n.length && n[r + 2] === 13 && n[r + 3] === 10)
      return r + 4;
  }
  return -1;
}
const Et = {
  off: 0,
  error: 200,
  warn: 300,
  info: 400,
  debug: 500
}, kr = (n, e, t) => {
  if (n) {
    if (Ba(Et, n))
      return n;
    U(t).warn(`${e} was set to ${JSON.stringify(n)}, expected one of ${JSON.stringify(Object.keys(Et))}`);
  }
};
function ze() {
}
function ut(n, e, t) {
  return !e || Et[n] > Et[t] ? ze : e[n].bind(e);
}
const oo = {
  error: ze,
  warn: ze,
  info: ze,
  debug: ze
};
let xr = /* @__PURE__ */ new WeakMap();
function U(n) {
  const e = n.logger, t = n.logLevel ?? "off";
  if (!e)
    return oo;
  const r = xr.get(e);
  if (r && r[0] === t)
    return r[1];
  const s = {
    error: ut("error", e, t),
    warn: ut("warn", e, t),
    info: ut("info", e, t),
    debug: ut("debug", e, t)
  };
  return xr.set(e, [t, s]), s;
}
const _e = (n) => (n.options && (n.options = { ...n.options }, delete n.options.headers), n.headers && (n.headers = Object.fromEntries((n.headers instanceof Headers ? [...n.headers] : Object.entries(n.headers)).map(([e, t]) => [
  e,
  e.toLowerCase() === "authorization" || e.toLowerCase() === "cookie" || e.toLowerCase() === "set-cookie" ? "***" : t
]))), "retryOfRequestLogID" in n && (n.retryOfRequestLogID && (n.retryOf = n.retryOfRequestLogID), delete n.retryOfRequestLogID), n);
var Ue;
class re {
  constructor(e, t, r) {
    this.iterator = e, Ue.set(this, void 0), this.controller = t, I(this, Ue, r);
  }
  static fromSSEResponse(e, t, r, s) {
    let i = !1;
    const a = r ? U(r) : console;
    async function* o() {
      if (i)
        throw new v("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");
      i = !0;
      let l = !1;
      try {
        for await (const c of lo(e, t))
          if (!l) {
            if (c.data.startsWith("[DONE]")) {
              l = !0;
              continue;
            }
            if (c.event === null || !c.event.startsWith("thread.")) {
              let h;
              try {
                h = JSON.parse(c.data);
              } catch (u) {
                throw a.error("Could not parse message into JSON:", c.data), a.error("From chunk:", c.raw), u;
              }
              if (h && h.error)
                throw new z(void 0, h.error, void 0, e.headers);
              yield s ? { event: c.event, data: h } : h;
            } else {
              let h;
              try {
                h = JSON.parse(c.data);
              } catch (u) {
                throw console.error("Could not parse message into JSON:", c.data), console.error("From chunk:", c.raw), u;
              }
              if (c.event == "error")
                throw new z(void 0, h.error, h.message, void 0);
              yield { event: c.event, data: h };
            }
          }
        l = !0;
      } catch (c) {
        if (wn(c))
          return;
        throw c;
      } finally {
        l || t.abort();
      }
    }
    return new re(o, t, r);
  }
  /**
   * Generates a Stream from a newline-separated ReadableStream
   * where each item is a JSON value.
   */
  static fromReadableStream(e, t, r) {
    let s = !1;
    async function* i() {
      const o = new Wt(), l = ds(e);
      for await (const c of l)
        for (const h of o.decode(c))
          yield h;
      for (const c of o.flush())
        yield c;
    }
    async function* a() {
      if (s)
        throw new v("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");
      s = !0;
      let o = !1;
      try {
        for await (const l of i())
          o || l && (yield JSON.parse(l));
        o = !0;
      } catch (l) {
        if (wn(l))
          return;
        throw l;
      } finally {
        o || t.abort();
      }
    }
    return new re(a, t, r);
  }
  [(Ue = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
    return this.iterator();
  }
  /**
   * Splits the stream into two streams which can be
   * independently read from at different speeds.
   */
  tee() {
    const e = [], t = [], r = this.iterator(), s = (i) => ({
      next: () => {
        if (i.length === 0) {
          const a = r.next();
          e.push(a), t.push(a);
        }
        return i.shift();
      }
    });
    return [
      new re(() => s(e), this.controller, d(this, Ue, "f")),
      new re(() => s(t), this.controller, d(this, Ue, "f"))
    ];
  }
  /**
   * Converts this stream to a newline-separated ReadableStream of
   * JSON stringified values in the stream
   * which can be turned back into a Stream with `Stream.fromReadableStream()`.
   */
  toReadableStream() {
    const e = this;
    let t;
    return hs({
      async start() {
        t = e[Symbol.asyncIterator]();
      },
      async pull(r) {
        try {
          const { value: s, done: i } = await t.next();
          if (i)
            return r.close();
          const a = Dn(JSON.stringify(s) + `
`);
          r.enqueue(a);
        } catch (s) {
          r.error(s);
        }
      },
      async cancel() {
        await t.return?.();
      }
    });
  }
}
async function* lo(n, e) {
  if (!n.body)
    throw e.abort(), typeof globalThis.navigator < "u" && globalThis.navigator.product === "ReactNative" ? new v("The default react-native fetch implementation does not support streaming. Please use expo/fetch: https://docs.expo.dev/versions/latest/sdk/expo/#expofetch-api") : new v("Attempted to iterate over a response with no body");
  const t = new uo(), r = new Wt(), s = ds(n.body);
  for await (const i of co(s))
    for (const a of r.decode(i)) {
      const o = t.decode(a);
      o && (yield o);
    }
  for (const i of r.flush()) {
    const a = t.decode(i);
    a && (yield a);
  }
}
async function* co(n) {
  let e = new Uint8Array();
  for await (const t of n) {
    if (t == null)
      continue;
    const r = t instanceof ArrayBuffer ? new Uint8Array(t) : typeof t == "string" ? Dn(t) : t;
    let s = new Uint8Array(e.length + r.length);
    s.set(e), s.set(r, e.length), e = s;
    let i;
    for (; (i = ao(e)) !== -1; )
      yield e.slice(0, i), e = e.slice(i);
  }
  e.length > 0 && (yield e);
}
class uo {
  constructor() {
    this.event = null, this.data = [], this.chunks = [];
  }
  decode(e) {
    if (e.endsWith("\r") && (e = e.substring(0, e.length - 1)), !e) {
      if (!this.event && !this.data.length)
        return null;
      const i = {
        event: this.event,
        data: this.data.join(`
`),
        raw: this.chunks
      };
      return this.event = null, this.data = [], this.chunks = [], i;
    }
    if (this.chunks.push(e), e.startsWith(":"))
      return null;
    let [t, r, s] = ho(e, ":");
    return s.startsWith(" ") && (s = s.substring(1)), t === "event" ? this.event = s : t === "data" && this.data.push(s), null;
  }
}
function ho(n, e) {
  const t = n.indexOf(e);
  return t !== -1 ? [n.substring(0, t), e, n.substring(t + e.length)] : [n, "", ""];
}
async function bs(n, e) {
  const { response: t, requestLogID: r, retryOfRequestLogID: s, startTime: i } = e, a = await (async () => {
    if (e.options.stream)
      return U(n).debug("response", t.status, t.url, t.headers, t.body), e.options.__streamClass ? e.options.__streamClass.fromSSEResponse(t, e.controller, n, e.options.__synthesizeEventData) : re.fromSSEResponse(t, e.controller, n, e.options.__synthesizeEventData);
    if (t.status === 204)
      return null;
    if (e.options.__binaryResponse)
      return t;
    const l = t.headers.get("content-type")?.split(";")[0]?.trim();
    if (l?.includes("application/json") || l?.endsWith("+json")) {
      if (t.headers.get("content-length") === "0")
        return;
      const p = await t.json();
      return _s(p, t);
    }
    return await t.text();
  })();
  return U(n).debug(`[${r}] response parsed`, _e({
    retryOfRequestLogID: s,
    url: t.url,
    status: t.status,
    body: a,
    durationMs: Date.now() - i
  })), a;
}
function _s(n, e) {
  return !n || typeof n != "object" || Array.isArray(n) ? n : Object.defineProperty(n, "_request_id", {
    value: e.headers.get("x-request-id"),
    enumerable: !1
  });
}
var qe;
class zt extends Promise {
  constructor(e, t, r = bs) {
    super((s) => {
      s(null);
    }), this.responsePromise = t, this.parseResponse = r, qe.set(this, void 0), I(this, qe, e);
  }
  _thenUnwrap(e) {
    return new zt(d(this, qe, "f"), this.responsePromise, async (t, r) => _s(e(await this.parseResponse(t, r), r), r.response));
  }
  /**
   * Gets the raw `Response` instance instead of parsing the response
   * data.
   *
   * If you want to parse the response body but still get the `Response`
   * instance, you can use {@link withResponse()}.
   *
   * 👋 Getting the wrong TypeScript type for `Response`?
   * Try setting `"moduleResolution": "NodeNext"` or add `"lib": ["DOM"]`
   * to your `tsconfig.json`.
   */
  asResponse() {
    return this.responsePromise.then((e) => e.response);
  }
  /**
   * Gets the parsed response data, the raw `Response` instance and the ID of the request,
   * returned via the X-Request-ID header which is useful for debugging requests and reporting
   * issues to OpenAI.
   *
   * If you just want to get the raw `Response` instance without parsing it,
   * you can use {@link asResponse()}.
   *
   * 👋 Getting the wrong TypeScript type for `Response`?
   * Try setting `"moduleResolution": "NodeNext"` or add `"lib": ["DOM"]`
   * to your `tsconfig.json`.
   */
  async withResponse() {
    const [e, t] = await Promise.all([this.parse(), this.asResponse()]);
    return { data: e, response: t, request_id: t.headers.get("x-request-id") };
  }
  parse() {
    return this.parsedPromise || (this.parsedPromise = this.responsePromise.then((e) => this.parseResponse(d(this, qe, "f"), e))), this.parsedPromise;
  }
  then(e, t) {
    return this.parse().then(e, t);
  }
  catch(e) {
    return this.parse().catch(e);
  }
  finally(e) {
    return this.parse().finally(e);
  }
}
qe = /* @__PURE__ */ new WeakMap();
var ht;
class Ln {
  constructor(e, t, r, s) {
    ht.set(this, void 0), I(this, ht, e), this.options = s, this.response = t, this.body = r;
  }
  hasNextPage() {
    return this.getPaginatedItems().length ? this.nextPageRequestOptions() != null : !1;
  }
  async getNextPage() {
    const e = this.nextPageRequestOptions();
    if (!e)
      throw new v("No next page expected; please check `.hasNextPage()` before calling `.getNextPage()`.");
    return await d(this, ht, "f").requestAPIList(this.constructor, e);
  }
  async *iterPages() {
    let e = this;
    for (yield e; e.hasNextPage(); )
      e = await e.getNextPage(), yield e;
  }
  async *[(ht = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
    for await (const e of this.iterPages())
      for (const t of e.getPaginatedItems())
        yield t;
  }
}
class fo extends zt {
  constructor(e, t, r) {
    super(e, t, async (s, i) => new r(s, i.response, await bs(s, i), i.options));
  }
  /**
   * Allow auto-paginating iteration on an unawaited list call, eg:
   *
   *    for await (const item of client.items.list()) {
   *      console.log(item)
   *    }
   */
  async *[Symbol.asyncIterator]() {
    const e = await this;
    for await (const t of e)
      yield t;
  }
}
class qt extends Ln {
  constructor(e, t, r, s) {
    super(e, t, r, s), this.data = r.data || [], this.object = r.object;
  }
  getPaginatedItems() {
    return this.data ?? [];
  }
  nextPageRequestOptions() {
    return null;
  }
}
class F extends Ln {
  constructor(e, t, r, s) {
    super(e, t, r, s), this.data = r.data || [], this.has_more = r.has_more || !1;
  }
  getPaginatedItems() {
    return this.data ?? [];
  }
  hasNextPage() {
    return this.has_more === !1 ? !1 : super.hasNextPage();
  }
  nextPageRequestOptions() {
    const e = this.getPaginatedItems(), t = e[e.length - 1]?.id;
    return t ? {
      ...this.options,
      query: {
        ...us(this.options.query),
        after: t
      }
    } : null;
  }
}
class tt extends Ln {
  constructor(e, t, r, s) {
    super(e, t, r, s), this.data = r.data || [], this.has_more = r.has_more || !1, this.last_id = r.last_id || "";
  }
  getPaginatedItems() {
    return this.data ?? [];
  }
  hasNextPage() {
    return this.has_more === !1 ? !1 : super.hasNextPage();
  }
  nextPageRequestOptions() {
    const e = this.last_id;
    return e ? {
      ...this.options,
      query: {
        ...us(this.options.query),
        after: e
      }
    } : null;
  }
}
const ks = () => {
  if (typeof File > "u") {
    const { process: n } = globalThis, e = typeof n?.versions?.node == "string" && parseInt(n.versions.node.split(".")) < 20;
    throw new Error("`File` is not defined as a global, which is required for file uploads." + (e ? " Update to Node 20 LTS or newer, or set `globalThis.File` to `import('node:buffer').File`." : ""));
  }
};
function Ge(n, e, t) {
  return ks(), new File(n, e ?? "unknown_file", t);
}
function bt(n) {
  return (typeof n == "object" && n !== null && ("name" in n && n.name && String(n.name) || "url" in n && n.url && String(n.url) || "filename" in n && n.filename && String(n.filename) || "path" in n && n.path && String(n.path)) || "").split(/[\\/]/).pop() || void 0;
}
const Fn = (n) => n != null && typeof n == "object" && typeof n[Symbol.asyncIterator] == "function", Ht = async (n, e) => _n(n.body) ? { ...n, body: await xs(n.body, e) } : n, se = async (n, e) => ({ ...n, body: await xs(n.body, e) }), Cr = /* @__PURE__ */ new WeakMap();
function po(n) {
  const e = typeof n == "function" ? n : n.fetch, t = Cr.get(e);
  if (t)
    return t;
  const r = (async () => {
    try {
      const s = "Response" in e ? e.Response : (await e("data:,")).constructor, i = new FormData();
      return i.toString() !== await new s(i).text();
    } catch {
      return !0;
    }
  })();
  return Cr.set(e, r), r;
}
const xs = async (n, e) => {
  if (!await po(e))
    throw new TypeError("The provided fetch function does not support file uploads with the current global FormData class.");
  const t = new FormData();
  return await Promise.all(Object.entries(n || {}).map(([r, s]) => kn(t, r, s))), t;
}, Cs = (n) => n instanceof Blob && "name" in n, mo = (n) => typeof n == "object" && n !== null && (n instanceof Response || Fn(n) || Cs(n)), _n = (n) => {
  if (mo(n))
    return !0;
  if (Array.isArray(n))
    return n.some(_n);
  if (n && typeof n == "object") {
    for (const e in n)
      if (_n(n[e]))
        return !0;
  }
  return !1;
}, kn = async (n, e, t) => {
  if (t !== void 0) {
    if (t == null)
      throw new TypeError(`Received null for "${e}"; to pass null in FormData, you must use the string 'null'`);
    if (typeof t == "string" || typeof t == "number" || typeof t == "boolean")
      n.append(e, String(t));
    else if (t instanceof Response)
      n.append(e, Ge([await t.blob()], bt(t)));
    else if (Fn(t))
      n.append(e, Ge([await new Response(fs(t)).blob()], bt(t)));
    else if (Cs(t))
      n.append(e, t, bt(t));
    else if (Array.isArray(t))
      await Promise.all(t.map((r) => kn(n, e + "[]", r)));
    else if (typeof t == "object")
      await Promise.all(Object.entries(t).map(([r, s]) => kn(n, `${e}[${r}]`, s)));
    else
      throw new TypeError(`Invalid value given to form, expected a string, number, boolean, object, Array, File or Blob but got ${t} instead`);
  }
}, Ss = (n) => n != null && typeof n == "object" && typeof n.size == "number" && typeof n.type == "string" && typeof n.text == "function" && typeof n.slice == "function" && typeof n.arrayBuffer == "function", go = (n) => n != null && typeof n == "object" && typeof n.name == "string" && typeof n.lastModified == "number" && Ss(n), wo = (n) => n != null && typeof n == "object" && typeof n.url == "string" && typeof n.blob == "function";
async function yo(n, e, t) {
  if (ks(), n = await n, go(n))
    return n instanceof File ? n : Ge([await n.arrayBuffer()], n.name);
  if (wo(n)) {
    const s = await n.blob();
    return e || (e = new URL(n.url).pathname.split(/[\\/]/).pop()), Ge(await xn(s), e, t);
  }
  const r = await xn(n);
  if (e || (e = bt(n)), !t?.type) {
    const s = r.find((i) => typeof i == "object" && "type" in i && i.type);
    typeof s == "string" && (t = { ...t, type: s });
  }
  return Ge(r, e, t);
}
async function xn(n) {
  let e = [];
  if (typeof n == "string" || ArrayBuffer.isView(n) || // includes Uint8Array, Buffer, etc.
  n instanceof ArrayBuffer)
    e.push(n);
  else if (Ss(n))
    e.push(n instanceof Blob ? n : await n.arrayBuffer());
  else if (Fn(n))
    for await (const t of n)
      e.push(...await xn(t));
  else {
    const t = n?.constructor?.name;
    throw new Error(`Unexpected data type: ${typeof n}${t ? `; constructor: ${t}` : ""}${bo(n)}`);
  }
  return e;
}
function bo(n) {
  return typeof n != "object" || n === null ? "" : `; props: [${Object.getOwnPropertyNames(n).map((t) => `"${t}"`).join(", ")}]`;
}
class S {
  constructor(e) {
    this._client = e;
  }
}
function vs(n) {
  return n.replace(/[^A-Za-z0-9\-._~!$&'()*+,;=:@]+/g, encodeURIComponent);
}
const Sr = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.create(null)), _o = (n = vs) => function(t, ...r) {
  if (t.length === 1)
    return t[0];
  let s = !1;
  const i = [], a = t.reduce((h, u, p) => {
    /[?#]/.test(u) && (s = !0);
    const f = r[p];
    let m = (s ? encodeURIComponent : n)("" + f);
    return p !== r.length && (f == null || typeof f == "object" && // handle values from other realms
    f.toString === Object.getPrototypeOf(Object.getPrototypeOf(f.hasOwnProperty ?? Sr) ?? Sr)?.toString) && (m = f + "", i.push({
      start: h.length + u.length,
      length: m.length,
      error: `Value of type ${Object.prototype.toString.call(f).slice(8, -1)} is not a valid path parameter`
    })), h + u + (p === r.length ? "" : m);
  }, ""), o = a.split(/[?#]/, 1)[0], l = new RegExp("(?<=^|\\/)(?:\\.|%2e){1,2}(?=\\/|$)", "gi");
  let c;
  for (; (c = l.exec(o)) !== null; )
    i.push({
      start: c.index,
      length: c[0].length,
      error: `Value "${c[0]}" can't be safely passed as a path parameter`
    });
  if (i.sort((h, u) => h.start - u.start), i.length > 0) {
    let h = 0;
    const u = i.reduce((p, f) => {
      const m = " ".repeat(f.start - h), y = "^".repeat(f.length);
      return h = f.start + f.length, p + m + y;
    }, "");
    throw new v(`Path parameters result in path with invalid segments:
${i.map((p) => p.error).join(`
`)}
${a}
${u}`);
  }
  return a;
}, w = /* @__PURE__ */ _o(vs);
let As = class extends S {
  /**
   * Get the messages in a stored chat completion. Only Chat Completions that have
   * been created with the `store` parameter set to `true` will be returned.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const chatCompletionStoreMessage of client.chat.completions.messages.list(
   *   'completion_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(e, t = {}, r) {
    return this._client.getAPIList(w`/chat/completions/${e}/messages`, F, { query: t, ...r });
  }
};
function Pt(n) {
  return n !== void 0 && "function" in n && n.function !== void 0;
}
function Nn(n) {
  return n?.$brand === "auto-parseable-response-format";
}
function ot(n) {
  return n?.$brand === "auto-parseable-tool";
}
function ko(n, e) {
  return !e || !Rs(e) ? {
    ...n,
    choices: n.choices.map((t) => (Is(t.message.tool_calls), {
      ...t,
      message: {
        ...t.message,
        parsed: null,
        ...t.message.tool_calls ? {
          tool_calls: t.message.tool_calls
        } : void 0
      }
    }))
  } : jn(n, e);
}
function jn(n, e) {
  const t = n.choices.map((r) => {
    if (r.finish_reason === "length")
      throw new ls();
    if (r.finish_reason === "content_filter")
      throw new cs();
    return Is(r.message.tool_calls), {
      ...r,
      message: {
        ...r.message,
        ...r.message.tool_calls ? {
          tool_calls: r.message.tool_calls?.map((s) => Co(e, s)) ?? void 0
        } : void 0,
        parsed: r.message.content && !r.message.refusal ? xo(e, r.message.content) : null
      }
    };
  });
  return { ...n, choices: t };
}
function xo(n, e) {
  return n.response_format?.type !== "json_schema" ? null : n.response_format?.type === "json_schema" ? "$parseRaw" in n.response_format ? n.response_format.$parseRaw(e) : JSON.parse(e) : null;
}
function Co(n, e) {
  const t = n.tools?.find((r) => Pt(r) && r.function?.name === e.function.name);
  return {
    ...e,
    function: {
      ...e.function,
      parsed_arguments: ot(t) ? t.$parseRaw(e.function.arguments) : t?.function.strict ? JSON.parse(e.function.arguments) : null
    }
  };
}
function So(n, e) {
  if (!n || !("tools" in n) || !n.tools)
    return !1;
  const t = n.tools?.find((r) => Pt(r) && r.function?.name === e.function.name);
  return Pt(t) && (ot(t) || t?.function.strict || !1);
}
function Rs(n) {
  return Nn(n.response_format) ? !0 : n.tools?.some((e) => ot(e) || e.type === "function" && e.function.strict === !0) ?? !1;
}
function Is(n) {
  for (const e of n || [])
    if (e.type !== "function")
      throw new v(`Currently only \`function\` tool calls are supported; Received \`${e.type}\``);
}
function vo(n) {
  for (const e of n ?? []) {
    if (e.type !== "function")
      throw new v(`Currently only \`function\` tool types support auto-parsing; Received \`${e.type}\``);
    if (e.function.strict !== !0)
      throw new v(`The \`${e.function.name}\` tool is not marked with \`strict: true\`. Only strict function tools can be auto-parsed`);
  }
}
const Tt = (n) => n?.role === "assistant", $s = (n) => n?.role === "tool";
var Cn, _t, kt, He, Je, xt, Ke, le, Xe, Ot, Mt, Me, Es;
class Bn {
  constructor() {
    Cn.add(this), this.controller = new AbortController(), _t.set(this, void 0), kt.set(this, () => {
    }), He.set(this, () => {
    }), Je.set(this, void 0), xt.set(this, () => {
    }), Ke.set(this, () => {
    }), le.set(this, {}), Xe.set(this, !1), Ot.set(this, !1), Mt.set(this, !1), Me.set(this, !1), I(this, _t, new Promise((e, t) => {
      I(this, kt, e, "f"), I(this, He, t, "f");
    })), I(this, Je, new Promise((e, t) => {
      I(this, xt, e, "f"), I(this, Ke, t, "f");
    })), d(this, _t, "f").catch(() => {
    }), d(this, Je, "f").catch(() => {
    });
  }
  _run(e) {
    setTimeout(() => {
      e().then(() => {
        this._emitFinal(), this._emit("end");
      }, d(this, Cn, "m", Es).bind(this));
    }, 0);
  }
  _connected() {
    this.ended || (d(this, kt, "f").call(this), this._emit("connect"));
  }
  get ended() {
    return d(this, Xe, "f");
  }
  get errored() {
    return d(this, Ot, "f");
  }
  get aborted() {
    return d(this, Mt, "f");
  }
  abort() {
    this.controller.abort();
  }
  /**
   * Adds the listener function to the end of the listeners array for the event.
   * No checks are made to see if the listener has already been added. Multiple calls passing
   * the same combination of event and listener will result in the listener being added, and
   * called, multiple times.
   * @returns this ChatCompletionStream, so that calls can be chained
   */
  on(e, t) {
    return (d(this, le, "f")[e] || (d(this, le, "f")[e] = [])).push({ listener: t }), this;
  }
  /**
   * Removes the specified listener from the listener array for the event.
   * off() will remove, at most, one instance of a listener from the listener array. If any single
   * listener has been added multiple times to the listener array for the specified event, then
   * off() must be called multiple times to remove each instance.
   * @returns this ChatCompletionStream, so that calls can be chained
   */
  off(e, t) {
    const r = d(this, le, "f")[e];
    if (!r)
      return this;
    const s = r.findIndex((i) => i.listener === t);
    return s >= 0 && r.splice(s, 1), this;
  }
  /**
   * Adds a one-time listener function for the event. The next time the event is triggered,
   * this listener is removed and then invoked.
   * @returns this ChatCompletionStream, so that calls can be chained
   */
  once(e, t) {
    return (d(this, le, "f")[e] || (d(this, le, "f")[e] = [])).push({ listener: t, once: !0 }), this;
  }
  /**
   * This is similar to `.once()`, but returns a Promise that resolves the next time
   * the event is triggered, instead of calling a listener callback.
   * @returns a Promise that resolves the next time given event is triggered,
   * or rejects if an error is emitted.  (If you request the 'error' event,
   * returns a promise that resolves with the error).
   *
   * Example:
   *
   *   const message = await stream.emitted('message') // rejects if the stream errors
   */
  emitted(e) {
    return new Promise((t, r) => {
      I(this, Me, !0), e !== "error" && this.once("error", r), this.once(e, t);
    });
  }
  async done() {
    I(this, Me, !0), await d(this, Je, "f");
  }
  _emit(e, ...t) {
    if (d(this, Xe, "f"))
      return;
    e === "end" && (I(this, Xe, !0), d(this, xt, "f").call(this));
    const r = d(this, le, "f")[e];
    if (r && (d(this, le, "f")[e] = r.filter((s) => !s.once), r.forEach(({ listener: s }) => s(...t))), e === "abort") {
      const s = t[0];
      !d(this, Me, "f") && !r?.length && Promise.reject(s), d(this, He, "f").call(this, s), d(this, Ke, "f").call(this, s), this._emit("end");
      return;
    }
    if (e === "error") {
      const s = t[0];
      !d(this, Me, "f") && !r?.length && Promise.reject(s), d(this, He, "f").call(this, s), d(this, Ke, "f").call(this, s), this._emit("end");
    }
  }
  _emitFinal() {
  }
}
_t = /* @__PURE__ */ new WeakMap(), kt = /* @__PURE__ */ new WeakMap(), He = /* @__PURE__ */ new WeakMap(), Je = /* @__PURE__ */ new WeakMap(), xt = /* @__PURE__ */ new WeakMap(), Ke = /* @__PURE__ */ new WeakMap(), le = /* @__PURE__ */ new WeakMap(), Xe = /* @__PURE__ */ new WeakMap(), Ot = /* @__PURE__ */ new WeakMap(), Mt = /* @__PURE__ */ new WeakMap(), Me = /* @__PURE__ */ new WeakMap(), Cn = /* @__PURE__ */ new WeakSet(), Es = function(e) {
  if (I(this, Ot, !0), e instanceof Error && e.name === "AbortError" && (e = new Y()), e instanceof Y)
    return I(this, Mt, !0), this._emit("abort", e);
  if (e instanceof v)
    return this._emit("error", e);
  if (e instanceof Error) {
    const t = new v(e.message);
    return t.cause = e, this._emit("error", t);
  }
  return this._emit("error", new v(String(e)));
};
function Ao(n) {
  return typeof n.parse == "function";
}
var H, Sn, Dt, vn, An, Rn, Ps, Ts;
const Ro = 10;
class Os extends Bn {
  constructor() {
    super(...arguments), H.add(this), this._chatCompletions = [], this.messages = [];
  }
  _addChatCompletion(e) {
    this._chatCompletions.push(e), this._emit("chatCompletion", e);
    const t = e.choices[0]?.message;
    return t && this._addMessage(t), e;
  }
  _addMessage(e, t = !0) {
    if ("content" in e || (e.content = null), this.messages.push(e), t) {
      if (this._emit("message", e), $s(e) && e.content)
        this._emit("functionToolCallResult", e.content);
      else if (Tt(e) && e.tool_calls)
        for (const r of e.tool_calls)
          r.type === "function" && this._emit("functionToolCall", r.function);
    }
  }
  /**
   * @returns a promise that resolves with the final ChatCompletion, or rejects
   * if an error occurred or the stream ended prematurely without producing a ChatCompletion.
   */
  async finalChatCompletion() {
    await this.done();
    const e = this._chatCompletions[this._chatCompletions.length - 1];
    if (!e)
      throw new v("stream ended without producing a ChatCompletion");
    return e;
  }
  /**
   * @returns a promise that resolves with the content of the final ChatCompletionMessage, or rejects
   * if an error occurred or the stream ended prematurely without producing a ChatCompletionMessage.
   */
  async finalContent() {
    return await this.done(), d(this, H, "m", Sn).call(this);
  }
  /**
   * @returns a promise that resolves with the the final assistant ChatCompletionMessage response,
   * or rejects if an error occurred or the stream ended prematurely without producing a ChatCompletionMessage.
   */
  async finalMessage() {
    return await this.done(), d(this, H, "m", Dt).call(this);
  }
  /**
   * @returns a promise that resolves with the content of the final FunctionCall, or rejects
   * if an error occurred or the stream ended prematurely without producing a ChatCompletionMessage.
   */
  async finalFunctionToolCall() {
    return await this.done(), d(this, H, "m", vn).call(this);
  }
  async finalFunctionToolCallResult() {
    return await this.done(), d(this, H, "m", An).call(this);
  }
  async totalUsage() {
    return await this.done(), d(this, H, "m", Rn).call(this);
  }
  allChatCompletions() {
    return [...this._chatCompletions];
  }
  _emitFinal() {
    const e = this._chatCompletions[this._chatCompletions.length - 1];
    e && this._emit("finalChatCompletion", e);
    const t = d(this, H, "m", Dt).call(this);
    t && this._emit("finalMessage", t);
    const r = d(this, H, "m", Sn).call(this);
    r && this._emit("finalContent", r);
    const s = d(this, H, "m", vn).call(this);
    s && this._emit("finalFunctionToolCall", s);
    const i = d(this, H, "m", An).call(this);
    i != null && this._emit("finalFunctionToolCallResult", i), this._chatCompletions.some((a) => a.usage) && this._emit("totalUsage", d(this, H, "m", Rn).call(this));
  }
  async _createChatCompletion(e, t, r) {
    const s = r?.signal;
    s && (s.aborted && this.controller.abort(), s.addEventListener("abort", () => this.controller.abort())), d(this, H, "m", Ps).call(this, t);
    const i = await e.chat.completions.create({ ...t, stream: !1 }, { ...r, signal: this.controller.signal });
    return this._connected(), this._addChatCompletion(jn(i, t));
  }
  async _runChatCompletion(e, t, r) {
    for (const s of t.messages)
      this._addMessage(s, !1);
    return await this._createChatCompletion(e, t, r);
  }
  async _runTools(e, t, r) {
    const s = "tool", { tool_choice: i = "auto", stream: a, ...o } = t, l = typeof i != "string" && i.type === "function" && i?.function?.name, { maxChatCompletions: c = Ro } = r || {}, h = t.tools.map((f) => {
      if (ot(f)) {
        if (!f.$callback)
          throw new v("Tool given to `.runTools()` that does not have an associated function");
        return {
          type: "function",
          function: {
            function: f.$callback,
            name: f.function.name,
            description: f.function.description || "",
            parameters: f.function.parameters,
            parse: f.$parseRaw,
            strict: !0
          }
        };
      }
      return f;
    }), u = {};
    for (const f of h)
      f.type === "function" && (u[f.function.name || f.function.function.name] = f.function);
    const p = "tools" in t ? h.map((f) => f.type === "function" ? {
      type: "function",
      function: {
        name: f.function.name || f.function.function.name,
        parameters: f.function.parameters,
        description: f.function.description,
        strict: f.function.strict
      }
    } : f) : void 0;
    for (const f of t.messages)
      this._addMessage(f, !1);
    for (let f = 0; f < c; ++f) {
      const y = (await this._createChatCompletion(e, {
        ...o,
        tool_choice: i,
        tools: p,
        messages: [...this.messages]
      }, r)).choices[0]?.message;
      if (!y)
        throw new v("missing message in ChatCompletion response");
      if (!y.tool_calls?.length)
        return;
      for (const x of y.tool_calls) {
        if (x.type !== "function")
          continue;
        const _ = x.id, { name: b, arguments: A } = x.function, $ = u[b];
        if ($) {
          if (l && l !== b) {
            const O = `Invalid tool_call: ${JSON.stringify(b)}. ${JSON.stringify(l)} requested. Please try again`;
            this._addMessage({ role: s, tool_call_id: _, content: O });
            continue;
          }
        } else {
          const O = `Invalid tool_call: ${JSON.stringify(b)}. Available options are: ${Object.keys(u).map((D) => JSON.stringify(D)).join(", ")}. Please try again`;
          this._addMessage({ role: s, tool_call_id: _, content: O });
          continue;
        }
        let P;
        try {
          P = Ao($) ? await $.parse(A) : A;
        } catch (O) {
          const D = O instanceof Error ? O.message : String(O);
          this._addMessage({ role: s, tool_call_id: _, content: D });
          continue;
        }
        const T = await $.function(P, this), M = d(this, H, "m", Ts).call(this, T);
        if (this._addMessage({ role: s, tool_call_id: _, content: M }), l)
          return;
      }
    }
  }
}
H = /* @__PURE__ */ new WeakSet(), Sn = function() {
  return d(this, H, "m", Dt).call(this).content ?? null;
}, Dt = function() {
  let e = this.messages.length;
  for (; e-- > 0; ) {
    const t = this.messages[e];
    if (Tt(t))
      return {
        ...t,
        content: t.content ?? null,
        refusal: t.refusal ?? null
      };
  }
  throw new v("stream ended without producing a ChatCompletionMessage with role=assistant");
}, vn = function() {
  for (let e = this.messages.length - 1; e >= 0; e--) {
    const t = this.messages[e];
    if (Tt(t) && t?.tool_calls?.length)
      return t.tool_calls.filter((r) => r.type === "function").at(-1)?.function;
  }
}, An = function() {
  for (let e = this.messages.length - 1; e >= 0; e--) {
    const t = this.messages[e];
    if ($s(t) && t.content != null && typeof t.content == "string" && this.messages.some((r) => r.role === "assistant" && r.tool_calls?.some((s) => s.type === "function" && s.id === t.tool_call_id)))
      return t.content;
  }
}, Rn = function() {
  const e = {
    completion_tokens: 0,
    prompt_tokens: 0,
    total_tokens: 0
  };
  for (const { usage: t } of this._chatCompletions)
    t && (e.completion_tokens += t.completion_tokens, e.prompt_tokens += t.prompt_tokens, e.total_tokens += t.total_tokens);
  return e;
}, Ps = function(e) {
  if (e.n != null && e.n > 1)
    throw new v("ChatCompletion convenience helpers only support n=1 at this time. To use n>1, please use chat.completions.create() directly.");
}, Ts = function(e) {
  return typeof e == "string" ? e : e === void 0 ? "undefined" : JSON.stringify(e);
};
class Un extends Os {
  static runTools(e, t, r) {
    const s = new Un(), i = {
      ...r,
      headers: { ...r?.headers, "X-Stainless-Helper-Method": "runTools" }
    };
    return s._run(() => s._runTools(e, t, i)), s;
  }
  _addMessage(e, t = !0) {
    super._addMessage(e, t), Tt(e) && e.content && this._emit("content", e.content);
  }
}
const Ms = 1, Ds = 2, Ls = 4, Fs = 8, Ns = 16, js = 32, Bs = 64, Us = 128, Ws = 256, zs = Us | Ws, qs = Ns | js | zs | Bs, Hs = Ms | Ds | qs, Js = Ls | Fs, Io = Hs | Js, B = {
  STR: Ms,
  NUM: Ds,
  ARR: Ls,
  OBJ: Fs,
  NULL: Ns,
  BOOL: js,
  NAN: Bs,
  INFINITY: Us,
  MINUS_INFINITY: Ws,
  INF: zs,
  SPECIAL: qs,
  ATOM: Hs,
  COLLECTION: Js,
  ALL: Io
};
class $o extends Error {
}
class Eo extends Error {
}
function Po(n, e = B.ALL) {
  if (typeof n != "string")
    throw new TypeError(`expecting str, got ${typeof n}`);
  if (!n.trim())
    throw new Error(`${n} is empty`);
  return To(n.trim(), e);
}
const To = (n, e) => {
  const t = n.length;
  let r = 0;
  const s = (p) => {
    throw new $o(`${p} at position ${r}`);
  }, i = (p) => {
    throw new Eo(`${p} at position ${r}`);
  }, a = () => (u(), r >= t && s("Unexpected end of input"), n[r] === '"' ? o() : n[r] === "{" ? l() : n[r] === "[" ? c() : n.substring(r, r + 4) === "null" || B.NULL & e && t - r < 4 && "null".startsWith(n.substring(r)) ? (r += 4, null) : n.substring(r, r + 4) === "true" || B.BOOL & e && t - r < 4 && "true".startsWith(n.substring(r)) ? (r += 4, !0) : n.substring(r, r + 5) === "false" || B.BOOL & e && t - r < 5 && "false".startsWith(n.substring(r)) ? (r += 5, !1) : n.substring(r, r + 8) === "Infinity" || B.INFINITY & e && t - r < 8 && "Infinity".startsWith(n.substring(r)) ? (r += 8, 1 / 0) : n.substring(r, r + 9) === "-Infinity" || B.MINUS_INFINITY & e && 1 < t - r && t - r < 9 && "-Infinity".startsWith(n.substring(r)) ? (r += 9, -1 / 0) : n.substring(r, r + 3) === "NaN" || B.NAN & e && t - r < 3 && "NaN".startsWith(n.substring(r)) ? (r += 3, NaN) : h()), o = () => {
    const p = r;
    let f = !1;
    for (r++; r < t && (n[r] !== '"' || f && n[r - 1] === "\\"); )
      f = n[r] === "\\" ? !f : !1, r++;
    if (n.charAt(r) == '"')
      try {
        return JSON.parse(n.substring(p, ++r - Number(f)));
      } catch (m) {
        i(String(m));
      }
    else if (B.STR & e)
      try {
        return JSON.parse(n.substring(p, r - Number(f)) + '"');
      } catch {
        return JSON.parse(n.substring(p, n.lastIndexOf("\\")) + '"');
      }
    s("Unterminated string literal");
  }, l = () => {
    r++, u();
    const p = {};
    try {
      for (; n[r] !== "}"; ) {
        if (u(), r >= t && B.OBJ & e)
          return p;
        const f = o();
        u(), r++;
        try {
          const m = a();
          Object.defineProperty(p, f, { value: m, writable: !0, enumerable: !0, configurable: !0 });
        } catch (m) {
          if (B.OBJ & e)
            return p;
          throw m;
        }
        u(), n[r] === "," && r++;
      }
    } catch {
      if (B.OBJ & e)
        return p;
      s("Expected '}' at end of object");
    }
    return r++, p;
  }, c = () => {
    r++;
    const p = [];
    try {
      for (; n[r] !== "]"; )
        p.push(a()), u(), n[r] === "," && r++;
    } catch {
      if (B.ARR & e)
        return p;
      s("Expected ']' at end of array");
    }
    return r++, p;
  }, h = () => {
    if (r === 0) {
      n === "-" && B.NUM & e && s("Not sure what '-' is");
      try {
        return JSON.parse(n);
      } catch (f) {
        if (B.NUM & e)
          try {
            return n[n.length - 1] === "." ? JSON.parse(n.substring(0, n.lastIndexOf("."))) : JSON.parse(n.substring(0, n.lastIndexOf("e")));
          } catch {
          }
        i(String(f));
      }
    }
    const p = r;
    for (n[r] === "-" && r++; n[r] && !",]}".includes(n[r]); )
      r++;
    r == t && !(B.NUM & e) && s("Unterminated number literal");
    try {
      return JSON.parse(n.substring(p, r));
    } catch {
      n.substring(p, r) === "-" && B.NUM & e && s("Not sure what '-' is");
      try {
        return JSON.parse(n.substring(p, n.lastIndexOf("e")));
      } catch (m) {
        i(String(m));
      }
    }
  }, u = () => {
    for (; r < t && ` 
\r	`.includes(n[r]); )
      r++;
  };
  return a();
}, vr = (n) => Po(n, B.ALL ^ B.NUM);
var N, oe, Ee, de, on, ft, ln, cn, un, dt, hn, Ar;
class nt extends Os {
  constructor(e) {
    super(), N.add(this), oe.set(this, void 0), Ee.set(this, void 0), de.set(this, void 0), I(this, oe, e), I(this, Ee, []);
  }
  get currentChatCompletionSnapshot() {
    return d(this, de, "f");
  }
  /**
   * Intended for use on the frontend, consuming a stream produced with
   * `.toReadableStream()` on the backend.
   *
   * Note that messages sent to the model do not appear in `.on('message')`
   * in this context.
   */
  static fromReadableStream(e) {
    const t = new nt(null);
    return t._run(() => t._fromReadableStream(e)), t;
  }
  static createChatCompletion(e, t, r) {
    const s = new nt(t);
    return s._run(() => s._runChatCompletion(e, { ...t, stream: !0 }, { ...r, headers: { ...r?.headers, "X-Stainless-Helper-Method": "stream" } })), s;
  }
  async _createChatCompletion(e, t, r) {
    super._createChatCompletion;
    const s = r?.signal;
    s && (s.aborted && this.controller.abort(), s.addEventListener("abort", () => this.controller.abort())), d(this, N, "m", on).call(this);
    const i = await e.chat.completions.create({ ...t, stream: !0 }, { ...r, signal: this.controller.signal });
    this._connected();
    for await (const a of i)
      d(this, N, "m", ln).call(this, a);
    if (i.controller.signal?.aborted)
      throw new Y();
    return this._addChatCompletion(d(this, N, "m", dt).call(this));
  }
  async _fromReadableStream(e, t) {
    const r = t?.signal;
    r && (r.aborted && this.controller.abort(), r.addEventListener("abort", () => this.controller.abort())), d(this, N, "m", on).call(this), this._connected();
    const s = re.fromReadableStream(e, this.controller);
    let i;
    for await (const a of s)
      i && i !== a.id && this._addChatCompletion(d(this, N, "m", dt).call(this)), d(this, N, "m", ln).call(this, a), i = a.id;
    if (s.controller.signal?.aborted)
      throw new Y();
    return this._addChatCompletion(d(this, N, "m", dt).call(this));
  }
  [(oe = /* @__PURE__ */ new WeakMap(), Ee = /* @__PURE__ */ new WeakMap(), de = /* @__PURE__ */ new WeakMap(), N = /* @__PURE__ */ new WeakSet(), on = function() {
    this.ended || I(this, de, void 0);
  }, ft = function(t) {
    let r = d(this, Ee, "f")[t.index];
    return r || (r = {
      content_done: !1,
      refusal_done: !1,
      logprobs_content_done: !1,
      logprobs_refusal_done: !1,
      done_tool_calls: /* @__PURE__ */ new Set(),
      current_tool_call_index: null
    }, d(this, Ee, "f")[t.index] = r, r);
  }, ln = function(t) {
    if (this.ended)
      return;
    const r = d(this, N, "m", Ar).call(this, t);
    this._emit("chunk", t, r);
    for (const s of t.choices) {
      const i = r.choices[s.index];
      s.delta.content != null && i.message?.role === "assistant" && i.message?.content && (this._emit("content", s.delta.content, i.message.content), this._emit("content.delta", {
        delta: s.delta.content,
        snapshot: i.message.content,
        parsed: i.message.parsed
      })), s.delta.refusal != null && i.message?.role === "assistant" && i.message?.refusal && this._emit("refusal.delta", {
        delta: s.delta.refusal,
        snapshot: i.message.refusal
      }), s.logprobs?.content != null && i.message?.role === "assistant" && this._emit("logprobs.content.delta", {
        content: s.logprobs?.content,
        snapshot: i.logprobs?.content ?? []
      }), s.logprobs?.refusal != null && i.message?.role === "assistant" && this._emit("logprobs.refusal.delta", {
        refusal: s.logprobs?.refusal,
        snapshot: i.logprobs?.refusal ?? []
      });
      const a = d(this, N, "m", ft).call(this, i);
      i.finish_reason && (d(this, N, "m", un).call(this, i), a.current_tool_call_index != null && d(this, N, "m", cn).call(this, i, a.current_tool_call_index));
      for (const o of s.delta.tool_calls ?? [])
        a.current_tool_call_index !== o.index && (d(this, N, "m", un).call(this, i), a.current_tool_call_index != null && d(this, N, "m", cn).call(this, i, a.current_tool_call_index)), a.current_tool_call_index = o.index;
      for (const o of s.delta.tool_calls ?? []) {
        const l = i.message.tool_calls?.[o.index];
        l?.type && (l?.type === "function" ? this._emit("tool_calls.function.arguments.delta", {
          name: l.function?.name,
          index: o.index,
          arguments: l.function.arguments,
          parsed_arguments: l.function.parsed_arguments,
          arguments_delta: o.function?.arguments ?? ""
        }) : (l?.type, void 0));
      }
    }
  }, cn = function(t, r) {
    if (d(this, N, "m", ft).call(this, t).done_tool_calls.has(r))
      return;
    const i = t.message.tool_calls?.[r];
    if (!i)
      throw new Error("no tool call snapshot");
    if (!i.type)
      throw new Error("tool call snapshot missing `type`");
    if (i.type === "function") {
      const a = d(this, oe, "f")?.tools?.find((o) => Pt(o) && o.function.name === i.function.name);
      this._emit("tool_calls.function.arguments.done", {
        name: i.function.name,
        index: r,
        arguments: i.function.arguments,
        parsed_arguments: ot(a) ? a.$parseRaw(i.function.arguments) : a?.function.strict ? JSON.parse(i.function.arguments) : null
      });
    } else
      i.type;
  }, un = function(t) {
    const r = d(this, N, "m", ft).call(this, t);
    if (t.message.content && !r.content_done) {
      r.content_done = !0;
      const s = d(this, N, "m", hn).call(this);
      this._emit("content.done", {
        content: t.message.content,
        parsed: s ? s.$parseRaw(t.message.content) : null
      });
    }
    t.message.refusal && !r.refusal_done && (r.refusal_done = !0, this._emit("refusal.done", { refusal: t.message.refusal })), t.logprobs?.content && !r.logprobs_content_done && (r.logprobs_content_done = !0, this._emit("logprobs.content.done", { content: t.logprobs.content })), t.logprobs?.refusal && !r.logprobs_refusal_done && (r.logprobs_refusal_done = !0, this._emit("logprobs.refusal.done", { refusal: t.logprobs.refusal }));
  }, dt = function() {
    if (this.ended)
      throw new v("stream has ended, this shouldn't happen");
    const t = d(this, de, "f");
    if (!t)
      throw new v("request ended without sending any chunks");
    return I(this, de, void 0), I(this, Ee, []), Oo(t, d(this, oe, "f"));
  }, hn = function() {
    const t = d(this, oe, "f")?.response_format;
    return Nn(t) ? t : null;
  }, Ar = function(t) {
    var r, s, i, a;
    let o = d(this, de, "f");
    const { choices: l, ...c } = t;
    o ? Object.assign(o, c) : o = I(this, de, {
      ...c,
      choices: []
    });
    for (const { delta: h, finish_reason: u, index: p, logprobs: f = null, ...m } of t.choices) {
      let y = o.choices[p];
      if (y || (y = o.choices[p] = { finish_reason: u, index: p, message: {}, logprobs: f, ...m }), f)
        if (!y.logprobs)
          y.logprobs = Object.assign({}, f);
        else {
          const { content: T, refusal: M, ...O } = f;
          Object.assign(y.logprobs, O), T && ((r = y.logprobs).content ?? (r.content = []), y.logprobs.content.push(...T)), M && ((s = y.logprobs).refusal ?? (s.refusal = []), y.logprobs.refusal.push(...M));
        }
      if (u && (y.finish_reason = u, d(this, oe, "f") && Rs(d(this, oe, "f")))) {
        if (u === "length")
          throw new ls();
        if (u === "content_filter")
          throw new cs();
      }
      if (Object.assign(y, m), !h)
        continue;
      const { content: x, refusal: _, function_call: b, role: A, tool_calls: $, ...P } = h;
      if (Object.assign(y.message, P), _ && (y.message.refusal = (y.message.refusal || "") + _), A && (y.message.role = A), b && (y.message.function_call ? (b.name && (y.message.function_call.name = b.name), b.arguments && ((i = y.message.function_call).arguments ?? (i.arguments = ""), y.message.function_call.arguments += b.arguments)) : y.message.function_call = b), x && (y.message.content = (y.message.content || "") + x, !y.message.refusal && d(this, N, "m", hn).call(this) && (y.message.parsed = vr(y.message.content))), $) {
        y.message.tool_calls || (y.message.tool_calls = []);
        for (const { index: T, id: M, type: O, function: D, ...g } of $) {
          const L = (a = y.message.tool_calls)[T] ?? (a[T] = {});
          Object.assign(L, g), M && (L.id = M), O && (L.type = O), D && (L.function ?? (L.function = { name: D.name ?? "", arguments: "" })), D?.name && (L.function.name = D.name), D?.arguments && (L.function.arguments += D.arguments, So(d(this, oe, "f"), L) && (L.function.parsed_arguments = vr(L.function.arguments)));
        }
      }
    }
    return o;
  }, Symbol.asyncIterator)]() {
    const e = [], t = [];
    let r = !1;
    return this.on("chunk", (s) => {
      const i = t.shift();
      i ? i.resolve(s) : e.push(s);
    }), this.on("end", () => {
      r = !0;
      for (const s of t)
        s.resolve(void 0);
      t.length = 0;
    }), this.on("abort", (s) => {
      r = !0;
      for (const i of t)
        i.reject(s);
      t.length = 0;
    }), this.on("error", (s) => {
      r = !0;
      for (const i of t)
        i.reject(s);
      t.length = 0;
    }), {
      next: async () => e.length ? { value: e.shift(), done: !1 } : r ? { value: void 0, done: !0 } : new Promise((i, a) => t.push({ resolve: i, reject: a })).then((i) => i ? { value: i, done: !1 } : { value: void 0, done: !0 }),
      return: async () => (this.abort(), { value: void 0, done: !0 })
    };
  }
  toReadableStream() {
    return new re(this[Symbol.asyncIterator].bind(this), this.controller).toReadableStream();
  }
}
function Oo(n, e) {
  const { id: t, choices: r, created: s, model: i, system_fingerprint: a, ...o } = n, l = {
    ...o,
    id: t,
    choices: r.map(({ message: c, finish_reason: h, index: u, logprobs: p, ...f }) => {
      if (!h)
        throw new v(`missing finish_reason for choice ${u}`);
      const { content: m = null, function_call: y, tool_calls: x, ..._ } = c, b = c.role;
      if (!b)
        throw new v(`missing role for choice ${u}`);
      if (y) {
        const { arguments: A, name: $ } = y;
        if (A == null)
          throw new v(`missing function_call.arguments for choice ${u}`);
        if (!$)
          throw new v(`missing function_call.name for choice ${u}`);
        return {
          ...f,
          message: {
            content: m,
            function_call: { arguments: A, name: $ },
            role: b,
            refusal: c.refusal ?? null
          },
          finish_reason: h,
          index: u,
          logprobs: p
        };
      }
      return x ? {
        ...f,
        index: u,
        finish_reason: h,
        logprobs: p,
        message: {
          ..._,
          role: b,
          content: m,
          refusal: c.refusal ?? null,
          tool_calls: x.map((A, $) => {
            const { function: P, type: T, id: M, ...O } = A, { arguments: D, name: g, ...L } = P || {};
            if (M == null)
              throw new v(`missing choices[${u}].tool_calls[${$}].id
${pt(n)}`);
            if (T == null)
              throw new v(`missing choices[${u}].tool_calls[${$}].type
${pt(n)}`);
            if (g == null)
              throw new v(`missing choices[${u}].tool_calls[${$}].function.name
${pt(n)}`);
            if (D == null)
              throw new v(`missing choices[${u}].tool_calls[${$}].function.arguments
${pt(n)}`);
            return { ...O, id: M, type: T, function: { ...L, name: g, arguments: D } };
          })
        }
      } : {
        ...f,
        message: { ..._, content: m, role: b, refusal: c.refusal ?? null },
        finish_reason: h,
        index: u,
        logprobs: p
      };
    }),
    created: s,
    model: i,
    object: "chat.completion",
    ...a ? { system_fingerprint: a } : {}
  };
  return ko(l, e);
}
function pt(n) {
  return JSON.stringify(n);
}
class Lt extends nt {
  static fromReadableStream(e) {
    const t = new Lt(null);
    return t._run(() => t._fromReadableStream(e)), t;
  }
  static runTools(e, t, r) {
    const s = new Lt(
      // @ts-expect-error TODO these types are incompatible
      t
    ), i = {
      ...r,
      headers: { ...r?.headers, "X-Stainless-Helper-Method": "runTools" }
    };
    return s._run(() => s._runTools(e, t, i)), s;
  }
}
let Wn = class extends S {
  constructor() {
    super(...arguments), this.messages = new As(this._client);
  }
  create(e, t) {
    return this._client.post("/chat/completions", { body: e, ...t, stream: e.stream ?? !1 });
  }
  /**
   * Get a stored chat completion. Only Chat Completions that have been created with
   * the `store` parameter set to `true` will be returned.
   *
   * @example
   * ```ts
   * const chatCompletion =
   *   await client.chat.completions.retrieve('completion_id');
   * ```
   */
  retrieve(e, t) {
    return this._client.get(w`/chat/completions/${e}`, t);
  }
  /**
   * Modify a stored chat completion. Only Chat Completions that have been created
   * with the `store` parameter set to `true` can be modified. Currently, the only
   * supported modification is to update the `metadata` field.
   *
   * @example
   * ```ts
   * const chatCompletion = await client.chat.completions.update(
   *   'completion_id',
   *   { metadata: { foo: 'string' } },
   * );
   * ```
   */
  update(e, t, r) {
    return this._client.post(w`/chat/completions/${e}`, { body: t, ...r });
  }
  /**
   * List stored Chat Completions. Only Chat Completions that have been stored with
   * the `store` parameter set to `true` will be returned.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const chatCompletion of client.chat.completions.list()) {
   *   // ...
   * }
   * ```
   */
  list(e = {}, t) {
    return this._client.getAPIList("/chat/completions", F, { query: e, ...t });
  }
  /**
   * Delete a stored chat completion. Only Chat Completions that have been created
   * with the `store` parameter set to `true` can be deleted.
   *
   * @example
   * ```ts
   * const chatCompletionDeleted =
   *   await client.chat.completions.delete('completion_id');
   * ```
   */
  delete(e, t) {
    return this._client.delete(w`/chat/completions/${e}`, t);
  }
  parse(e, t) {
    return vo(e.tools), this._client.chat.completions.create(e, {
      ...t,
      headers: {
        ...t?.headers,
        "X-Stainless-Helper-Method": "chat.completions.parse"
      }
    })._thenUnwrap((r) => jn(r, e));
  }
  runTools(e, t) {
    return e.stream ? Lt.runTools(this._client, e, t) : Un.runTools(this._client, e, t);
  }
  /**
   * Creates a chat completion stream
   */
  stream(e, t) {
    return nt.createChatCompletion(this._client, e, t);
  }
};
Wn.Messages = As;
class zn extends S {
  constructor() {
    super(...arguments), this.completions = new Wn(this._client);
  }
}
zn.Completions = Wn;
const Ks = /* @__PURE__ */ Symbol("brand.privateNullableHeaders");
function* Mo(n) {
  if (!n)
    return;
  if (Ks in n) {
    const { values: r, nulls: s } = n;
    yield* r.entries();
    for (const i of s)
      yield [i, null];
    return;
  }
  let e = !1, t;
  n instanceof Headers ? t = n.entries() : ur(n) ? t = n : (e = !0, t = Object.entries(n ?? {}));
  for (let r of t) {
    const s = r[0];
    if (typeof s != "string")
      throw new TypeError("expected header name to be a string");
    const i = ur(r[1]) ? r[1] : [r[1]];
    let a = !1;
    for (const o of i)
      o !== void 0 && (e && !a && (a = !0, yield [s, null]), yield [s, o]);
  }
}
const k = (n) => {
  const e = new Headers(), t = /* @__PURE__ */ new Set();
  for (const r of n) {
    const s = /* @__PURE__ */ new Set();
    for (const [i, a] of Mo(r)) {
      const o = i.toLowerCase();
      s.has(o) || (e.delete(i), s.add(o)), a === null ? (e.delete(i), t.add(o)) : (e.append(i, a), t.delete(o));
    }
  }
  return { [Ks]: !0, values: e, nulls: t };
};
class Xs extends S {
  /**
   * Generates audio from the input text.
   *
   * Returns the audio file content, or a stream of audio events.
   *
   * @example
   * ```ts
   * const speech = await client.audio.speech.create({
   *   input: 'input',
   *   model: 'string',
   *   voice: 'string',
   * });
   *
   * const content = await speech.blob();
   * console.log(content);
   * ```
   */
  create(e, t) {
    return this._client.post("/audio/speech", {
      body: e,
      ...t,
      headers: k([{ Accept: "application/octet-stream" }, t?.headers]),
      __binaryResponse: !0
    });
  }
}
class Vs extends S {
  create(e, t) {
    return this._client.post("/audio/transcriptions", se({
      body: e,
      ...t,
      stream: e.stream ?? !1,
      __metadata: { model: e.model }
    }, this._client));
  }
}
class Qs extends S {
  create(e, t) {
    return this._client.post("/audio/translations", se({ body: e, ...t, __metadata: { model: e.model } }, this._client));
  }
}
class lt extends S {
  constructor() {
    super(...arguments), this.transcriptions = new Vs(this._client), this.translations = new Qs(this._client), this.speech = new Xs(this._client);
  }
}
lt.Transcriptions = Vs;
lt.Translations = Qs;
lt.Speech = Xs;
class Gs extends S {
  /**
   * Creates and executes a batch from an uploaded file of requests
   */
  create(e, t) {
    return this._client.post("/batches", { body: e, ...t });
  }
  /**
   * Retrieves a batch.
   */
  retrieve(e, t) {
    return this._client.get(w`/batches/${e}`, t);
  }
  /**
   * List your organization's batches.
   */
  list(e = {}, t) {
    return this._client.getAPIList("/batches", F, { query: e, ...t });
  }
  /**
   * Cancels an in-progress batch. The batch will be in status `cancelling` for up to
   * 10 minutes, before changing to `cancelled`, where it will have partial results
   * (if any) available in the output file.
   */
  cancel(e, t) {
    return this._client.post(w`/batches/${e}/cancel`, t);
  }
}
class Ys extends S {
  /**
   * Create an assistant with a model and instructions.
   *
   * @deprecated
   */
  create(e, t) {
    return this._client.post("/assistants", {
      body: e,
      ...t,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, t?.headers])
    });
  }
  /**
   * Retrieves an assistant.
   *
   * @deprecated
   */
  retrieve(e, t) {
    return this._client.get(w`/assistants/${e}`, {
      ...t,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, t?.headers])
    });
  }
  /**
   * Modifies an assistant.
   *
   * @deprecated
   */
  update(e, t, r) {
    return this._client.post(w`/assistants/${e}`, {
      body: t,
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * Returns a list of assistants.
   *
   * @deprecated
   */
  list(e = {}, t) {
    return this._client.getAPIList("/assistants", F, {
      query: e,
      ...t,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, t?.headers])
    });
  }
  /**
   * Delete an assistant.
   *
   * @deprecated
   */
  delete(e, t) {
    return this._client.delete(w`/assistants/${e}`, {
      ...t,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, t?.headers])
    });
  }
}
let Zs = class extends S {
  /**
   * Create an ephemeral API token for use in client-side applications with the
   * Realtime API. Can be configured with the same session parameters as the
   * `session.update` client event.
   *
   * It responds with a session object, plus a `client_secret` key which contains a
   * usable ephemeral API token that can be used to authenticate browser clients for
   * the Realtime API.
   *
   * @example
   * ```ts
   * const session =
   *   await client.beta.realtime.sessions.create();
   * ```
   */
  create(e, t) {
    return this._client.post("/realtime/sessions", {
      body: e,
      ...t,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, t?.headers])
    });
  }
};
class ei extends S {
  /**
   * Create an ephemeral API token for use in client-side applications with the
   * Realtime API specifically for realtime transcriptions. Can be configured with
   * the same session parameters as the `transcription_session.update` client event.
   *
   * It responds with a session object, plus a `client_secret` key which contains a
   * usable ephemeral API token that can be used to authenticate browser clients for
   * the Realtime API.
   *
   * @example
   * ```ts
   * const transcriptionSession =
   *   await client.beta.realtime.transcriptionSessions.create();
   * ```
   */
  create(e, t) {
    return this._client.post("/realtime/transcription_sessions", {
      body: e,
      ...t,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, t?.headers])
    });
  }
}
let Jt = class extends S {
  constructor() {
    super(...arguments), this.sessions = new Zs(this._client), this.transcriptionSessions = new ei(this._client);
  }
};
Jt.Sessions = Zs;
Jt.TranscriptionSessions = ei;
class ti extends S {
  /**
   * Create a ChatKit session.
   *
   * @example
   * ```ts
   * const chatSession =
   *   await client.beta.chatkit.sessions.create({
   *     user: 'x',
   *     workflow: { id: 'id' },
   *   });
   * ```
   */
  create(e, t) {
    return this._client.post("/chatkit/sessions", {
      body: e,
      ...t,
      headers: k([{ "OpenAI-Beta": "chatkit_beta=v1" }, t?.headers])
    });
  }
  /**
   * Cancel an active ChatKit session and return its most recent metadata.
   *
   * Cancelling prevents new requests from using the issued client secret.
   *
   * @example
   * ```ts
   * const chatSession =
   *   await client.beta.chatkit.sessions.cancel('cksess_123');
   * ```
   */
  cancel(e, t) {
    return this._client.post(w`/chatkit/sessions/${e}/cancel`, {
      ...t,
      headers: k([{ "OpenAI-Beta": "chatkit_beta=v1" }, t?.headers])
    });
  }
}
let ni = class extends S {
  /**
   * Retrieve a ChatKit thread by its identifier.
   *
   * @example
   * ```ts
   * const chatkitThread =
   *   await client.beta.chatkit.threads.retrieve('cthr_123');
   * ```
   */
  retrieve(e, t) {
    return this._client.get(w`/chatkit/threads/${e}`, {
      ...t,
      headers: k([{ "OpenAI-Beta": "chatkit_beta=v1" }, t?.headers])
    });
  }
  /**
   * List ChatKit threads with optional pagination and user filters.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const chatkitThread of client.beta.chatkit.threads.list()) {
   *   // ...
   * }
   * ```
   */
  list(e = {}, t) {
    return this._client.getAPIList("/chatkit/threads", tt, {
      query: e,
      ...t,
      headers: k([{ "OpenAI-Beta": "chatkit_beta=v1" }, t?.headers])
    });
  }
  /**
   * Delete a ChatKit thread along with its items and stored attachments.
   *
   * @example
   * ```ts
   * const thread = await client.beta.chatkit.threads.delete(
   *   'cthr_123',
   * );
   * ```
   */
  delete(e, t) {
    return this._client.delete(w`/chatkit/threads/${e}`, {
      ...t,
      headers: k([{ "OpenAI-Beta": "chatkit_beta=v1" }, t?.headers])
    });
  }
  /**
   * List items that belong to a ChatKit thread.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const thread of client.beta.chatkit.threads.listItems(
   *   'cthr_123',
   * )) {
   *   // ...
   * }
   * ```
   */
  listItems(e, t = {}, r) {
    return this._client.getAPIList(w`/chatkit/threads/${e}/items`, tt, { query: t, ...r, headers: k([{ "OpenAI-Beta": "chatkit_beta=v1" }, r?.headers]) });
  }
};
class Kt extends S {
  constructor() {
    super(...arguments), this.sessions = new ti(this._client), this.threads = new ni(this._client);
  }
}
Kt.Sessions = ti;
Kt.Threads = ni;
class ri extends S {
  /**
   * Create a message.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  create(e, t, r) {
    return this._client.post(w`/threads/${e}/messages`, {
      body: t,
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * Retrieve a message.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  retrieve(e, t, r) {
    const { thread_id: s } = t;
    return this._client.get(w`/threads/${s}/messages/${e}`, {
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * Modifies a message.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  update(e, t, r) {
    const { thread_id: s, ...i } = t;
    return this._client.post(w`/threads/${s}/messages/${e}`, {
      body: i,
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * Returns a list of messages for a given thread.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  list(e, t = {}, r) {
    return this._client.getAPIList(w`/threads/${e}/messages`, F, {
      query: t,
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * Deletes a message.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  delete(e, t, r) {
    const { thread_id: s } = t;
    return this._client.delete(w`/threads/${s}/messages/${e}`, {
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
}
class si extends S {
  /**
   * Retrieves a run step.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  retrieve(e, t, r) {
    const { thread_id: s, run_id: i, ...a } = t;
    return this._client.get(w`/threads/${s}/runs/${i}/steps/${e}`, {
      query: a,
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * Returns a list of run steps belonging to a run.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  list(e, t, r) {
    const { thread_id: s, ...i } = t;
    return this._client.getAPIList(w`/threads/${s}/runs/${e}/steps`, F, {
      query: i,
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
}
const Do = (n) => {
  if (typeof Buffer < "u") {
    const e = Buffer.from(n, "base64");
    return Array.from(new Float32Array(e.buffer, e.byteOffset, e.length / Float32Array.BYTES_PER_ELEMENT));
  } else {
    const e = atob(n), t = e.length, r = new Uint8Array(t);
    for (let s = 0; s < t; s++)
      r[s] = e.charCodeAt(s);
    return Array.from(new Float32Array(r.buffer));
  }
}, Pe = (n) => {
  if (typeof globalThis.process < "u")
    return globalThis.process.env?.[n]?.trim() ?? void 0;
  if (typeof globalThis.Deno < "u")
    return globalThis.Deno.env?.get?.(n)?.trim();
};
var W, Ce, In, ne, Ct, ee, Se, Fe, ke, Ft, G, St, vt, Ye, Ve, Qe, Rr, Ir, $r, Er, Pr, Tr, Or;
class Ze extends Bn {
  constructor() {
    super(...arguments), W.add(this), In.set(this, []), ne.set(this, {}), Ct.set(this, {}), ee.set(this, void 0), Se.set(this, void 0), Fe.set(this, void 0), ke.set(this, void 0), Ft.set(this, void 0), G.set(this, void 0), St.set(this, void 0), vt.set(this, void 0), Ye.set(this, void 0);
  }
  [(In = /* @__PURE__ */ new WeakMap(), ne = /* @__PURE__ */ new WeakMap(), Ct = /* @__PURE__ */ new WeakMap(), ee = /* @__PURE__ */ new WeakMap(), Se = /* @__PURE__ */ new WeakMap(), Fe = /* @__PURE__ */ new WeakMap(), ke = /* @__PURE__ */ new WeakMap(), Ft = /* @__PURE__ */ new WeakMap(), G = /* @__PURE__ */ new WeakMap(), St = /* @__PURE__ */ new WeakMap(), vt = /* @__PURE__ */ new WeakMap(), Ye = /* @__PURE__ */ new WeakMap(), W = /* @__PURE__ */ new WeakSet(), Symbol.asyncIterator)]() {
    const e = [], t = [];
    let r = !1;
    return this.on("event", (s) => {
      const i = t.shift();
      i ? i.resolve(s) : e.push(s);
    }), this.on("end", () => {
      r = !0;
      for (const s of t)
        s.resolve(void 0);
      t.length = 0;
    }), this.on("abort", (s) => {
      r = !0;
      for (const i of t)
        i.reject(s);
      t.length = 0;
    }), this.on("error", (s) => {
      r = !0;
      for (const i of t)
        i.reject(s);
      t.length = 0;
    }), {
      next: async () => e.length ? { value: e.shift(), done: !1 } : r ? { value: void 0, done: !0 } : new Promise((i, a) => t.push({ resolve: i, reject: a })).then((i) => i ? { value: i, done: !1 } : { value: void 0, done: !0 }),
      return: async () => (this.abort(), { value: void 0, done: !0 })
    };
  }
  static fromReadableStream(e) {
    const t = new Ce();
    return t._run(() => t._fromReadableStream(e)), t;
  }
  async _fromReadableStream(e, t) {
    const r = t?.signal;
    r && (r.aborted && this.controller.abort(), r.addEventListener("abort", () => this.controller.abort())), this._connected();
    const s = re.fromReadableStream(e, this.controller);
    for await (const i of s)
      d(this, W, "m", Ve).call(this, i);
    if (s.controller.signal?.aborted)
      throw new Y();
    return this._addRun(d(this, W, "m", Qe).call(this));
  }
  toReadableStream() {
    return new re(this[Symbol.asyncIterator].bind(this), this.controller).toReadableStream();
  }
  static createToolAssistantStream(e, t, r, s) {
    const i = new Ce();
    return i._run(() => i._runToolAssistantStream(e, t, r, {
      ...s,
      headers: { ...s?.headers, "X-Stainless-Helper-Method": "stream" }
    })), i;
  }
  async _createToolAssistantStream(e, t, r, s) {
    const i = s?.signal;
    i && (i.aborted && this.controller.abort(), i.addEventListener("abort", () => this.controller.abort()));
    const a = { ...r, stream: !0 }, o = await e.submitToolOutputs(t, a, {
      ...s,
      signal: this.controller.signal
    });
    this._connected();
    for await (const l of o)
      d(this, W, "m", Ve).call(this, l);
    if (o.controller.signal?.aborted)
      throw new Y();
    return this._addRun(d(this, W, "m", Qe).call(this));
  }
  static createThreadAssistantStream(e, t, r) {
    const s = new Ce();
    return s._run(() => s._threadAssistantStream(e, t, {
      ...r,
      headers: { ...r?.headers, "X-Stainless-Helper-Method": "stream" }
    })), s;
  }
  static createAssistantStream(e, t, r, s) {
    const i = new Ce();
    return i._run(() => i._runAssistantStream(e, t, r, {
      ...s,
      headers: { ...s?.headers, "X-Stainless-Helper-Method": "stream" }
    })), i;
  }
  currentEvent() {
    return d(this, St, "f");
  }
  currentRun() {
    return d(this, vt, "f");
  }
  currentMessageSnapshot() {
    return d(this, ee, "f");
  }
  currentRunStepSnapshot() {
    return d(this, Ye, "f");
  }
  async finalRunSteps() {
    return await this.done(), Object.values(d(this, ne, "f"));
  }
  async finalMessages() {
    return await this.done(), Object.values(d(this, Ct, "f"));
  }
  async finalRun() {
    if (await this.done(), !d(this, Se, "f"))
      throw Error("Final run was not received.");
    return d(this, Se, "f");
  }
  async _createThreadAssistantStream(e, t, r) {
    const s = r?.signal;
    s && (s.aborted && this.controller.abort(), s.addEventListener("abort", () => this.controller.abort()));
    const i = { ...t, stream: !0 }, a = await e.createAndRun(i, { ...r, signal: this.controller.signal });
    this._connected();
    for await (const o of a)
      d(this, W, "m", Ve).call(this, o);
    if (a.controller.signal?.aborted)
      throw new Y();
    return this._addRun(d(this, W, "m", Qe).call(this));
  }
  async _createAssistantStream(e, t, r, s) {
    const i = s?.signal;
    i && (i.aborted && this.controller.abort(), i.addEventListener("abort", () => this.controller.abort()));
    const a = { ...r, stream: !0 }, o = await e.create(t, a, { ...s, signal: this.controller.signal });
    this._connected();
    for await (const l of o)
      d(this, W, "m", Ve).call(this, l);
    if (o.controller.signal?.aborted)
      throw new Y();
    return this._addRun(d(this, W, "m", Qe).call(this));
  }
  static accumulateDelta(e, t) {
    for (const [r, s] of Object.entries(t)) {
      if (!e.hasOwnProperty(r)) {
        e[r] = s;
        continue;
      }
      let i = e[r];
      if (i == null) {
        e[r] = s;
        continue;
      }
      if (r === "index" || r === "type") {
        e[r] = s;
        continue;
      }
      if (typeof i == "string" && typeof s == "string")
        i += s;
      else if (typeof i == "number" && typeof s == "number")
        i += s;
      else if (rn(i) && rn(s))
        i = this.accumulateDelta(i, s);
      else if (Array.isArray(i) && Array.isArray(s)) {
        if (i.every((a) => typeof a == "string" || typeof a == "number")) {
          i.push(...s);
          continue;
        }
        for (const a of s) {
          if (!rn(a))
            throw new Error(`Expected array delta entry to be an object but got: ${a}`);
          const o = a.index;
          if (o == null)
            throw console.error(a), new Error("Expected array delta entry to have an `index` property");
          if (typeof o != "number")
            throw new Error(`Expected array delta entry \`index\` property to be a number but got ${o}`);
          const l = i[o];
          l == null ? i.push(a) : i[o] = this.accumulateDelta(l, a);
        }
        continue;
      } else
        throw Error(`Unhandled record type: ${r}, deltaValue: ${s}, accValue: ${i}`);
      e[r] = i;
    }
    return e;
  }
  _addRun(e) {
    return e;
  }
  async _threadAssistantStream(e, t, r) {
    return await this._createThreadAssistantStream(t, e, r);
  }
  async _runAssistantStream(e, t, r, s) {
    return await this._createAssistantStream(t, e, r, s);
  }
  async _runToolAssistantStream(e, t, r, s) {
    return await this._createToolAssistantStream(t, e, r, s);
  }
}
Ce = Ze, Ve = function(e) {
  if (!this.ended)
    switch (I(this, St, e), d(this, W, "m", $r).call(this, e), e.event) {
      case "thread.created":
        break;
      case "thread.run.created":
      case "thread.run.queued":
      case "thread.run.in_progress":
      case "thread.run.requires_action":
      case "thread.run.completed":
      case "thread.run.incomplete":
      case "thread.run.failed":
      case "thread.run.cancelling":
      case "thread.run.cancelled":
      case "thread.run.expired":
        d(this, W, "m", Or).call(this, e);
        break;
      case "thread.run.step.created":
      case "thread.run.step.in_progress":
      case "thread.run.step.delta":
      case "thread.run.step.completed":
      case "thread.run.step.failed":
      case "thread.run.step.cancelled":
      case "thread.run.step.expired":
        d(this, W, "m", Ir).call(this, e);
        break;
      case "thread.message.created":
      case "thread.message.in_progress":
      case "thread.message.delta":
      case "thread.message.completed":
      case "thread.message.incomplete":
        d(this, W, "m", Rr).call(this, e);
        break;
      case "error":
        throw new Error("Encountered an error event in event processing - errors should be processed earlier");
    }
}, Qe = function() {
  if (this.ended)
    throw new v("stream has ended, this shouldn't happen");
  if (!d(this, Se, "f"))
    throw Error("Final run has not been received");
  return d(this, Se, "f");
}, Rr = function(e) {
  const [t, r] = d(this, W, "m", Pr).call(this, e, d(this, ee, "f"));
  I(this, ee, t), d(this, Ct, "f")[t.id] = t;
  for (const s of r) {
    const i = t.content[s.index];
    i?.type == "text" && this._emit("textCreated", i.text);
  }
  switch (e.event) {
    case "thread.message.created":
      this._emit("messageCreated", e.data);
      break;
    case "thread.message.in_progress":
      break;
    case "thread.message.delta":
      if (this._emit("messageDelta", e.data.delta, t), e.data.delta.content)
        for (const s of e.data.delta.content) {
          if (s.type == "text" && s.text) {
            let i = s.text, a = t.content[s.index];
            if (a && a.type == "text")
              this._emit("textDelta", i, a.text);
            else
              throw Error("The snapshot associated with this text delta is not text or missing");
          }
          if (s.index != d(this, Fe, "f")) {
            if (d(this, ke, "f"))
              switch (d(this, ke, "f").type) {
                case "text":
                  this._emit("textDone", d(this, ke, "f").text, d(this, ee, "f"));
                  break;
                case "image_file":
                  this._emit("imageFileDone", d(this, ke, "f").image_file, d(this, ee, "f"));
                  break;
              }
            I(this, Fe, s.index);
          }
          I(this, ke, t.content[s.index]);
        }
      break;
    case "thread.message.completed":
    case "thread.message.incomplete":
      if (d(this, Fe, "f") !== void 0) {
        const s = e.data.content[d(this, Fe, "f")];
        if (s)
          switch (s.type) {
            case "image_file":
              this._emit("imageFileDone", s.image_file, d(this, ee, "f"));
              break;
            case "text":
              this._emit("textDone", s.text, d(this, ee, "f"));
              break;
          }
      }
      d(this, ee, "f") && this._emit("messageDone", e.data), I(this, ee, void 0);
  }
}, Ir = function(e) {
  const t = d(this, W, "m", Er).call(this, e);
  switch (I(this, Ye, t), e.event) {
    case "thread.run.step.created":
      this._emit("runStepCreated", e.data);
      break;
    case "thread.run.step.delta":
      const r = e.data.delta;
      if (r.step_details && r.step_details.type == "tool_calls" && r.step_details.tool_calls && t.step_details.type == "tool_calls")
        for (const i of r.step_details.tool_calls)
          i.index == d(this, Ft, "f") ? this._emit("toolCallDelta", i, t.step_details.tool_calls[i.index]) : (d(this, G, "f") && this._emit("toolCallDone", d(this, G, "f")), I(this, Ft, i.index), I(this, G, t.step_details.tool_calls[i.index]), d(this, G, "f") && this._emit("toolCallCreated", d(this, G, "f")));
      this._emit("runStepDelta", e.data.delta, t);
      break;
    case "thread.run.step.completed":
    case "thread.run.step.failed":
    case "thread.run.step.cancelled":
    case "thread.run.step.expired":
      I(this, Ye, void 0), e.data.step_details.type == "tool_calls" && d(this, G, "f") && (this._emit("toolCallDone", d(this, G, "f")), I(this, G, void 0)), this._emit("runStepDone", e.data, t);
      break;
  }
}, $r = function(e) {
  d(this, In, "f").push(e), this._emit("event", e);
}, Er = function(e) {
  switch (e.event) {
    case "thread.run.step.created":
      return d(this, ne, "f")[e.data.id] = e.data, e.data;
    case "thread.run.step.delta":
      let t = d(this, ne, "f")[e.data.id];
      if (!t)
        throw Error("Received a RunStepDelta before creation of a snapshot");
      let r = e.data;
      if (r.delta) {
        const s = Ce.accumulateDelta(t, r.delta);
        d(this, ne, "f")[e.data.id] = s;
      }
      return d(this, ne, "f")[e.data.id];
    case "thread.run.step.completed":
    case "thread.run.step.failed":
    case "thread.run.step.cancelled":
    case "thread.run.step.expired":
    case "thread.run.step.in_progress":
      d(this, ne, "f")[e.data.id] = e.data;
      break;
  }
  if (d(this, ne, "f")[e.data.id])
    return d(this, ne, "f")[e.data.id];
  throw new Error("No snapshot available");
}, Pr = function(e, t) {
  let r = [];
  switch (e.event) {
    case "thread.message.created":
      return [e.data, r];
    case "thread.message.delta":
      if (!t)
        throw Error("Received a delta with no existing snapshot (there should be one from message creation)");
      let s = e.data;
      if (s.delta.content)
        for (const i of s.delta.content)
          if (i.index in t.content) {
            let a = t.content[i.index];
            t.content[i.index] = d(this, W, "m", Tr).call(this, i, a);
          } else
            t.content[i.index] = i, r.push(i);
      return [t, r];
    case "thread.message.in_progress":
    case "thread.message.completed":
    case "thread.message.incomplete":
      if (t)
        return [t, r];
      throw Error("Received thread message event with no existing snapshot");
  }
  throw Error("Tried to accumulate a non-message event");
}, Tr = function(e, t) {
  return Ce.accumulateDelta(t, e);
}, Or = function(e) {
  switch (I(this, vt, e.data), e.event) {
    case "thread.run.created":
      break;
    case "thread.run.queued":
      break;
    case "thread.run.in_progress":
      break;
    case "thread.run.requires_action":
    case "thread.run.cancelled":
    case "thread.run.failed":
    case "thread.run.completed":
    case "thread.run.expired":
    case "thread.run.incomplete":
      I(this, Se, e.data), d(this, G, "f") && (this._emit("toolCallDone", d(this, G, "f")), I(this, G, void 0));
      break;
  }
};
let qn = class extends S {
  constructor() {
    super(...arguments), this.steps = new si(this._client);
  }
  create(e, t, r) {
    const { include: s, ...i } = t;
    return this._client.post(w`/threads/${e}/runs`, {
      query: { include: s },
      body: i,
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers]),
      stream: t.stream ?? !1,
      __synthesizeEventData: !0
    });
  }
  /**
   * Retrieves a run.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  retrieve(e, t, r) {
    const { thread_id: s } = t;
    return this._client.get(w`/threads/${s}/runs/${e}`, {
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * Modifies a run.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  update(e, t, r) {
    const { thread_id: s, ...i } = t;
    return this._client.post(w`/threads/${s}/runs/${e}`, {
      body: i,
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * Returns a list of runs belonging to a thread.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  list(e, t = {}, r) {
    return this._client.getAPIList(w`/threads/${e}/runs`, F, {
      query: t,
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * Cancels a run that is `in_progress`.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  cancel(e, t, r) {
    const { thread_id: s } = t;
    return this._client.post(w`/threads/${s}/runs/${e}/cancel`, {
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * A helper to create a run an poll for a terminal state. More information on Run
   * lifecycles can be found here:
   * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
   */
  async createAndPoll(e, t, r) {
    const s = await this.create(e, t, r);
    return await this.poll(s.id, { thread_id: e }, r);
  }
  /**
   * Create a Run stream
   *
   * @deprecated use `stream` instead
   */
  createAndStream(e, t, r) {
    return Ze.createAssistantStream(e, this._client.beta.threads.runs, t, r);
  }
  /**
   * A helper to poll a run status until it reaches a terminal state. More
   * information on Run lifecycles can be found here:
   * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
   */
  async poll(e, t, r) {
    const s = k([
      r?.headers,
      {
        "X-Stainless-Poll-Helper": "true",
        "X-Stainless-Custom-Poll-Interval": r?.pollIntervalMs?.toString() ?? void 0
      }
    ]);
    for (; ; ) {
      const { data: i, response: a } = await this.retrieve(e, t, {
        ...r,
        headers: { ...r?.headers, ...s }
      }).withResponse();
      switch (i.status) {
        //If we are in any sort of intermediate state we poll
        case "queued":
        case "in_progress":
        case "cancelling":
          let o = 5e3;
          if (r?.pollIntervalMs)
            o = r.pollIntervalMs;
          else {
            const l = a.headers.get("openai-poll-after-ms");
            if (l) {
              const c = parseInt(l);
              isNaN(c) || (o = c);
            }
          }
          await at(o);
          break;
        //We return the run in any terminal state.
        case "requires_action":
        case "incomplete":
        case "cancelled":
        case "completed":
        case "failed":
        case "expired":
          return i;
      }
    }
  }
  /**
   * Create a Run stream
   */
  stream(e, t, r) {
    return Ze.createAssistantStream(e, this._client.beta.threads.runs, t, r);
  }
  submitToolOutputs(e, t, r) {
    const { thread_id: s, ...i } = t;
    return this._client.post(w`/threads/${s}/runs/${e}/submit_tool_outputs`, {
      body: i,
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers]),
      stream: t.stream ?? !1,
      __synthesizeEventData: !0
    });
  }
  /**
   * A helper to submit a tool output to a run and poll for a terminal run state.
   * More information on Run lifecycles can be found here:
   * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
   */
  async submitToolOutputsAndPoll(e, t, r) {
    const s = await this.submitToolOutputs(e, t, r);
    return await this.poll(s.id, t, r);
  }
  /**
   * Submit the tool outputs from a previous run and stream the run to a terminal
   * state. More information on Run lifecycles can be found here:
   * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
   */
  submitToolOutputsStream(e, t, r) {
    return Ze.createToolAssistantStream(e, this._client.beta.threads.runs, t, r);
  }
};
qn.Steps = si;
class Xt extends S {
  constructor() {
    super(...arguments), this.runs = new qn(this._client), this.messages = new ri(this._client);
  }
  /**
   * Create a thread.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  create(e = {}, t) {
    return this._client.post("/threads", {
      body: e,
      ...t,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, t?.headers])
    });
  }
  /**
   * Retrieves a thread.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  retrieve(e, t) {
    return this._client.get(w`/threads/${e}`, {
      ...t,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, t?.headers])
    });
  }
  /**
   * Modifies a thread.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  update(e, t, r) {
    return this._client.post(w`/threads/${e}`, {
      body: t,
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * Delete a thread.
   *
   * @deprecated The Assistants API is deprecated in favor of the Responses API
   */
  delete(e, t) {
    return this._client.delete(w`/threads/${e}`, {
      ...t,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, t?.headers])
    });
  }
  createAndRun(e, t) {
    return this._client.post("/threads/runs", {
      body: e,
      ...t,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, t?.headers]),
      stream: e.stream ?? !1,
      __synthesizeEventData: !0
    });
  }
  /**
   * A helper to create a thread, start a run and then poll for a terminal state.
   * More information on Run lifecycles can be found here:
   * https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps
   */
  async createAndRunPoll(e, t) {
    const r = await this.createAndRun(e, t);
    return await this.runs.poll(r.id, { thread_id: r.thread_id }, t);
  }
  /**
   * Create a thread and stream the run back
   */
  createAndRunStream(e, t) {
    return Ze.createThreadAssistantStream(e, this._client.beta.threads, t);
  }
}
Xt.Runs = qn;
Xt.Messages = ri;
class je extends S {
  constructor() {
    super(...arguments), this.realtime = new Jt(this._client), this.chatkit = new Kt(this._client), this.assistants = new Ys(this._client), this.threads = new Xt(this._client);
  }
}
je.Realtime = Jt;
je.ChatKit = Kt;
je.Assistants = Ys;
je.Threads = Xt;
class ii extends S {
  create(e, t) {
    return this._client.post("/completions", { body: e, ...t, stream: e.stream ?? !1 });
  }
}
let ai = class extends S {
  /**
   * Retrieve Container File Content
   */
  retrieve(e, t, r) {
    const { container_id: s } = t;
    return this._client.get(w`/containers/${s}/files/${e}/content`, {
      ...r,
      headers: k([{ Accept: "application/binary" }, r?.headers]),
      __binaryResponse: !0
    });
  }
}, Hn = class extends S {
  constructor() {
    super(...arguments), this.content = new ai(this._client);
  }
  /**
   * Create a Container File
   *
   * You can send either a multipart/form-data request with the raw file content, or
   * a JSON request with a file ID.
   */
  create(e, t, r) {
    return this._client.post(w`/containers/${e}/files`, Ht({ body: t, ...r }, this._client));
  }
  /**
   * Retrieve Container File
   */
  retrieve(e, t, r) {
    const { container_id: s } = t;
    return this._client.get(w`/containers/${s}/files/${e}`, r);
  }
  /**
   * List Container files
   */
  list(e, t = {}, r) {
    return this._client.getAPIList(w`/containers/${e}/files`, F, {
      query: t,
      ...r
    });
  }
  /**
   * Delete Container File
   */
  delete(e, t, r) {
    const { container_id: s } = t;
    return this._client.delete(w`/containers/${s}/files/${e}`, {
      ...r,
      headers: k([{ Accept: "*/*" }, r?.headers])
    });
  }
};
Hn.Content = ai;
class Jn extends S {
  constructor() {
    super(...arguments), this.files = new Hn(this._client);
  }
  /**
   * Create Container
   */
  create(e, t) {
    return this._client.post("/containers", { body: e, ...t });
  }
  /**
   * Retrieve Container
   */
  retrieve(e, t) {
    return this._client.get(w`/containers/${e}`, t);
  }
  /**
   * List Containers
   */
  list(e = {}, t) {
    return this._client.getAPIList("/containers", F, { query: e, ...t });
  }
  /**
   * Delete Container
   */
  delete(e, t) {
    return this._client.delete(w`/containers/${e}`, {
      ...t,
      headers: k([{ Accept: "*/*" }, t?.headers])
    });
  }
}
Jn.Files = Hn;
class oi extends S {
  /**
   * Create items in a conversation with the given ID.
   */
  create(e, t, r) {
    const { include: s, ...i } = t;
    return this._client.post(w`/conversations/${e}/items`, {
      query: { include: s },
      body: i,
      ...r
    });
  }
  /**
   * Get a single item from a conversation with the given IDs.
   */
  retrieve(e, t, r) {
    const { conversation_id: s, ...i } = t;
    return this._client.get(w`/conversations/${s}/items/${e}`, { query: i, ...r });
  }
  /**
   * List all items for a conversation with the given ID.
   */
  list(e, t = {}, r) {
    return this._client.getAPIList(w`/conversations/${e}/items`, tt, { query: t, ...r });
  }
  /**
   * Delete an item from a conversation with the given IDs.
   */
  delete(e, t, r) {
    const { conversation_id: s } = t;
    return this._client.delete(w`/conversations/${s}/items/${e}`, r);
  }
}
class Kn extends S {
  constructor() {
    super(...arguments), this.items = new oi(this._client);
  }
  /**
   * Create a conversation.
   */
  create(e = {}, t) {
    return this._client.post("/conversations", { body: e, ...t });
  }
  /**
   * Get a conversation
   */
  retrieve(e, t) {
    return this._client.get(w`/conversations/${e}`, t);
  }
  /**
   * Update a conversation
   */
  update(e, t, r) {
    return this._client.post(w`/conversations/${e}`, { body: t, ...r });
  }
  /**
   * Delete a conversation. Items in the conversation will not be deleted.
   */
  delete(e, t) {
    return this._client.delete(w`/conversations/${e}`, t);
  }
}
Kn.Items = oi;
class li extends S {
  /**
   * Creates an embedding vector representing the input text.
   *
   * @example
   * ```ts
   * const createEmbeddingResponse =
   *   await client.embeddings.create({
   *     input: 'The quick brown fox jumped over the lazy dog',
   *     model: 'text-embedding-3-small',
   *   });
   * ```
   */
  create(e, t) {
    const r = !!e.encoding_format;
    let s = r ? e.encoding_format : "base64";
    r && U(this._client).debug("embeddings/user defined encoding_format:", e.encoding_format);
    const i = this._client.post("/embeddings", {
      body: {
        ...e,
        encoding_format: s
      },
      ...t
    });
    return r ? i : (U(this._client).debug("embeddings/decoding base64 embeddings from base64"), i._thenUnwrap((a) => (a && a.data && a.data.forEach((o) => {
      const l = o.embedding;
      o.embedding = Do(l);
    }), a)));
  }
}
class ci extends S {
  /**
   * Get an evaluation run output item by ID.
   */
  retrieve(e, t, r) {
    const { eval_id: s, run_id: i } = t;
    return this._client.get(w`/evals/${s}/runs/${i}/output_items/${e}`, r);
  }
  /**
   * Get a list of output items for an evaluation run.
   */
  list(e, t, r) {
    const { eval_id: s, ...i } = t;
    return this._client.getAPIList(w`/evals/${s}/runs/${e}/output_items`, F, { query: i, ...r });
  }
}
class Xn extends S {
  constructor() {
    super(...arguments), this.outputItems = new ci(this._client);
  }
  /**
   * Kicks off a new run for a given evaluation, specifying the data source, and what
   * model configuration to use to test. The datasource will be validated against the
   * schema specified in the config of the evaluation.
   */
  create(e, t, r) {
    return this._client.post(w`/evals/${e}/runs`, { body: t, ...r });
  }
  /**
   * Get an evaluation run by ID.
   */
  retrieve(e, t, r) {
    const { eval_id: s } = t;
    return this._client.get(w`/evals/${s}/runs/${e}`, r);
  }
  /**
   * Get a list of runs for an evaluation.
   */
  list(e, t = {}, r) {
    return this._client.getAPIList(w`/evals/${e}/runs`, F, {
      query: t,
      ...r
    });
  }
  /**
   * Delete an eval run.
   */
  delete(e, t, r) {
    const { eval_id: s } = t;
    return this._client.delete(w`/evals/${s}/runs/${e}`, r);
  }
  /**
   * Cancel an ongoing evaluation run.
   */
  cancel(e, t, r) {
    const { eval_id: s } = t;
    return this._client.post(w`/evals/${s}/runs/${e}`, r);
  }
}
Xn.OutputItems = ci;
class Vn extends S {
  constructor() {
    super(...arguments), this.runs = new Xn(this._client);
  }
  /**
   * Create the structure of an evaluation that can be used to test a model's
   * performance. An evaluation is a set of testing criteria and the config for a
   * data source, which dictates the schema of the data used in the evaluation. After
   * creating an evaluation, you can run it on different models and model parameters.
   * We support several types of graders and datasources. For more information, see
   * the [Evals guide](https://platform.openai.com/docs/guides/evals).
   */
  create(e, t) {
    return this._client.post("/evals", { body: e, ...t });
  }
  /**
   * Get an evaluation by ID.
   */
  retrieve(e, t) {
    return this._client.get(w`/evals/${e}`, t);
  }
  /**
   * Update certain properties of an evaluation.
   */
  update(e, t, r) {
    return this._client.post(w`/evals/${e}`, { body: t, ...r });
  }
  /**
   * List evaluations for a project.
   */
  list(e = {}, t) {
    return this._client.getAPIList("/evals", F, { query: e, ...t });
  }
  /**
   * Delete an evaluation.
   */
  delete(e, t) {
    return this._client.delete(w`/evals/${e}`, t);
  }
}
Vn.Runs = Xn;
let ui = class extends S {
  /**
   * Upload a file that can be used across various endpoints. Individual files can be
   * up to 512 MB, and each project can store up to 2.5 TB of files in total. There
   * is no organization-wide storage limit.
   *
   * - The Assistants API supports files up to 2 million tokens and of specific file
   *   types. See the
   *   [Assistants Tools guide](https://platform.openai.com/docs/assistants/tools)
   *   for details.
   * - The Fine-tuning API only supports `.jsonl` files. The input also has certain
   *   required formats for fine-tuning
   *   [chat](https://platform.openai.com/docs/api-reference/fine-tuning/chat-input)
   *   or
   *   [completions](https://platform.openai.com/docs/api-reference/fine-tuning/completions-input)
   *   models.
   * - The Batch API only supports `.jsonl` files up to 200 MB in size. The input
   *   also has a specific required
   *   [format](https://platform.openai.com/docs/api-reference/batch/request-input).
   *
   * Please [contact us](https://help.openai.com/) if you need to increase these
   * storage limits.
   */
  create(e, t) {
    return this._client.post("/files", se({ body: e, ...t }, this._client));
  }
  /**
   * Returns information about a specific file.
   */
  retrieve(e, t) {
    return this._client.get(w`/files/${e}`, t);
  }
  /**
   * Returns a list of files.
   */
  list(e = {}, t) {
    return this._client.getAPIList("/files", F, { query: e, ...t });
  }
  /**
   * Delete a file and remove it from all vector stores.
   */
  delete(e, t) {
    return this._client.delete(w`/files/${e}`, t);
  }
  /**
   * Returns the contents of the specified file.
   */
  content(e, t) {
    return this._client.get(w`/files/${e}/content`, {
      ...t,
      headers: k([{ Accept: "application/binary" }, t?.headers]),
      __binaryResponse: !0
    });
  }
  /**
   * Waits for the given file to be processed, default timeout is 30 mins.
   */
  async waitForProcessing(e, { pollInterval: t = 5e3, maxWait: r = 1800 * 1e3 } = {}) {
    const s = /* @__PURE__ */ new Set(["processed", "error", "deleted"]), i = Date.now();
    let a = await this.retrieve(e);
    for (; !a.status || !s.has(a.status); )
      if (await at(t), a = await this.retrieve(e), Date.now() - i > r)
        throw new Mn({
          message: `Giving up on waiting for file ${e} to finish processing after ${r} milliseconds.`
        });
    return a;
  }
};
class hi extends S {
}
let fi = class extends S {
  /**
   * Run a grader.
   *
   * @example
   * ```ts
   * const response = await client.fineTuning.alpha.graders.run({
   *   grader: {
   *     input: 'input',
   *     name: 'name',
   *     operation: 'eq',
   *     reference: 'reference',
   *     type: 'string_check',
   *   },
   *   model_sample: 'model_sample',
   * });
   * ```
   */
  run(e, t) {
    return this._client.post("/fine_tuning/alpha/graders/run", { body: e, ...t });
  }
  /**
   * Validate a grader.
   *
   * @example
   * ```ts
   * const response =
   *   await client.fineTuning.alpha.graders.validate({
   *     grader: {
   *       input: 'input',
   *       name: 'name',
   *       operation: 'eq',
   *       reference: 'reference',
   *       type: 'string_check',
   *     },
   *   });
   * ```
   */
  validate(e, t) {
    return this._client.post("/fine_tuning/alpha/graders/validate", { body: e, ...t });
  }
};
class Qn extends S {
  constructor() {
    super(...arguments), this.graders = new fi(this._client);
  }
}
Qn.Graders = fi;
class di extends S {
  /**
   * **NOTE:** Calling this endpoint requires an [admin API key](../admin-api-keys).
   *
   * This enables organization owners to share fine-tuned models with other projects
   * in their organization.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const permissionCreateResponse of client.fineTuning.checkpoints.permissions.create(
   *   'ft:gpt-4o-mini-2024-07-18:org:weather:B7R9VjQd',
   *   { project_ids: ['string'] },
   * )) {
   *   // ...
   * }
   * ```
   */
  create(e, t, r) {
    return this._client.getAPIList(w`/fine_tuning/checkpoints/${e}/permissions`, qt, { body: t, method: "post", ...r });
  }
  /**
   * **NOTE:** This endpoint requires an [admin API key](../admin-api-keys).
   *
   * Organization owners can use this endpoint to view all permissions for a
   * fine-tuned model checkpoint.
   *
   * @deprecated Retrieve is deprecated. Please swap to the paginated list method instead.
   */
  retrieve(e, t = {}, r) {
    return this._client.get(w`/fine_tuning/checkpoints/${e}/permissions`, {
      query: t,
      ...r
    });
  }
  /**
   * **NOTE:** This endpoint requires an [admin API key](../admin-api-keys).
   *
   * Organization owners can use this endpoint to view all permissions for a
   * fine-tuned model checkpoint.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const permissionListResponse of client.fineTuning.checkpoints.permissions.list(
   *   'ft-AF1WoRqd3aJAHsqc9NY7iL8F',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(e, t = {}, r) {
    return this._client.getAPIList(w`/fine_tuning/checkpoints/${e}/permissions`, tt, { query: t, ...r });
  }
  /**
   * **NOTE:** This endpoint requires an [admin API key](../admin-api-keys).
   *
   * Organization owners can use this endpoint to delete a permission for a
   * fine-tuned model checkpoint.
   *
   * @example
   * ```ts
   * const permission =
   *   await client.fineTuning.checkpoints.permissions.delete(
   *     'cp_zc4Q7MP6XxulcVzj4MZdwsAB',
   *     {
   *       fine_tuned_model_checkpoint:
   *         'ft:gpt-4o-mini-2024-07-18:org:weather:B7R9VjQd',
   *     },
   *   );
   * ```
   */
  delete(e, t, r) {
    const { fine_tuned_model_checkpoint: s } = t;
    return this._client.delete(w`/fine_tuning/checkpoints/${s}/permissions/${e}`, r);
  }
}
let Gn = class extends S {
  constructor() {
    super(...arguments), this.permissions = new di(this._client);
  }
};
Gn.Permissions = di;
class pi extends S {
  /**
   * List checkpoints for a fine-tuning job.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const fineTuningJobCheckpoint of client.fineTuning.jobs.checkpoints.list(
   *   'ft-AF1WoRqd3aJAHsqc9NY7iL8F',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(e, t = {}, r) {
    return this._client.getAPIList(w`/fine_tuning/jobs/${e}/checkpoints`, F, { query: t, ...r });
  }
}
class Yn extends S {
  constructor() {
    super(...arguments), this.checkpoints = new pi(this._client);
  }
  /**
   * Creates a fine-tuning job which begins the process of creating a new model from
   * a given dataset.
   *
   * Response includes details of the enqueued job including job status and the name
   * of the fine-tuned models once complete.
   *
   * [Learn more about fine-tuning](https://platform.openai.com/docs/guides/model-optimization)
   *
   * @example
   * ```ts
   * const fineTuningJob = await client.fineTuning.jobs.create({
   *   model: 'gpt-4o-mini',
   *   training_file: 'file-abc123',
   * });
   * ```
   */
  create(e, t) {
    return this._client.post("/fine_tuning/jobs", { body: e, ...t });
  }
  /**
   * Get info about a fine-tuning job.
   *
   * [Learn more about fine-tuning](https://platform.openai.com/docs/guides/model-optimization)
   *
   * @example
   * ```ts
   * const fineTuningJob = await client.fineTuning.jobs.retrieve(
   *   'ft-AF1WoRqd3aJAHsqc9NY7iL8F',
   * );
   * ```
   */
  retrieve(e, t) {
    return this._client.get(w`/fine_tuning/jobs/${e}`, t);
  }
  /**
   * List your organization's fine-tuning jobs
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const fineTuningJob of client.fineTuning.jobs.list()) {
   *   // ...
   * }
   * ```
   */
  list(e = {}, t) {
    return this._client.getAPIList("/fine_tuning/jobs", F, { query: e, ...t });
  }
  /**
   * Immediately cancel a fine-tune job.
   *
   * @example
   * ```ts
   * const fineTuningJob = await client.fineTuning.jobs.cancel(
   *   'ft-AF1WoRqd3aJAHsqc9NY7iL8F',
   * );
   * ```
   */
  cancel(e, t) {
    return this._client.post(w`/fine_tuning/jobs/${e}/cancel`, t);
  }
  /**
   * Get status updates for a fine-tuning job.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const fineTuningJobEvent of client.fineTuning.jobs.listEvents(
   *   'ft-AF1WoRqd3aJAHsqc9NY7iL8F',
   * )) {
   *   // ...
   * }
   * ```
   */
  listEvents(e, t = {}, r) {
    return this._client.getAPIList(w`/fine_tuning/jobs/${e}/events`, F, { query: t, ...r });
  }
  /**
   * Pause a fine-tune job.
   *
   * @example
   * ```ts
   * const fineTuningJob = await client.fineTuning.jobs.pause(
   *   'ft-AF1WoRqd3aJAHsqc9NY7iL8F',
   * );
   * ```
   */
  pause(e, t) {
    return this._client.post(w`/fine_tuning/jobs/${e}/pause`, t);
  }
  /**
   * Resume a fine-tune job.
   *
   * @example
   * ```ts
   * const fineTuningJob = await client.fineTuning.jobs.resume(
   *   'ft-AF1WoRqd3aJAHsqc9NY7iL8F',
   * );
   * ```
   */
  resume(e, t) {
    return this._client.post(w`/fine_tuning/jobs/${e}/resume`, t);
  }
}
Yn.Checkpoints = pi;
class Be extends S {
  constructor() {
    super(...arguments), this.methods = new hi(this._client), this.jobs = new Yn(this._client), this.checkpoints = new Gn(this._client), this.alpha = new Qn(this._client);
  }
}
Be.Methods = hi;
Be.Jobs = Yn;
Be.Checkpoints = Gn;
Be.Alpha = Qn;
class mi extends S {
}
class Zn extends S {
  constructor() {
    super(...arguments), this.graderModels = new mi(this._client);
  }
}
Zn.GraderModels = mi;
class gi extends S {
  /**
   * Creates a variation of a given image. This endpoint only supports `dall-e-2`.
   *
   * @example
   * ```ts
   * const imagesResponse = await client.images.createVariation({
   *   image: fs.createReadStream('otter.png'),
   * });
   * ```
   */
  createVariation(e, t) {
    return this._client.post("/images/variations", se({ body: e, ...t }, this._client));
  }
  edit(e, t) {
    return this._client.post("/images/edits", se({ body: e, ...t, stream: e.stream ?? !1 }, this._client));
  }
  generate(e, t) {
    return this._client.post("/images/generations", { body: e, ...t, stream: e.stream ?? !1 });
  }
}
class wi extends S {
  /**
   * Retrieves a model instance, providing basic information about the model such as
   * the owner and permissioning.
   */
  retrieve(e, t) {
    return this._client.get(w`/models/${e}`, t);
  }
  /**
   * Lists the currently available models, and provides basic information about each
   * one such as the owner and availability.
   */
  list(e) {
    return this._client.getAPIList("/models", qt, e);
  }
  /**
   * Delete a fine-tuned model. You must have the Owner role in your organization to
   * delete a model.
   */
  delete(e, t) {
    return this._client.delete(w`/models/${e}`, t);
  }
}
class yi extends S {
  /**
   * Classifies if text and/or image inputs are potentially harmful. Learn more in
   * the [moderation guide](https://platform.openai.com/docs/guides/moderation).
   */
  create(e, t) {
    return this._client.post("/moderations", { body: e, ...t });
  }
}
class bi extends S {
  /**
   * Accept an incoming SIP call and configure the realtime session that will handle
   * it.
   *
   * @example
   * ```ts
   * await client.realtime.calls.accept('call_id', {
   *   type: 'realtime',
   * });
   * ```
   */
  accept(e, t, r) {
    return this._client.post(w`/realtime/calls/${e}/accept`, {
      body: t,
      ...r,
      headers: k([{ Accept: "*/*" }, r?.headers])
    });
  }
  /**
   * End an active Realtime API call, whether it was initiated over SIP or WebRTC.
   *
   * @example
   * ```ts
   * await client.realtime.calls.hangup('call_id');
   * ```
   */
  hangup(e, t) {
    return this._client.post(w`/realtime/calls/${e}/hangup`, {
      ...t,
      headers: k([{ Accept: "*/*" }, t?.headers])
    });
  }
  /**
   * Transfer an active SIP call to a new destination using the SIP REFER verb.
   *
   * @example
   * ```ts
   * await client.realtime.calls.refer('call_id', {
   *   target_uri: 'tel:+14155550123',
   * });
   * ```
   */
  refer(e, t, r) {
    return this._client.post(w`/realtime/calls/${e}/refer`, {
      body: t,
      ...r,
      headers: k([{ Accept: "*/*" }, r?.headers])
    });
  }
  /**
   * Decline an incoming SIP call by returning a SIP status code to the caller.
   *
   * @example
   * ```ts
   * await client.realtime.calls.reject('call_id');
   * ```
   */
  reject(e, t = {}, r) {
    return this._client.post(w`/realtime/calls/${e}/reject`, {
      body: t,
      ...r,
      headers: k([{ Accept: "*/*" }, r?.headers])
    });
  }
}
class _i extends S {
  /**
   * Create a Realtime client secret with an associated session configuration.
   *
   * Client secrets are short-lived tokens that can be passed to a client app, such
   * as a web frontend or mobile client, which grants access to the Realtime API
   * without leaking your main API key. You can configure a custom TTL for each
   * client secret.
   *
   * You can also attach session configuration options to the client secret, which
   * will be applied to any sessions created using that client secret, but these can
   * also be overridden by the client connection.
   *
   * [Learn more about authentication with client secrets over WebRTC](https://platform.openai.com/docs/guides/realtime-webrtc).
   *
   * Returns the created client secret and the effective session object. The client
   * secret is a string that looks like `ek_1234`.
   *
   * @example
   * ```ts
   * const clientSecret =
   *   await client.realtime.clientSecrets.create();
   * ```
   */
  create(e, t) {
    return this._client.post("/realtime/client_secrets", { body: e, ...t });
  }
}
class Vt extends S {
  constructor() {
    super(...arguments), this.clientSecrets = new _i(this._client), this.calls = new bi(this._client);
  }
}
Vt.ClientSecrets = _i;
Vt.Calls = bi;
function Lo(n, e) {
  return !e || !No(e) ? {
    ...n,
    output_parsed: null,
    output: n.output.map((t) => t.type === "function_call" ? {
      ...t,
      parsed_arguments: null
    } : t.type === "message" ? {
      ...t,
      content: t.content.map((r) => ({
        ...r,
        parsed: null
      }))
    } : t)
  } : ki(n, e);
}
function ki(n, e) {
  const t = n.output.map((s) => {
    if (s.type === "function_call")
      return {
        ...s,
        parsed_arguments: Uo(e, s)
      };
    if (s.type === "message") {
      const i = s.content.map((a) => a.type === "output_text" ? {
        ...a,
        parsed: Fo(e, a.text)
      } : a);
      return {
        ...s,
        content: i
      };
    }
    return s;
  }), r = Object.assign({}, n, { output: t });
  return Object.getOwnPropertyDescriptor(n, "output_text") || $n(r), Object.defineProperty(r, "output_parsed", {
    enumerable: !0,
    get() {
      for (const s of r.output)
        if (s.type === "message") {
          for (const i of s.content)
            if (i.type === "output_text" && i.parsed !== null)
              return i.parsed;
        }
      return null;
    }
  }), r;
}
function Fo(n, e) {
  return n.text?.format?.type !== "json_schema" ? null : "$parseRaw" in n.text?.format ? (n.text?.format).$parseRaw(e) : JSON.parse(e);
}
function No(n) {
  return !!Nn(n.text?.format);
}
function jo(n) {
  return n?.$brand === "auto-parseable-tool";
}
function Bo(n, e) {
  return n.find((t) => t.type === "function" && t.name === e);
}
function Uo(n, e) {
  const t = Bo(n.tools ?? [], e.name);
  return {
    ...e,
    ...e,
    parsed_arguments: jo(t) ? t.$parseRaw(e.arguments) : t?.strict ? JSON.parse(e.arguments) : null
  };
}
function $n(n) {
  const e = [];
  for (const t of n.output)
    if (t.type === "message")
      for (const r of t.content)
        r.type === "output_text" && e.push(r.text);
  n.output_text = e.join("");
}
var Te, mt, pe, gt, Mr, Dr, Lr, Fr;
class er extends Bn {
  constructor(e) {
    super(), Te.add(this), mt.set(this, void 0), pe.set(this, void 0), gt.set(this, void 0), I(this, mt, e);
  }
  static createResponse(e, t, r) {
    const s = new er(t);
    return s._run(() => s._createOrRetrieveResponse(e, t, {
      ...r,
      headers: { ...r?.headers, "X-Stainless-Helper-Method": "stream" }
    })), s;
  }
  async _createOrRetrieveResponse(e, t, r) {
    const s = r?.signal;
    s && (s.aborted && this.controller.abort(), s.addEventListener("abort", () => this.controller.abort())), d(this, Te, "m", Mr).call(this);
    let i, a = null;
    "response_id" in t ? (i = await e.responses.retrieve(t.response_id, { stream: !0 }, { ...r, signal: this.controller.signal, stream: !0 }), a = t.starting_after ?? null) : i = await e.responses.create({ ...t, stream: !0 }, { ...r, signal: this.controller.signal }), this._connected();
    for await (const o of i)
      d(this, Te, "m", Dr).call(this, o, a);
    if (i.controller.signal?.aborted)
      throw new Y();
    return d(this, Te, "m", Lr).call(this);
  }
  [(mt = /* @__PURE__ */ new WeakMap(), pe = /* @__PURE__ */ new WeakMap(), gt = /* @__PURE__ */ new WeakMap(), Te = /* @__PURE__ */ new WeakSet(), Mr = function() {
    this.ended || I(this, pe, void 0);
  }, Dr = function(t, r) {
    if (this.ended)
      return;
    const s = (a, o) => {
      (r == null || o.sequence_number > r) && this._emit(a, o);
    }, i = d(this, Te, "m", Fr).call(this, t);
    switch (s("event", t), t.type) {
      case "response.output_text.delta": {
        const a = i.output[t.output_index];
        if (!a)
          throw new v(`missing output at index ${t.output_index}`);
        if (a.type === "message") {
          const o = a.content[t.content_index];
          if (!o)
            throw new v(`missing content at index ${t.content_index}`);
          if (o.type !== "output_text")
            throw new v(`expected content to be 'output_text', got ${o.type}`);
          s("response.output_text.delta", {
            ...t,
            snapshot: o.text
          });
        }
        break;
      }
      case "response.function_call_arguments.delta": {
        const a = i.output[t.output_index];
        if (!a)
          throw new v(`missing output at index ${t.output_index}`);
        a.type === "function_call" && s("response.function_call_arguments.delta", {
          ...t,
          snapshot: a.arguments
        });
        break;
      }
      default:
        s(t.type, t);
        break;
    }
  }, Lr = function() {
    if (this.ended)
      throw new v("stream has ended, this shouldn't happen");
    const t = d(this, pe, "f");
    if (!t)
      throw new v("request ended without sending any events");
    I(this, pe, void 0);
    const r = Wo(t, d(this, mt, "f"));
    return I(this, gt, r), r;
  }, Fr = function(t) {
    let r = d(this, pe, "f");
    if (!r) {
      if (t.type !== "response.created")
        throw new v(`When snapshot hasn't been set yet, expected 'response.created' event, got ${t.type}`);
      return r = I(this, pe, t.response), r;
    }
    switch (t.type) {
      case "response.output_item.added": {
        r.output.push(t.item);
        break;
      }
      case "response.content_part.added": {
        const s = r.output[t.output_index];
        if (!s)
          throw new v(`missing output at index ${t.output_index}`);
        const i = s.type, a = t.part;
        i === "message" && a.type !== "reasoning_text" ? s.content.push(a) : i === "reasoning" && a.type === "reasoning_text" && (s.content || (s.content = []), s.content.push(a));
        break;
      }
      case "response.output_text.delta": {
        const s = r.output[t.output_index];
        if (!s)
          throw new v(`missing output at index ${t.output_index}`);
        if (s.type === "message") {
          const i = s.content[t.content_index];
          if (!i)
            throw new v(`missing content at index ${t.content_index}`);
          if (i.type !== "output_text")
            throw new v(`expected content to be 'output_text', got ${i.type}`);
          i.text += t.delta;
        }
        break;
      }
      case "response.function_call_arguments.delta": {
        const s = r.output[t.output_index];
        if (!s)
          throw new v(`missing output at index ${t.output_index}`);
        s.type === "function_call" && (s.arguments += t.delta);
        break;
      }
      case "response.reasoning_text.delta": {
        const s = r.output[t.output_index];
        if (!s)
          throw new v(`missing output at index ${t.output_index}`);
        if (s.type === "reasoning") {
          const i = s.content?.[t.content_index];
          if (!i)
            throw new v(`missing content at index ${t.content_index}`);
          if (i.type !== "reasoning_text")
            throw new v(`expected content to be 'reasoning_text', got ${i.type}`);
          i.text += t.delta;
        }
        break;
      }
      case "response.completed": {
        I(this, pe, t.response);
        break;
      }
    }
    return r;
  }, Symbol.asyncIterator)]() {
    const e = [], t = [];
    let r = !1;
    return this.on("event", (s) => {
      const i = t.shift();
      i ? i.resolve(s) : e.push(s);
    }), this.on("end", () => {
      r = !0;
      for (const s of t)
        s.resolve(void 0);
      t.length = 0;
    }), this.on("abort", (s) => {
      r = !0;
      for (const i of t)
        i.reject(s);
      t.length = 0;
    }), this.on("error", (s) => {
      r = !0;
      for (const i of t)
        i.reject(s);
      t.length = 0;
    }), {
      next: async () => e.length ? { value: e.shift(), done: !1 } : r ? { value: void 0, done: !0 } : new Promise((i, a) => t.push({ resolve: i, reject: a })).then((i) => i ? { value: i, done: !1 } : { value: void 0, done: !0 }),
      return: async () => (this.abort(), { value: void 0, done: !0 })
    };
  }
  /**
   * @returns a promise that resolves with the final Response, or rejects
   * if an error occurred or the stream ended prematurely without producing a REsponse.
   */
  async finalResponse() {
    await this.done();
    const e = d(this, gt, "f");
    if (!e)
      throw new v("stream ended without producing a ChatCompletion");
    return e;
  }
}
function Wo(n, e) {
  return Lo(n, e);
}
class xi extends S {
  /**
   * Returns a list of input items for a given response.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const responseItem of client.responses.inputItems.list(
   *   'response_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(e, t = {}, r) {
    return this._client.getAPIList(w`/responses/${e}/input_items`, F, { query: t, ...r });
  }
}
class Ci extends S {
  /**
   * Returns input token counts of the request.
   *
   * Returns an object with `object` set to `response.input_tokens` and an
   * `input_tokens` count.
   *
   * @example
   * ```ts
   * const response = await client.responses.inputTokens.count();
   * ```
   */
  count(e = {}, t) {
    return this._client.post("/responses/input_tokens", { body: e, ...t });
  }
}
class Qt extends S {
  constructor() {
    super(...arguments), this.inputItems = new xi(this._client), this.inputTokens = new Ci(this._client);
  }
  create(e, t) {
    return this._client.post("/responses", { body: e, ...t, stream: e.stream ?? !1 })._thenUnwrap((r) => ("object" in r && r.object === "response" && $n(r), r));
  }
  retrieve(e, t = {}, r) {
    return this._client.get(w`/responses/${e}`, {
      query: t,
      ...r,
      stream: t?.stream ?? !1
    })._thenUnwrap((s) => ("object" in s && s.object === "response" && $n(s), s));
  }
  /**
   * Deletes a model response with the given ID.
   *
   * @example
   * ```ts
   * await client.responses.delete(
   *   'resp_677efb5139a88190b512bc3fef8e535d',
   * );
   * ```
   */
  delete(e, t) {
    return this._client.delete(w`/responses/${e}`, {
      ...t,
      headers: k([{ Accept: "*/*" }, t?.headers])
    });
  }
  parse(e, t) {
    return this._client.responses.create(e, t)._thenUnwrap((r) => ki(r, e));
  }
  /**
   * Creates a model response stream
   */
  stream(e, t) {
    return er.createResponse(this._client, e, t);
  }
  /**
   * Cancels a model response with the given ID. Only responses created with the
   * `background` parameter set to `true` can be cancelled.
   * [Learn more](https://platform.openai.com/docs/guides/background).
   *
   * @example
   * ```ts
   * const response = await client.responses.cancel(
   *   'resp_677efb5139a88190b512bc3fef8e535d',
   * );
   * ```
   */
  cancel(e, t) {
    return this._client.post(w`/responses/${e}/cancel`, t);
  }
  /**
   * Compact a conversation. Returns a compacted response object.
   *
   * Learn when and how to compact long-running conversations in the
   * [conversation state guide](https://platform.openai.com/docs/guides/conversation-state#managing-the-context-window).
   * For ZDR-compatible compaction details, see
   * [Compaction (advanced)](https://platform.openai.com/docs/guides/conversation-state#compaction-advanced).
   *
   * @example
   * ```ts
   * const compactedResponse = await client.responses.compact({
   *   model: 'gpt-5.4',
   * });
   * ```
   */
  compact(e, t) {
    return this._client.post("/responses/compact", { body: e, ...t });
  }
}
Qt.InputItems = xi;
Qt.InputTokens = Ci;
let Si = class extends S {
  /**
   * Download a skill zip bundle by its ID.
   */
  retrieve(e, t) {
    return this._client.get(w`/skills/${e}/content`, {
      ...t,
      headers: k([{ Accept: "application/binary" }, t?.headers]),
      __binaryResponse: !0
    });
  }
};
class vi extends S {
  /**
   * Download a skill version zip bundle.
   */
  retrieve(e, t, r) {
    const { skill_id: s } = t;
    return this._client.get(w`/skills/${s}/versions/${e}/content`, {
      ...r,
      headers: k([{ Accept: "application/binary" }, r?.headers]),
      __binaryResponse: !0
    });
  }
}
class tr extends S {
  constructor() {
    super(...arguments), this.content = new vi(this._client);
  }
  /**
   * Create a new immutable skill version.
   */
  create(e, t = {}, r) {
    return this._client.post(w`/skills/${e}/versions`, Ht({ body: t, ...r }, this._client));
  }
  /**
   * Get a specific skill version.
   */
  retrieve(e, t, r) {
    const { skill_id: s } = t;
    return this._client.get(w`/skills/${s}/versions/${e}`, r);
  }
  /**
   * List skill versions for a skill.
   */
  list(e, t = {}, r) {
    return this._client.getAPIList(w`/skills/${e}/versions`, F, {
      query: t,
      ...r
    });
  }
  /**
   * Delete a skill version.
   */
  delete(e, t, r) {
    const { skill_id: s } = t;
    return this._client.delete(w`/skills/${s}/versions/${e}`, r);
  }
}
tr.Content = vi;
class Gt extends S {
  constructor() {
    super(...arguments), this.content = new Si(this._client), this.versions = new tr(this._client);
  }
  /**
   * Create a new skill.
   */
  create(e = {}, t) {
    return this._client.post("/skills", Ht({ body: e, ...t }, this._client));
  }
  /**
   * Get a skill by its ID.
   */
  retrieve(e, t) {
    return this._client.get(w`/skills/${e}`, t);
  }
  /**
   * Update the default version pointer for a skill.
   */
  update(e, t, r) {
    return this._client.post(w`/skills/${e}`, { body: t, ...r });
  }
  /**
   * List all skills for the current project.
   */
  list(e = {}, t) {
    return this._client.getAPIList("/skills", F, { query: e, ...t });
  }
  /**
   * Delete a skill by its ID.
   */
  delete(e, t) {
    return this._client.delete(w`/skills/${e}`, t);
  }
}
Gt.Content = Si;
Gt.Versions = tr;
class Ai extends S {
  /**
   * Adds a
   * [Part](https://platform.openai.com/docs/api-reference/uploads/part-object) to an
   * [Upload](https://platform.openai.com/docs/api-reference/uploads/object) object.
   * A Part represents a chunk of bytes from the file you are trying to upload.
   *
   * Each Part can be at most 64 MB, and you can add Parts until you hit the Upload
   * maximum of 8 GB.
   *
   * It is possible to add multiple Parts in parallel. You can decide the intended
   * order of the Parts when you
   * [complete the Upload](https://platform.openai.com/docs/api-reference/uploads/complete).
   */
  create(e, t, r) {
    return this._client.post(w`/uploads/${e}/parts`, se({ body: t, ...r }, this._client));
  }
}
class nr extends S {
  constructor() {
    super(...arguments), this.parts = new Ai(this._client);
  }
  /**
   * Creates an intermediate
   * [Upload](https://platform.openai.com/docs/api-reference/uploads/object) object
   * that you can add
   * [Parts](https://platform.openai.com/docs/api-reference/uploads/part-object) to.
   * Currently, an Upload can accept at most 8 GB in total and expires after an hour
   * after you create it.
   *
   * Once you complete the Upload, we will create a
   * [File](https://platform.openai.com/docs/api-reference/files/object) object that
   * contains all the parts you uploaded. This File is usable in the rest of our
   * platform as a regular File object.
   *
   * For certain `purpose` values, the correct `mime_type` must be specified. Please
   * refer to documentation for the
   * [supported MIME types for your use case](https://platform.openai.com/docs/assistants/tools/file-search#supported-files).
   *
   * For guidance on the proper filename extensions for each purpose, please follow
   * the documentation on
   * [creating a File](https://platform.openai.com/docs/api-reference/files/create).
   *
   * Returns the Upload object with status `pending`.
   */
  create(e, t) {
    return this._client.post("/uploads", { body: e, ...t });
  }
  /**
   * Cancels the Upload. No Parts may be added after an Upload is cancelled.
   *
   * Returns the Upload object with status `cancelled`.
   */
  cancel(e, t) {
    return this._client.post(w`/uploads/${e}/cancel`, t);
  }
  /**
   * Completes the
   * [Upload](https://platform.openai.com/docs/api-reference/uploads/object).
   *
   * Within the returned Upload object, there is a nested
   * [File](https://platform.openai.com/docs/api-reference/files/object) object that
   * is ready to use in the rest of the platform.
   *
   * You can specify the order of the Parts by passing in an ordered list of the Part
   * IDs.
   *
   * The number of bytes uploaded upon completion must match the number of bytes
   * initially specified when creating the Upload object. No Parts may be added after
   * an Upload is completed. Returns the Upload object with status `completed`,
   * including an additional `file` property containing the created usable File
   * object.
   */
  complete(e, t, r) {
    return this._client.post(w`/uploads/${e}/complete`, { body: t, ...r });
  }
}
nr.Parts = Ai;
const zo = async (n) => {
  const e = await Promise.allSettled(n), t = e.filter((s) => s.status === "rejected");
  if (t.length) {
    for (const s of t)
      console.error(s.reason);
    throw new Error(`${t.length} promise(s) failed - see the above errors`);
  }
  const r = [];
  for (const s of e)
    s.status === "fulfilled" && r.push(s.value);
  return r;
};
class Ri extends S {
  /**
   * Create a vector store file batch.
   */
  create(e, t, r) {
    return this._client.post(w`/vector_stores/${e}/file_batches`, {
      body: t,
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * Retrieves a vector store file batch.
   */
  retrieve(e, t, r) {
    const { vector_store_id: s } = t;
    return this._client.get(w`/vector_stores/${s}/file_batches/${e}`, {
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * Cancel a vector store file batch. This attempts to cancel the processing of
   * files in this batch as soon as possible.
   */
  cancel(e, t, r) {
    const { vector_store_id: s } = t;
    return this._client.post(w`/vector_stores/${s}/file_batches/${e}/cancel`, {
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * Create a vector store batch and poll until all files have been processed.
   */
  async createAndPoll(e, t, r) {
    const s = await this.create(e, t);
    return await this.poll(e, s.id, r);
  }
  /**
   * Returns a list of vector store files in a batch.
   */
  listFiles(e, t, r) {
    const { vector_store_id: s, ...i } = t;
    return this._client.getAPIList(w`/vector_stores/${s}/file_batches/${e}/files`, F, { query: i, ...r, headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers]) });
  }
  /**
   * Wait for the given file batch to be processed.
   *
   * Note: this will return even if one of the files failed to process, you need to
   * check batch.file_counts.failed_count to handle this case.
   */
  async poll(e, t, r) {
    const s = k([
      r?.headers,
      {
        "X-Stainless-Poll-Helper": "true",
        "X-Stainless-Custom-Poll-Interval": r?.pollIntervalMs?.toString() ?? void 0
      }
    ]);
    for (; ; ) {
      const { data: i, response: a } = await this.retrieve(t, { vector_store_id: e }, {
        ...r,
        headers: s
      }).withResponse();
      switch (i.status) {
        case "in_progress":
          let o = 5e3;
          if (r?.pollIntervalMs)
            o = r.pollIntervalMs;
          else {
            const l = a.headers.get("openai-poll-after-ms");
            if (l) {
              const c = parseInt(l);
              isNaN(c) || (o = c);
            }
          }
          await at(o);
          break;
        case "failed":
        case "cancelled":
        case "completed":
          return i;
      }
    }
  }
  /**
   * Uploads the given files concurrently and then creates a vector store file batch.
   *
   * The concurrency limit is configurable using the `maxConcurrency` parameter.
   */
  async uploadAndPoll(e, { files: t, fileIds: r = [] }, s) {
    if (t == null || t.length == 0)
      throw new Error("No `files` provided to process. If you've already uploaded files you should use `.createAndPoll()` instead");
    const i = s?.maxConcurrency ?? 5, a = Math.min(i, t.length), o = this._client, l = t.values(), c = [...r];
    async function h(p) {
      for (let f of p) {
        const m = await o.files.create({ file: f, purpose: "assistants" }, s);
        c.push(m.id);
      }
    }
    const u = Array(a).fill(l).map(h);
    return await zo(u), await this.createAndPoll(e, {
      file_ids: c
    });
  }
}
class Ii extends S {
  /**
   * Create a vector store file by attaching a
   * [File](https://platform.openai.com/docs/api-reference/files) to a
   * [vector store](https://platform.openai.com/docs/api-reference/vector-stores/object).
   */
  create(e, t, r) {
    return this._client.post(w`/vector_stores/${e}/files`, {
      body: t,
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * Retrieves a vector store file.
   */
  retrieve(e, t, r) {
    const { vector_store_id: s } = t;
    return this._client.get(w`/vector_stores/${s}/files/${e}`, {
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * Update attributes on a vector store file.
   */
  update(e, t, r) {
    const { vector_store_id: s, ...i } = t;
    return this._client.post(w`/vector_stores/${s}/files/${e}`, {
      body: i,
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * Returns a list of vector store files.
   */
  list(e, t = {}, r) {
    return this._client.getAPIList(w`/vector_stores/${e}/files`, F, {
      query: t,
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * Delete a vector store file. This will remove the file from the vector store but
   * the file itself will not be deleted. To delete the file, use the
   * [delete file](https://platform.openai.com/docs/api-reference/files/delete)
   * endpoint.
   */
  delete(e, t, r) {
    const { vector_store_id: s } = t;
    return this._client.delete(w`/vector_stores/${s}/files/${e}`, {
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * Attach a file to the given vector store and wait for it to be processed.
   */
  async createAndPoll(e, t, r) {
    const s = await this.create(e, t, r);
    return await this.poll(e, s.id, r);
  }
  /**
   * Wait for the vector store file to finish processing.
   *
   * Note: this will return even if the file failed to process, you need to check
   * file.last_error and file.status to handle these cases
   */
  async poll(e, t, r) {
    const s = k([
      r?.headers,
      {
        "X-Stainless-Poll-Helper": "true",
        "X-Stainless-Custom-Poll-Interval": r?.pollIntervalMs?.toString() ?? void 0
      }
    ]);
    for (; ; ) {
      const i = await this.retrieve(t, {
        vector_store_id: e
      }, { ...r, headers: s }).withResponse(), a = i.data;
      switch (a.status) {
        case "in_progress":
          let o = 5e3;
          if (r?.pollIntervalMs)
            o = r.pollIntervalMs;
          else {
            const l = i.response.headers.get("openai-poll-after-ms");
            if (l) {
              const c = parseInt(l);
              isNaN(c) || (o = c);
            }
          }
          await at(o);
          break;
        case "failed":
        case "completed":
          return a;
      }
    }
  }
  /**
   * Upload a file to the `files` API and then attach it to the given vector store.
   *
   * Note the file will be asynchronously processed (you can use the alternative
   * polling helper method to wait for processing to complete).
   */
  async upload(e, t, r) {
    const s = await this._client.files.create({ file: t, purpose: "assistants" }, r);
    return this.create(e, { file_id: s.id }, r);
  }
  /**
   * Add a file to a vector store and poll until processing is complete.
   */
  async uploadAndPoll(e, t, r) {
    const s = await this.upload(e, t, r);
    return await this.poll(e, s.id, r);
  }
  /**
   * Retrieve the parsed contents of a vector store file.
   */
  content(e, t, r) {
    const { vector_store_id: s } = t;
    return this._client.getAPIList(w`/vector_stores/${s}/files/${e}/content`, qt, { ...r, headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers]) });
  }
}
class Yt extends S {
  constructor() {
    super(...arguments), this.files = new Ii(this._client), this.fileBatches = new Ri(this._client);
  }
  /**
   * Create a vector store.
   */
  create(e, t) {
    return this._client.post("/vector_stores", {
      body: e,
      ...t,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, t?.headers])
    });
  }
  /**
   * Retrieves a vector store.
   */
  retrieve(e, t) {
    return this._client.get(w`/vector_stores/${e}`, {
      ...t,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, t?.headers])
    });
  }
  /**
   * Modifies a vector store.
   */
  update(e, t, r) {
    return this._client.post(w`/vector_stores/${e}`, {
      body: t,
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
  /**
   * Returns a list of vector stores.
   */
  list(e = {}, t) {
    return this._client.getAPIList("/vector_stores", F, {
      query: e,
      ...t,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, t?.headers])
    });
  }
  /**
   * Delete a vector store.
   */
  delete(e, t) {
    return this._client.delete(w`/vector_stores/${e}`, {
      ...t,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, t?.headers])
    });
  }
  /**
   * Search a vector store for relevant chunks based on a query and file attributes
   * filter.
   */
  search(e, t, r) {
    return this._client.getAPIList(w`/vector_stores/${e}/search`, qt, {
      body: t,
      method: "post",
      ...r,
      headers: k([{ "OpenAI-Beta": "assistants=v2" }, r?.headers])
    });
  }
}
Yt.Files = Ii;
Yt.FileBatches = Ri;
class $i extends S {
  /**
   * Create a new video generation job from a prompt and optional reference assets.
   */
  create(e, t) {
    return this._client.post("/videos", se({ body: e, ...t }, this._client));
  }
  /**
   * Fetch the latest metadata for a generated video.
   */
  retrieve(e, t) {
    return this._client.get(w`/videos/${e}`, t);
  }
  /**
   * List recently generated videos for the current project.
   */
  list(e = {}, t) {
    return this._client.getAPIList("/videos", tt, { query: e, ...t });
  }
  /**
   * Permanently delete a completed or failed video and its stored assets.
   */
  delete(e, t) {
    return this._client.delete(w`/videos/${e}`, t);
  }
  /**
   * Create a character from an uploaded video.
   */
  createCharacter(e, t) {
    return this._client.post("/videos/characters", se({ body: e, ...t }, this._client));
  }
  /**
   * Download the generated video bytes or a derived preview asset.
   *
   * Streams the rendered video content for the specified video job.
   */
  downloadContent(e, t = {}, r) {
    return this._client.get(w`/videos/${e}/content`, {
      query: t,
      ...r,
      headers: k([{ Accept: "application/binary" }, r?.headers]),
      __binaryResponse: !0
    });
  }
  /**
   * Create a new video generation job by editing a source video or existing
   * generated video.
   */
  edit(e, t) {
    return this._client.post("/videos/edits", se({ body: e, ...t }, this._client));
  }
  /**
   * Create an extension of a completed video.
   */
  extend(e, t) {
    return this._client.post("/videos/extensions", se({ body: e, ...t }, this._client));
  }
  /**
   * Fetch a character.
   */
  getCharacter(e, t) {
    return this._client.get(w`/videos/characters/${e}`, t);
  }
  /**
   * Create a remix of a completed video using a refreshed prompt.
   */
  remix(e, t, r) {
    return this._client.post(w`/videos/${e}/remix`, Ht({ body: t, ...r }, this._client));
  }
}
var De, Ei, At;
class Pi extends S {
  constructor() {
    super(...arguments), De.add(this);
  }
  /**
   * Validates that the given payload was sent by OpenAI and parses the payload.
   */
  async unwrap(e, t, r = this._client.webhookSecret, s = 300) {
    return await this.verifySignature(e, t, r, s), JSON.parse(e);
  }
  /**
   * Validates whether or not the webhook payload was sent by OpenAI.
   *
   * An error will be raised if the webhook payload was not sent by OpenAI.
   *
   * @param payload - The webhook payload
   * @param headers - The webhook headers
   * @param secret - The webhook secret (optional, will use client secret if not provided)
   * @param tolerance - Maximum age of the webhook in seconds (default: 300 = 5 minutes)
   */
  async verifySignature(e, t, r = this._client.webhookSecret, s = 300) {
    if (typeof crypto > "u" || typeof crypto.subtle.importKey != "function" || typeof crypto.subtle.verify != "function")
      throw new Error("Webhook signature verification is only supported when the `crypto` global is defined");
    d(this, De, "m", Ei).call(this, r);
    const i = k([t]).values, a = d(this, De, "m", At).call(this, i, "webhook-signature"), o = d(this, De, "m", At).call(this, i, "webhook-timestamp"), l = d(this, De, "m", At).call(this, i, "webhook-id"), c = parseInt(o, 10);
    if (isNaN(c))
      throw new We("Invalid webhook timestamp format");
    const h = Math.floor(Date.now() / 1e3);
    if (h - c > s)
      throw new We("Webhook timestamp is too old");
    if (c > h + s)
      throw new We("Webhook timestamp is too new");
    const u = a.split(" ").map((y) => y.startsWith("v1,") ? y.substring(3) : y), p = r.startsWith("whsec_") ? Buffer.from(r.replace("whsec_", ""), "base64") : Buffer.from(r, "utf-8"), f = l ? `${l}.${o}.${e}` : `${o}.${e}`, m = await crypto.subtle.importKey("raw", p, { name: "HMAC", hash: "SHA-256" }, !1, ["verify"]);
    for (const y of u)
      try {
        const x = Buffer.from(y, "base64");
        if (await crypto.subtle.verify("HMAC", m, x, new TextEncoder().encode(f)))
          return;
      } catch {
        continue;
      }
    throw new We("The given webhook signature does not match the expected signature");
  }
}
De = /* @__PURE__ */ new WeakSet(), Ei = function(e) {
  if (typeof e != "string" || e.length === 0)
    throw new Error("The webhook secret must either be set using the env var, OPENAI_WEBHOOK_SECRET, on the client class, OpenAI({ webhookSecret: '123' }), or passed to this function");
}, At = function(e, t) {
  if (!e)
    throw new Error("Headers are required");
  const r = e.get(t);
  if (r == null)
    throw new Error(`Missing required header: ${t}`);
  return r;
};
var En, rr, Rt, Ti;
class E {
  /**
   * API Client for interfacing with the OpenAI API.
   *
   * @param {string | undefined} [opts.apiKey=process.env['OPENAI_API_KEY'] ?? undefined]
   * @param {string | null | undefined} [opts.organization=process.env['OPENAI_ORG_ID'] ?? null]
   * @param {string | null | undefined} [opts.project=process.env['OPENAI_PROJECT_ID'] ?? null]
   * @param {string | null | undefined} [opts.webhookSecret=process.env['OPENAI_WEBHOOK_SECRET'] ?? null]
   * @param {string} [opts.baseURL=process.env['OPENAI_BASE_URL'] ?? https://api.openai.com/v1] - Override the default base URL for the API.
   * @param {number} [opts.timeout=10 minutes] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
   * @param {MergedRequestInit} [opts.fetchOptions] - Additional `RequestInit` options to be passed to `fetch` calls.
   * @param {Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
   * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
   * @param {HeadersLike} opts.defaultHeaders - Default headers to include with every request to the API.
   * @param {Record<string, string | undefined>} opts.defaultQuery - Default query parameters to include with every request to the API.
   * @param {boolean} [opts.dangerouslyAllowBrowser=false] - By default, client-side use of this library is not allowed, as it risks exposing your secret API credentials to attackers.
   */
  constructor({ baseURL: e = Pe("OPENAI_BASE_URL"), apiKey: t = Pe("OPENAI_API_KEY"), organization: r = Pe("OPENAI_ORG_ID") ?? null, project: s = Pe("OPENAI_PROJECT_ID") ?? null, webhookSecret: i = Pe("OPENAI_WEBHOOK_SECRET") ?? null, ...a } = {}) {
    if (En.add(this), Rt.set(this, void 0), this.completions = new ii(this), this.chat = new zn(this), this.embeddings = new li(this), this.files = new ui(this), this.images = new gi(this), this.audio = new lt(this), this.moderations = new yi(this), this.models = new wi(this), this.fineTuning = new Be(this), this.graders = new Zn(this), this.vectorStores = new Yt(this), this.webhooks = new Pi(this), this.beta = new je(this), this.batches = new Gs(this), this.uploads = new nr(this), this.responses = new Qt(this), this.realtime = new Vt(this), this.conversations = new Kn(this), this.evals = new Vn(this), this.containers = new Jn(this), this.skills = new Gt(this), this.videos = new $i(this), t === void 0)
      throw new v("Missing credentials. Please pass an `apiKey`, or set the `OPENAI_API_KEY` environment variable.");
    const o = {
      apiKey: t,
      organization: r,
      project: s,
      webhookSecret: i,
      ...a,
      baseURL: e || "https://api.openai.com/v1"
    };
    if (!o.dangerouslyAllowBrowser && za())
      throw new v(`It looks like you're running in a browser-like environment.

This is disabled by default, as it risks exposing your secret API credentials to attackers.
If you understand the risks and have appropriate mitigations in place,
you can set the \`dangerouslyAllowBrowser\` option to \`true\`, e.g.,

new OpenAI({ apiKey, dangerouslyAllowBrowser: true });

https://help.openai.com/en/articles/5112595-best-practices-for-api-key-safety
`);
    this.baseURL = o.baseURL, this.timeout = o.timeout ?? rr.DEFAULT_TIMEOUT, this.logger = o.logger ?? console;
    const l = "warn";
    this.logLevel = l, this.logLevel = kr(o.logLevel, "ClientOptions.logLevel", this) ?? kr(Pe("OPENAI_LOG"), "process.env['OPENAI_LOG']", this) ?? l, this.fetchOptions = o.fetchOptions, this.maxRetries = o.maxRetries ?? 2, this.fetch = o.fetch ?? Xa(), I(this, Rt, Qa), this._options = o, this.apiKey = typeof t == "string" ? t : "Missing Key", this.organization = r, this.project = s, this.webhookSecret = i;
  }
  /**
   * Create a new client instance re-using the same options given to the current client with optional overriding.
   */
  withOptions(e) {
    return new this.constructor({
      ...this._options,
      baseURL: this.baseURL,
      maxRetries: this.maxRetries,
      timeout: this.timeout,
      logger: this.logger,
      logLevel: this.logLevel,
      fetch: this.fetch,
      fetchOptions: this.fetchOptions,
      apiKey: this.apiKey,
      organization: this.organization,
      project: this.project,
      webhookSecret: this.webhookSecret,
      ...e
    });
  }
  defaultQuery() {
    return this._options.defaultQuery;
  }
  validateHeaders({ values: e, nulls: t }) {
  }
  async authHeaders(e) {
    return k([{ Authorization: `Bearer ${this.apiKey}` }]);
  }
  stringifyQuery(e) {
    return ro(e);
  }
  getUserAgent() {
    return `${this.constructor.name}/JS ${Oe}`;
  }
  defaultIdempotencyKey() {
    return `stainless-node-retry-${Zr()}`;
  }
  makeStatusError(e, t, r, s) {
    return z.generate(e, t, r, s);
  }
  async _callApiKey() {
    const e = this._options.apiKey;
    if (typeof e != "function")
      return !1;
    let t;
    try {
      t = await e();
    } catch (r) {
      throw r instanceof v ? r : new v(
        `Failed to get token from 'apiKey' function: ${r.message}`,
        // @ts-ignore
        { cause: r }
      );
    }
    if (typeof t != "string" || !t)
      throw new v(`Expected 'apiKey' function argument to return a string but it returned ${t}`);
    return this.apiKey = t, !0;
  }
  buildURL(e, t, r) {
    const s = !d(this, En, "m", Ti).call(this) && r || this.baseURL, i = ja(e) ? new URL(e) : new URL(s + (s.endsWith("/") && e.startsWith("/") ? e.slice(1) : e)), a = this.defaultQuery(), o = Object.fromEntries(i.searchParams);
    return (!hr(a) || !hr(o)) && (t = { ...o, ...a, ...t }), typeof t == "object" && t && !Array.isArray(t) && (i.search = this.stringifyQuery(t)), i.toString();
  }
  /**
   * Used as a callback for mutating the given `FinalRequestOptions` object.
   */
  async prepareOptions(e) {
    await this._callApiKey();
  }
  /**
   * Used as a callback for mutating the given `RequestInit` object.
   *
   * This is useful for cases where you want to add certain headers based off of
   * the request properties, e.g. `method` or `url`.
   */
  async prepareRequest(e, { url: t, options: r }) {
  }
  get(e, t) {
    return this.methodRequest("get", e, t);
  }
  post(e, t) {
    return this.methodRequest("post", e, t);
  }
  patch(e, t) {
    return this.methodRequest("patch", e, t);
  }
  put(e, t) {
    return this.methodRequest("put", e, t);
  }
  delete(e, t) {
    return this.methodRequest("delete", e, t);
  }
  methodRequest(e, t, r) {
    return this.request(Promise.resolve(r).then((s) => ({ method: e, path: t, ...s })));
  }
  request(e, t = null) {
    return new zt(this, this.makeRequest(e, t, void 0));
  }
  async makeRequest(e, t, r) {
    const s = await e, i = s.maxRetries ?? this.maxRetries;
    t == null && (t = i), await this.prepareOptions(s);
    const { req: a, url: o, timeout: l } = await this.buildRequest(s, {
      retryCount: i - t
    });
    await this.prepareRequest(a, { url: o, options: s });
    const c = "log_" + (Math.random() * (1 << 24) | 0).toString(16).padStart(6, "0"), h = r === void 0 ? "" : `, retryOf: ${r}`, u = Date.now();
    if (U(this).debug(`[${c}] sending request`, _e({
      retryOfRequestLogID: r,
      method: s.method,
      url: o,
      options: s,
      headers: a.headers
    })), s.signal?.aborted)
      throw new Y();
    const p = new AbortController(), f = await this.fetchWithTimeout(o, a, l, p).catch(yn), m = Date.now();
    if (f instanceof globalThis.Error) {
      const _ = `retrying, ${t} attempts remaining`;
      if (s.signal?.aborted)
        throw new Y();
      const b = wn(f) || /timed? ?out/i.test(String(f) + ("cause" in f ? String(f.cause) : ""));
      if (t)
        return U(this).info(`[${c}] connection ${b ? "timed out" : "failed"} - ${_}`), U(this).debug(`[${c}] connection ${b ? "timed out" : "failed"} (${_})`, _e({
          retryOfRequestLogID: r,
          url: o,
          durationMs: m - u,
          message: f.message
        })), this.retryRequest(s, t, r ?? c);
      throw U(this).info(`[${c}] connection ${b ? "timed out" : "failed"} - error; no more retries left`), U(this).debug(`[${c}] connection ${b ? "timed out" : "failed"} (error; no more retries left)`, _e({
        retryOfRequestLogID: r,
        url: o,
        durationMs: m - u,
        message: f.message
      })), b ? new Mn() : new Ut({ cause: f });
    }
    const y = [...f.headers.entries()].filter(([_]) => _ === "x-request-id").map(([_, b]) => ", " + _ + ": " + JSON.stringify(b)).join(""), x = `[${c}${h}${y}] ${a.method} ${o} ${f.ok ? "succeeded" : "failed"} with status ${f.status} in ${m - u}ms`;
    if (!f.ok) {
      const _ = await this.shouldRetry(f);
      if (t && _) {
        const M = `retrying, ${t} attempts remaining`;
        return await Va(f.body), U(this).info(`${x} - ${M}`), U(this).debug(`[${c}] response error (${M})`, _e({
          retryOfRequestLogID: r,
          url: f.url,
          status: f.status,
          headers: f.headers,
          durationMs: m - u
        })), this.retryRequest(s, t, r ?? c, f.headers);
      }
      const b = _ ? "error; no more retries left" : "error; not retryable";
      U(this).info(`${x} - ${b}`);
      const A = await f.text().catch((M) => yn(M).message), $ = Wa(A), P = $ ? void 0 : A;
      throw U(this).debug(`[${c}] response error (${b})`, _e({
        retryOfRequestLogID: r,
        url: f.url,
        status: f.status,
        headers: f.headers,
        message: P,
        durationMs: Date.now() - u
      })), this.makeStatusError(f.status, $, P, f.headers);
    }
    return U(this).info(x), U(this).debug(`[${c}] response start`, _e({
      retryOfRequestLogID: r,
      url: f.url,
      status: f.status,
      headers: f.headers,
      durationMs: m - u
    })), { response: f, options: s, controller: p, requestLogID: c, retryOfRequestLogID: r, startTime: u };
  }
  getAPIList(e, t, r) {
    return this.requestAPIList(t, r && "then" in r ? r.then((s) => ({ method: "get", path: e, ...s })) : { method: "get", path: e, ...r });
  }
  requestAPIList(e, t) {
    const r = this.makeRequest(t, null, void 0);
    return new fo(this, r, e);
  }
  async fetchWithTimeout(e, t, r, s) {
    const { signal: i, method: a, ...o } = t || {}, l = this._makeAbort(s);
    i && i.addEventListener("abort", l, { once: !0 });
    const c = setTimeout(l, r), h = globalThis.ReadableStream && o.body instanceof globalThis.ReadableStream || typeof o.body == "object" && o.body !== null && Symbol.asyncIterator in o.body, u = {
      signal: s.signal,
      ...h ? { duplex: "half" } : {},
      method: "GET",
      ...o
    };
    a && (u.method = a.toUpperCase());
    try {
      return await this.fetch.call(void 0, e, u);
    } finally {
      clearTimeout(c);
    }
  }
  async shouldRetry(e) {
    const t = e.headers.get("x-should-retry");
    return t === "true" ? !0 : t === "false" ? !1 : e.status === 408 || e.status === 409 || e.status === 429 || e.status >= 500;
  }
  async retryRequest(e, t, r, s) {
    let i;
    const a = s?.get("retry-after-ms");
    if (a) {
      const l = parseFloat(a);
      Number.isNaN(l) || (i = l);
    }
    const o = s?.get("retry-after");
    if (o && !i) {
      const l = parseFloat(o);
      Number.isNaN(l) ? i = Date.parse(o) - Date.now() : i = l * 1e3;
    }
    if (i === void 0) {
      const l = e.maxRetries ?? this.maxRetries;
      i = this.calculateDefaultRetryTimeoutMillis(t, l);
    }
    return await at(i), this.makeRequest(e, t - 1, r);
  }
  calculateDefaultRetryTimeoutMillis(e, t) {
    const i = t - e, a = Math.min(0.5 * Math.pow(2, i), 8), o = 1 - Math.random() * 0.25;
    return a * o * 1e3;
  }
  async buildRequest(e, { retryCount: t = 0 } = {}) {
    const r = { ...e }, { method: s, path: i, query: a, defaultBaseURL: o } = r, l = this.buildURL(i, a, o);
    "timeout" in r && Ua("timeout", r.timeout), r.timeout = r.timeout ?? this.timeout;
    const { bodyHeaders: c, body: h } = this.buildBody({ options: r }), u = await this.buildHeaders({ options: e, method: s, bodyHeaders: c, retryCount: t });
    return { req: {
      method: s,
      headers: u,
      ...r.signal && { signal: r.signal },
      ...globalThis.ReadableStream && h instanceof globalThis.ReadableStream && { duplex: "half" },
      ...h && { body: h },
      ...this.fetchOptions ?? {},
      ...r.fetchOptions ?? {}
    }, url: l, timeout: r.timeout };
  }
  async buildHeaders({ options: e, method: t, bodyHeaders: r, retryCount: s }) {
    let i = {};
    this.idempotencyHeader && t !== "get" && (e.idempotencyKey || (e.idempotencyKey = this.defaultIdempotencyKey()), i[this.idempotencyHeader] = e.idempotencyKey);
    const a = k([
      i,
      {
        Accept: "application/json",
        "User-Agent": this.getUserAgent(),
        "X-Stainless-Retry-Count": String(s),
        ...e.timeout ? { "X-Stainless-Timeout": String(Math.trunc(e.timeout / 1e3)) } : {},
        ...Ka(),
        "OpenAI-Organization": this.organization,
        "OpenAI-Project": this.project
      },
      await this.authHeaders(e),
      this._options.defaultHeaders,
      r,
      e.headers
    ]);
    return this.validateHeaders(a), a.values;
  }
  _makeAbort(e) {
    return () => e.abort();
  }
  buildBody({ options: { body: e, headers: t } }) {
    if (!e)
      return { bodyHeaders: void 0, body: void 0 };
    const r = k([t]);
    return (
      // Pass raw type verbatim
      ArrayBuffer.isView(e) || e instanceof ArrayBuffer || e instanceof DataView || typeof e == "string" && // Preserve legacy string encoding behavior for now
      r.values.has("content-type") || // `Blob` is superset of `File`
      globalThis.Blob && e instanceof globalThis.Blob || // `FormData` -> `multipart/form-data`
      e instanceof FormData || // `URLSearchParams` -> `application/x-www-form-urlencoded`
      e instanceof URLSearchParams || // Send chunked stream (each chunk has own `length`)
      globalThis.ReadableStream && e instanceof globalThis.ReadableStream ? { bodyHeaders: void 0, body: e } : typeof e == "object" && (Symbol.asyncIterator in e || Symbol.iterator in e && "next" in e && typeof e.next == "function") ? { bodyHeaders: void 0, body: fs(e) } : typeof e == "object" && r.values.get("content-type") === "application/x-www-form-urlencoded" ? {
        bodyHeaders: { "content-type": "application/x-www-form-urlencoded" },
        body: this.stringifyQuery(e)
      } : d(this, Rt, "f").call(this, { body: e, headers: r })
    );
  }
}
rr = E, Rt = /* @__PURE__ */ new WeakMap(), En = /* @__PURE__ */ new WeakSet(), Ti = function() {
  return this.baseURL !== "https://api.openai.com/v1";
};
E.OpenAI = rr;
E.DEFAULT_TIMEOUT = 6e5;
E.OpenAIError = v;
E.APIError = z;
E.APIConnectionError = Ut;
E.APIConnectionTimeoutError = Mn;
E.APIUserAbortError = Y;
E.NotFoundError = rs;
E.ConflictError = ss;
E.RateLimitError = as;
E.BadRequestError = es;
E.AuthenticationError = ts;
E.InternalServerError = os;
E.PermissionDeniedError = ns;
E.UnprocessableEntityError = is;
E.InvalidWebhookSignatureError = We;
E.toFile = yo;
E.Completions = ii;
E.Chat = zn;
E.Embeddings = li;
E.Files = ui;
E.Images = gi;
E.Audio = lt;
E.Moderations = yi;
E.Models = wi;
E.FineTuning = Be;
E.Graders = Zn;
E.VectorStores = Yt;
E.Webhooks = Pi;
E.Beta = je;
E.Batches = Gs;
E.Uploads = nr;
E.Responses = Qt;
E.Realtime = Vt;
E.Conversations = Kn;
E.Evals = Vn;
E.Containers = Jn;
E.Skills = Gt;
E.Videos = $i;
const Oi = "jr-auto/fast", Mi = "https://api.justrelate.com/ai", qo = "https://6dyoi7w4yzq2bta2fh5hubtd4a0lnozo.lambda-url.eu-central-1.on.aws";
function Di(n, e) {
  const t = `${_a()}/${n}`, r = e || qo;
  return new URL(t, r).toString();
}
function Li({
  useAnonymously: n = !1,
  baseUrl: e,
  maxRetries: t,
  defaultHeaders: r
} = {}) {
  return new E({
    // note: this is a fake key, which is not used
    // we overwrite the authorization header in our fetch implementation
    apiKey: "dont-use-this-key",
    baseURL: Di("v1", e),
    defaultHeaders: { Accept: "*/*", ...r },
    dangerouslyAllowBrowser: !0,
    maxRetries: t,
    fetch: async (s, i) => {
      const a = Ho(i);
      return n ? fetch(s, { ...i, headers: a }) : ba(Mi, async (o) => {
        a.set("authorization", `Bearer ${o}`);
        const l = await fetch(s, { ...i, headers: a });
        return l.status === 401 ? { authenticationFailed: await l.json() } : { result: l };
      });
    }
  });
}
function Ho(n) {
  const e = new Headers(n?.headers);
  for (const t of [...e.keys()])
    t.toLowerCase().startsWith("x-") && e.delete(t);
  return e.delete("authorization"), e.set("content-type", "application/json"), e;
}
async function Jo() {
  const e = await Li().chat.completions.create({
    model: Oi,
    messages: [
      {
        role: "user",
        content: "Please tell me who you are."
      }
    ],
    stream: !0
  });
  for await (const t of e)
    console.log(t.choices[0]?.delta?.content || "");
}
typeof window < "u" && (window.runTest = Jo);
class Ko {
  stream;
  controller;
  closed = !1;
  constructor() {
    let e;
    this.stream = new ReadableStream({
      start(t) {
        e = t;
      }
    }), this.controller = e;
  }
  push(e) {
    this.closed || this.controller.enqueue(e);
  }
  close() {
    this.closed || (this.closed = !0, this.controller.close());
  }
  async *[Symbol.asyncIterator]() {
    const e = this.stream.getReader();
    for (; ; ) {
      const { value: t, done: r } = await e.read();
      if (r) return;
      yield t;
    }
  }
}
function Xo(n, e) {
  const t = n.split(`
`), r = t.flatMap((o, l) => {
    const c = o.match(/^ {0,3}```(\S+)/);
    return c && e.includes(c[1]) ? [{ index: l, blockType: c[1] }] : [];
  }), s = t.flatMap(
    (o, l) => /^ {0,3}```\s*$/.test(o) ? [l] : []
  ), i = [];
  let a = 0;
  for (const { index: o, blockType: l } of r) {
    Nr(i, t.slice(a, o).join(`
`));
    const c = s.find((h) => h > o);
    if (c !== void 0)
      i.push({
        type: "custom",
        blockType: l,
        content: t.slice(o + 1, c).join(`
`),
        isPartial: !1
      }), a = c + 1;
    else {
      const h = t.slice(o + 1), u = h[h.length - 1] ?? "", p = /^ {0,3}`{1,2}$/.test(u);
      i.push({
        type: "custom",
        blockType: l,
        content: (p ? h.slice(0, -1) : h).join(
          `
`
        ),
        isPartial: !0
      }), a = t.length;
    }
  }
  return Nr(i, t.slice(a).join(`
`)), i;
}
function Nr(n, e) {
  e.trim() !== "" && n.push({ type: "text", text: e });
}
function jr(n, { contentBlockTypes: e = [] } = {}) {
  return n.filter((t) => t.role !== "system").flatMap((t) => {
    const r = Vo(t, e);
    return r ? [r] : [];
  });
}
function Vo(n, e) {
  if (n.role === "user")
    return {
      role: "user",
      content: Pn(n.content)
    };
  if (n.role === "assistant") {
    const t = Go(n), r = (t?.length ?? 0) === 0;
    return {
      role: "assistant",
      content: Qo(
        n.content,
        e,
        r
      ),
      ...t !== void 0 && { tool_calls: t }
    };
  }
  if (n.role === "tool")
    return {
      role: "tool",
      content: Pn(n.content),
      tool_call_id: n.tool_call_id
    };
}
function Qo(n, e, t) {
  if (typeof n == "string") {
    const r = Xo(n, e);
    return t ? r : r.map(
      (s) => s.type === "custom" ? { ...s, isPartial: !1 } : s
    );
  }
  return Pn(n);
}
function Pn(n) {
  return typeof n == "string" ? n === "" ? [] : [{ type: "text", text: n }] : Array.isArray(n) ? n.filter(
    (e) => typeof e == "object" && e !== null && e.type === "text" && typeof e.text == "string"
  ) : [];
}
function Go(n) {
  return n.tool_calls?.filter((e) => "function" in e).map((e) => ({
    id: e.id,
    type: "function",
    function: {
      name: e.function.name,
      arguments: e.function.arguments
    }
  }));
}
class Yo {
  constructor(e) {
    this.types = e;
  }
  completedMessages = [];
  completedRawCount = 0;
  parse(e) {
    const t = e.filter((a) => a.role !== "system"), r = t.length - 1;
    if (r > this.completedRawCount) {
      const a = t.slice(
        this.completedRawCount,
        r
      );
      this.completedMessages = [
        ...this.completedMessages,
        ...jr(a, {
          contentBlockTypes: this.types
        })
      ], this.completedRawCount = r;
    }
    const s = r >= 0 ? t[r] : void 0, i = s ? jr([s], { contentBlockTypes: this.types }) : [];
    return [...this.completedMessages, ...i];
  }
}
const Nt = "checkContentBlockResult";
function Zo(n) {
  return {
    name: Nt,
    description: "Report on the special content code block(s) processed in the current assistant message. Returns a report of what was applied and any warnings. ONLY call this tool in an assistant message that contains at least one such code block, and only once per message. Do not call it in a message with no such block — there will be nothing to report.",
    parameters: {
      type: "object",
      properties: {},
      additionalProperties: !1
    },
    function: async () => {
      const { blockCount: e, reports: t } = await n.drainReports();
      return e === 0 ? "No special content code block was seen since the last check. Only call this tool in the same assistant message as such a block." : t.length === 0 ? "The content block(s) were processed successfully with nothing further to report." : t.join(`

---

`);
    }
  };
}
function el() {
  return `

After every message that contains one or more of the above special code blocks, call the \`${Nt}\` tool exactly once to verify what was applied and learn about any warnings. The tool call should come in the same message as the content block.`;
}
function tl(n, e) {
  if (!e.hasReports()) return n;
  if (n.some((t) => t.name === Nt))
    throw new Error(
      `Tool name "${Nt}" is reserved by llm-conversation for the content-block verifier and must not be declared by the caller.`
    );
  return [...n, Zo(e)];
}
let nl = sl;
function rl(n, e = {}) {
  return nl(n, e);
}
async function* sl(n, e) {
  const { tools: t, model: r, temperature: s, useAnonymously: i } = e, a = Li({
    useAnonymously: i,
    defaultHeaders: { Prefer: "cache-ttl=300" }
  }), o = {
    model: r ?? Oi,
    messages: al(n),
    temperature: s,
    stream: !0,
    stream_options: { include_usage: !0 }
  }, l = t?.length ? a.chat.completions.runTools({
    ...o,
    tools: t.map((c) => ({
      type: "function",
      function: c
    }))
  }) : a.chat.completions.stream(o);
  for await (const c of l) {
    const h = l.currentChatCompletionSnapshot?.choices[0], u = h ? il(h) : void 0, p = l.messages.slice(n.length);
    yield u ? [...p, u] : p;
  }
  yield l.messages.slice(n.length);
}
function il(n) {
  const e = n.message;
  if (e.role === "assistant")
    return {
      role: "assistant",
      content: e.content,
      tool_calls: e.tool_calls
    };
}
function al(n) {
  return n.map((e) => e.role !== "assistant" ? e : e.tool_calls && e.tool_calls.length > 0 ? {
    role: e.role,
    content: e.content,
    tool_calls: e.tool_calls
  } : { role: e.role, content: e.content });
}
class ol {
  constructor(e, t) {
    this.definitions = e, this.setData = t;
  }
  currentChannel = null;
  completedCount = 0;
  /** One entry per block encountered in the conversation, indexed the same
   *  way as `blocks` in `process()`. */
  runs = [];
  /** Cursor into `runs`: index of the first block not yet reported by
   *  `drainReports()`. */
  drainCursor = 0;
  getInstructions() {
    const e = `There are special markdown code blocks available that you can write to cause special effects. Each special code block uses a specific info string, that you must write after the three backtick code fence. Each of these special code blocks expects the content of the block to be formatted in a specific way. These are described below.

If you write a markdown code block without an info string (or with an unknown info string) these will be treated as regular markdown code blocks, without special effect.

The following special code blocks are available:`, t = this.definitions.map((r) => {
      const s = `\`\`\`${r.type}
/* replace with actual data */
\`\`\``;
      return r.description ? `${s}

${r.description}` : s;
    });
    return `${e}

${t.join(`

---

`)}`;
  }
  hasReports() {
    return this.definitions.some((e) => e.reportToAi);
  }
  process(e) {
    const t = [...ul(e)];
    for (let r = this.completedCount; r < t.length; r++) {
      const s = t[r];
      if (!this.currentChannel) {
        const i = this.definitions.find(
          (a) => a.type === s.blockType
        );
        if (!i) {
          s.isPartial || this.completedCount++;
          continue;
        }
        this.currentChannel = new Ko(), this.runs.push(
          new ll(
            i,
            this.currentChannel,
            this.completedCount,
            this.setData
          )
        );
      }
      if (this.currentChannel.push(s.content), s.isPartial) break;
      this.currentChannel.close(), this.currentChannel = null, this.completedCount++;
    }
  }
  async flush() {
    this.currentChannel && (this.currentChannel.close(), this.currentChannel = null, this.completedCount++), await Promise.all(this.runs.map((e) => e.done));
  }
  /** Wait for every block seen so far to finish `process` iteration, then
   *  return the non-null reports of blocks since the last drain.
   */
  async drainReports() {
    await Promise.all(this.runs.map((r) => r.done));
    const e = this.runs.slice(this.drainCursor);
    this.drainCursor = this.runs.length;
    const t = e.flatMap((r) => {
      const s = r.report();
      return s != null ? [s] : [];
    });
    return { blockCount: e.length, reports: t };
  }
}
class ll {
  constructor(e, t, r, s) {
    this.definition = e, this.done = this.run(t, r, s);
  }
  latest = null;
  done;
  report() {
    return this.latest ? this.definition.reportToAi?.(this.latest.value) ?? null : null;
  }
  async run(e, t, r) {
    for await (const s of this.definition.process(cl(e)))
      this.latest = { value: s }, r(t, s);
  }
}
async function* cl(n) {
  let e = "";
  for await (const t of n) {
    const r = t.slice(e.length);
    r && (yield r), e = t;
  }
}
function* ul(n) {
  for (const e of n)
    if (e.role === "assistant")
      for (const t of e.content)
        t.type === "custom" && (yield t);
}
async function hl(n) {
  return await (typeof n == "function" ? (
    // assumption: T is not a function
    n()
  ) : n);
}
class fl {
  state;
  listener;
  useAnonymously;
  parser;
  runner;
  constructor(e, t = [], { useAnonymously: r = !1, contentBlocks: s = [] } = {}) {
    this.listener = e, this.useAnonymously = r, this.parser = new Yo(s.map((i) => i.type)), this.runner = s.length ? new ol(
      s,
      (i, a) => this.setBlockData(i, a)
    ) : null, this.state = {
      rawApiMessages: t,
      isProcessing: !1,
      contentBlockData: []
    }, this.emitState();
  }
  getRawApiMessages() {
    return this.state.rawApiMessages;
  }
  async processUserMessage(e, t) {
    const r = {
      role: "user",
      content: t
    }, s = this.state.rawApiMessages;
    this.setState({
      ...this.state,
      rawApiMessages: [...s, r],
      isProcessing: !0
    });
    const { systemPrompt: i, tools: a, temperature: o, model: l } = await hl(e), c = this.runner ? `${i}

${this.runner.getInstructions()}${this.runner.hasReports() ? el() : ""}` : i, h = [
      ...pl(s, c),
      r
    ], u = rl(h, {
      tools: this.runner ? tl(a, this.runner) : a,
      model: l,
      temperature: o,
      useAnonymously: this.useAnonymously
    });
    try {
      for await (const p of u) {
        const f = [...h, ...p];
        this.setState({
          ...this.state,
          rawApiMessages: f,
          isProcessing: !0
        }), this.runner && this.runner.process(this.parser.parse(f));
      }
    } finally {
      try {
        this.runner && await this.runner.flush();
      } finally {
        this.setState({ ...this.state, isProcessing: !1 });
      }
    }
  }
  setBlockData(e, t) {
    const r = [...this.state.contentBlockData];
    r[e] = t, this.setState({ ...this.state, contentBlockData: r });
  }
  setState(e) {
    this.state = e, this.emitState();
  }
  emitState() {
    const e = this.parser.parse(this.state.rawApiMessages);
    this.listener({
      messages: dl(e, this.state.contentBlockData),
      isProcessing: this.state.isProcessing
    });
  }
}
function dl(n, e) {
  let t = 0;
  return n.map((r) => r.role !== "assistant" ? r : {
    ...r,
    content: r.content.map((s) => {
      if (s.type !== "custom") return s;
      const i = e[t++];
      return i !== void 0 ? { ...s, data: i } : s;
    })
  });
}
function pl(n, e) {
  return n.some((t) => t.role === "user") ? n : [
    {
      role: "system",
      // TODO move computeSystemMessage up
      content: e
    },
    ...n
  ];
}
const Fi = ka(async () => ({
  restApi: {
    url: Di("conversations"),
    audience: Mi
  },
  attributes: {}
})), Ni = {
  de: {
    placeholder: "Stelle eine Frage",
    helpPrompt: "Sag mir was du tun kannst, und mache Vorschläge für Fragen.",
    moreOptions: "Weitere Optionen",
    sendNow: "Absenden",
    disclaimer: "KI-generierte Antworten können ungenau sein. Überprüfen Sie wichtige Informationen.",
    help: "Hilfe",
    resetConversation: "Chat zurücksetzen",
    shareConversation: "Chat teilen"
  },
  en: {
    placeholder: "Ask anything",
    helpPrompt: "Please tell me what you can do, and suggest prompts to use.",
    moreOptions: "More options",
    sendNow: "Send now",
    disclaimer: "AI generated responses can be inaccurate. Check important information.",
    help: "Help",
    resetConversation: "Reset conversation",
    shareConversation: "Share conversation"
  },
  fr: {
    placeholder: "Posez une question",
    helpPrompt: "Dis-moi ce que tu peux faire et suggère des questions.",
    moreOptions: "Plus d'options",
    sendNow: "Envoyer",
    disclaimer: "Les réponses générées par l'IA peuvent être inexactes. Vérifiez les informations importantes.",
    help: "Aide",
    resetConversation: "Réinitialiser le chat",
    shareConversation: "Partager le chat"
  }
};
function ge(n) {
  const e = Qr(), t = ml(e) ? e : "en";
  return Ni[t][n];
}
function ml(n) {
  return !!n && n in Ni;
}
function gl(n) {
  const e = ve(), [t, r] = e, s = Re(!1);
  return we(() => {
    const i = window.localStorage.getItem(n);
    if (i) {
      const a = JSON.parse(i);
      r({ value: a });
    }
    s.current = !0;
  }, [n, r]), we(() => {
    if (t === void 0) return;
    const i = t.value;
    window.localStorage.setItem(n, JSON.stringify(i));
  }, [n, t]), [t?.value, (i) => r({ value: i })];
}
function Br(n, e) {
  const t = String(n);
  if (typeof e != "string")
    throw new TypeError("Expected character");
  let r = 0, s = t.indexOf(e);
  for (; s !== -1; )
    r++, s = t.indexOf(e, s + e.length);
  return r;
}
const rt = en(/[A-Za-z]/), sr = en(/[\dA-Za-z]/);
function wl(n) {
  return (
    // Special whitespace codes (which have negative values), C0 and Control
    // character DEL
    n !== null && (n < 32 || n === 127)
  );
}
function Ne(n) {
  return n !== null && n < -2;
}
function X(n) {
  return n !== null && (n < 0 || n === 32);
}
function ce(n) {
  return n === -2 || n === -1 || n === 32;
}
const Zt = en(new RegExp("\\p{P}|\\p{S}", "u")), Ie = en(/\s/);
function en(n) {
  return e;
  function e(t) {
    return t !== null && t > -1 && n.test(String.fromCharCode(t));
  }
}
function yl(n) {
  if (typeof n != "string")
    throw new TypeError("Expected a string");
  return n.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d");
}
const tn = (
  // Note: overloads in JSDoc can’t yet use different `@template`s.
  /**
   * @type {(
   *   (<Condition extends string>(test: Condition) => (node: unknown, index?: number | null | undefined, parent?: Parent | null | undefined, context?: unknown) => node is Node & {type: Condition}) &
   *   (<Condition extends Props>(test: Condition) => (node: unknown, index?: number | null | undefined, parent?: Parent | null | undefined, context?: unknown) => node is Node & Condition) &
   *   (<Condition extends TestFunction>(test: Condition) => (node: unknown, index?: number | null | undefined, parent?: Parent | null | undefined, context?: unknown) => node is Node & Predicate<Condition, Node>) &
   *   ((test?: null | undefined) => (node?: unknown, index?: number | null | undefined, parent?: Parent | null | undefined, context?: unknown) => node is Node) &
   *   ((test?: Test) => Check)
   * )}
   */
  /**
   * @param {Test} [test]
   * @returns {Check}
   */
  (function(n) {
    if (n == null)
      return xl;
    if (typeof n == "function")
      return nn(n);
    if (typeof n == "object")
      return Array.isArray(n) ? bl(n) : (
        // Cast because `ReadonlyArray` goes into the above but `isArray`
        // narrows to `Array`.
        _l(
          /** @type {Props} */
          n
        )
      );
    if (typeof n == "string")
      return kl(n);
    throw new Error("Expected function, string, or object as test");
  })
);
function bl(n) {
  const e = [];
  let t = -1;
  for (; ++t < n.length; )
    e[t] = tn(n[t]);
  return nn(r);
  function r(...s) {
    let i = -1;
    for (; ++i < e.length; )
      if (e[i].apply(this, s)) return !0;
    return !1;
  }
}
function _l(n) {
  const e = (
    /** @type {Record<string, unknown>} */
    n
  );
  return nn(t);
  function t(r) {
    const s = (
      /** @type {Record<string, unknown>} */
      /** @type {unknown} */
      r
    );
    let i;
    for (i in n)
      if (s[i] !== e[i]) return !1;
    return !0;
  }
}
function kl(n) {
  return nn(e);
  function e(t) {
    return t && t.type === n;
  }
}
function nn(n) {
  return e;
  function e(t, r, s) {
    return !!(Cl(t) && n.call(
      this,
      t,
      typeof r == "number" ? r : void 0,
      s || void 0
    ));
  }
}
function xl() {
  return !0;
}
function Cl(n) {
  return n !== null && typeof n == "object" && "type" in n;
}
const ji = [], Sl = !0, Tn = !1, vl = "skip";
function Bi(n, e, t, r) {
  let s;
  typeof e == "function" && typeof t != "function" ? (r = t, t = e) : s = e;
  const i = tn(s), a = r ? -1 : 1;
  o(n, void 0, [])();
  function o(l, c, h) {
    const u = (
      /** @type {Record<string, unknown>} */
      l && typeof l == "object" ? l : {}
    );
    if (typeof u.type == "string") {
      const f = (
        // `hast`
        typeof u.tagName == "string" ? u.tagName : (
          // `xast`
          typeof u.name == "string" ? u.name : void 0
        )
      );
      Object.defineProperty(p, "name", {
        value: "node (" + (l.type + (f ? "<" + f + ">" : "")) + ")"
      });
    }
    return p;
    function p() {
      let f = ji, m, y, x;
      if ((!e || i(l, c, h[h.length - 1] || void 0)) && (f = Al(t(l, h)), f[0] === Tn))
        return f;
      if ("children" in l && l.children) {
        const _ = (
          /** @type {UnistParent} */
          l
        );
        if (_.children && f[0] !== vl)
          for (y = (r ? _.children.length : -1) + a, x = h.concat(_); y > -1 && y < _.children.length; ) {
            const b = _.children[y];
            if (m = o(b, y, x)(), m[0] === Tn)
              return m;
            y = typeof m[1] == "number" ? m[1] : y + a;
          }
      }
      return f;
    }
  }
}
function Al(n) {
  return Array.isArray(n) ? n : typeof n == "number" ? [Sl, n] : n == null ? ji : [n];
}
function Rl(n, e, t) {
  const s = tn((t || {}).ignore || []), i = Il(e);
  let a = -1;
  for (; ++a < i.length; )
    Bi(n, "text", o);
  function o(c, h) {
    let u = -1, p;
    for (; ++u < h.length; ) {
      const f = h[u], m = p ? p.children : void 0;
      if (s(
        f,
        m ? m.indexOf(f) : void 0,
        p
      ))
        return;
      p = f;
    }
    if (p)
      return l(c, h);
  }
  function l(c, h) {
    const u = h[h.length - 1], p = i[a][0], f = i[a][1];
    let m = 0;
    const x = u.children.indexOf(c);
    let _ = !1, b = [];
    p.lastIndex = 0;
    let A = p.exec(c.value);
    for (; A; ) {
      const $ = A.index, P = {
        index: A.index,
        input: A.input,
        stack: [...h, c]
      };
      let T = f(...A, P);
      if (typeof T == "string" && (T = T.length > 0 ? { type: "text", value: T } : void 0), T === !1 ? p.lastIndex = $ + 1 : (m !== $ && b.push({
        type: "text",
        value: c.value.slice(m, $)
      }), Array.isArray(T) ? b.push(...T) : T && b.push(T), m = $ + A[0].length, _ = !0), !p.global)
        break;
      A = p.exec(c.value);
    }
    return _ ? (m < c.value.length && b.push({ type: "text", value: c.value.slice(m) }), u.children.splice(x, 1, ...b)) : b = [c], x + b.length;
  }
}
function Il(n) {
  const e = [];
  if (!Array.isArray(n))
    throw new TypeError("Expected find and replace tuple or list of tuples");
  const t = !n[0] || Array.isArray(n[0]) ? n : [n];
  let r = -1;
  for (; ++r < t.length; ) {
    const s = t[r];
    e.push([$l(s[0]), El(s[1])]);
  }
  return e;
}
function $l(n) {
  return typeof n == "string" ? new RegExp(yl(n), "g") : n;
}
function El(n) {
  return typeof n == "function" ? n : function() {
    return n;
  };
}
const fn = "phrasing", dn = ["autolink", "link", "image", "label"];
function Pl() {
  return {
    transforms: [Nl],
    enter: {
      literalAutolink: Ol,
      literalAutolinkEmail: pn,
      literalAutolinkHttp: pn,
      literalAutolinkWww: pn
    },
    exit: {
      literalAutolink: Fl,
      literalAutolinkEmail: Ll,
      literalAutolinkHttp: Ml,
      literalAutolinkWww: Dl
    }
  };
}
function Tl() {
  return {
    unsafe: [
      {
        character: "@",
        before: "[+\\-.\\w]",
        after: "[\\-.\\w]",
        inConstruct: fn,
        notInConstruct: dn
      },
      {
        character: ".",
        before: "[Ww]",
        after: "[\\-.\\w]",
        inConstruct: fn,
        notInConstruct: dn
      },
      {
        character: ":",
        before: "[ps]",
        after: "\\/",
        inConstruct: fn,
        notInConstruct: dn
      }
    ]
  };
}
function Ol(n) {
  this.enter({ type: "link", title: null, url: "", children: [] }, n);
}
function pn(n) {
  this.config.enter.autolinkProtocol.call(this, n);
}
function Ml(n) {
  this.config.exit.autolinkProtocol.call(this, n);
}
function Dl(n) {
  this.config.exit.data.call(this, n);
  const e = this.stack[this.stack.length - 1];
  e.type, e.url = "http://" + this.sliceSerialize(n);
}
function Ll(n) {
  this.config.exit.autolinkEmail.call(this, n);
}
function Fl(n) {
  this.exit(n);
}
function Nl(n) {
  Rl(
    n,
    [
      [/(https?:\/\/|www(?=\.))([-.\w]+)([^ \t\r\n]*)/gi, jl],
      [new RegExp("(?<=^|\\s|\\p{P}|\\p{S})([-.\\w+]+)@([-\\w]+(?:\\.[-\\w]+)+)", "gu"), Bl]
    ],
    { ignore: ["link", "linkReference"] }
  );
}
function jl(n, e, t, r, s) {
  let i = "";
  if (!Ui(s) || (/^w/i.test(e) && (t = e + t, e = "", i = "http://"), !Ul(t)))
    return !1;
  const a = Wl(t + r);
  if (!a[0]) return !1;
  const o = {
    type: "link",
    title: null,
    url: i + e + a[0],
    children: [{ type: "text", value: e + a[0] }]
  };
  return a[1] ? [o, { type: "text", value: a[1] }] : o;
}
function Bl(n, e, t, r) {
  return (
    // Not an expected previous character.
    !Ui(r, !0) || // Label ends in not allowed character.
    /[-\d_]$/.test(t) ? !1 : {
      type: "link",
      title: null,
      url: "mailto:" + e + "@" + t,
      children: [{ type: "text", value: e + "@" + t }]
    }
  );
}
function Ul(n) {
  const e = n.split(".");
  return !(e.length < 2 || e[e.length - 1] && (/_/.test(e[e.length - 1]) || !/[a-zA-Z\d]/.test(e[e.length - 1])) || e[e.length - 2] && (/_/.test(e[e.length - 2]) || !/[a-zA-Z\d]/.test(e[e.length - 2])));
}
function Wl(n) {
  const e = /[!"&'),.:;<>?\]}]+$/.exec(n);
  if (!e)
    return [n, void 0];
  n = n.slice(0, e.index);
  let t = e[0], r = t.indexOf(")");
  const s = Br(n, "(");
  let i = Br(n, ")");
  for (; r !== -1 && s > i; )
    n += t.slice(0, r + 1), t = t.slice(r + 1), r = t.indexOf(")"), i++;
  return [n, t];
}
function Ui(n, e) {
  const t = n.input.charCodeAt(n.index - 1);
  return (n.index === 0 || Ie(t) || Zt(t)) && // If it’s an email, the previous character should not be a slash.
  (!e || t !== 47);
}
function ct(n) {
  return n.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase();
}
Wi.peek = Gl;
function zl() {
  this.buffer();
}
function ql(n) {
  this.enter({ type: "footnoteReference", identifier: "", label: "" }, n);
}
function Hl() {
  this.buffer();
}
function Jl(n) {
  this.enter(
    { type: "footnoteDefinition", identifier: "", label: "", children: [] },
    n
  );
}
function Kl(n) {
  const e = this.resume(), t = this.stack[this.stack.length - 1];
  t.type, t.identifier = ct(
    this.sliceSerialize(n)
  ).toLowerCase(), t.label = e;
}
function Xl(n) {
  this.exit(n);
}
function Vl(n) {
  const e = this.resume(), t = this.stack[this.stack.length - 1];
  t.type, t.identifier = ct(
    this.sliceSerialize(n)
  ).toLowerCase(), t.label = e;
}
function Ql(n) {
  this.exit(n);
}
function Gl() {
  return "[";
}
function Wi(n, e, t, r) {
  const s = t.createTracker(r);
  let i = s.move("[^");
  const a = t.enter("footnoteReference"), o = t.enter("reference");
  return i += s.move(
    t.safe(t.associationId(n), { after: "]", before: i })
  ), o(), a(), i += s.move("]"), i;
}
function Yl() {
  return {
    enter: {
      gfmFootnoteCallString: zl,
      gfmFootnoteCall: ql,
      gfmFootnoteDefinitionLabelString: Hl,
      gfmFootnoteDefinition: Jl
    },
    exit: {
      gfmFootnoteCallString: Kl,
      gfmFootnoteCall: Xl,
      gfmFootnoteDefinitionLabelString: Vl,
      gfmFootnoteDefinition: Ql
    }
  };
}
function Zl(n) {
  let e = !1;
  return n && n.firstLineBlank && (e = !0), {
    handlers: { footnoteDefinition: t, footnoteReference: Wi },
    // This is on by default already.
    unsafe: [{ character: "[", inConstruct: ["label", "phrasing", "reference"] }]
  };
  function t(r, s, i, a) {
    const o = i.createTracker(a);
    let l = o.move("[^");
    const c = i.enter("footnoteDefinition"), h = i.enter("label");
    return l += o.move(
      i.safe(i.associationId(r), { before: l, after: "]" })
    ), h(), l += o.move("]:"), r.children && r.children.length > 0 && (o.shift(4), l += o.move(
      (e ? `
` : " ") + i.indentLines(
        i.containerFlow(r, o.current()),
        e ? zi : ec
      )
    )), c(), l;
  }
}
function ec(n, e, t) {
  return e === 0 ? n : zi(n, e, t);
}
function zi(n, e, t) {
  return (t ? "" : "    ") + n;
}
const tc = [
  "autolink",
  "destinationLiteral",
  "destinationRaw",
  "reference",
  "titleQuote",
  "titleApostrophe"
];
qi.peek = ac;
function nc() {
  return {
    canContainEols: ["delete"],
    enter: { strikethrough: sc },
    exit: { strikethrough: ic }
  };
}
function rc() {
  return {
    unsafe: [
      {
        character: "~",
        inConstruct: "phrasing",
        notInConstruct: tc
      }
    ],
    handlers: { delete: qi }
  };
}
function sc(n) {
  this.enter({ type: "delete", children: [] }, n);
}
function ic(n) {
  this.exit(n);
}
function qi(n, e, t, r) {
  const s = t.createTracker(r), i = t.enter("strikethrough");
  let a = s.move("~~");
  return a += t.containerPhrasing(n, {
    ...s.current(),
    before: a,
    after: "~"
  }), a += s.move("~~"), i(), a;
}
function ac() {
  return "~";
}
function oc(n) {
  return n.length;
}
function lc(n, e) {
  const t = e || {}, r = (t.align || []).concat(), s = t.stringLength || oc, i = [], a = [], o = [], l = [];
  let c = 0, h = -1;
  for (; ++h < n.length; ) {
    const y = [], x = [];
    let _ = -1;
    for (n[h].length > c && (c = n[h].length); ++_ < n[h].length; ) {
      const b = cc(n[h][_]);
      if (t.alignDelimiters !== !1) {
        const A = s(b);
        x[_] = A, (l[_] === void 0 || A > l[_]) && (l[_] = A);
      }
      y.push(b);
    }
    a[h] = y, o[h] = x;
  }
  let u = -1;
  if (typeof r == "object" && "length" in r)
    for (; ++u < c; )
      i[u] = Ur(r[u]);
  else {
    const y = Ur(r);
    for (; ++u < c; )
      i[u] = y;
  }
  u = -1;
  const p = [], f = [];
  for (; ++u < c; ) {
    const y = i[u];
    let x = "", _ = "";
    y === 99 ? (x = ":", _ = ":") : y === 108 ? x = ":" : y === 114 && (_ = ":");
    let b = t.alignDelimiters === !1 ? 1 : Math.max(
      1,
      l[u] - x.length - _.length
    );
    const A = x + "-".repeat(b) + _;
    t.alignDelimiters !== !1 && (b = x.length + b + _.length, b > l[u] && (l[u] = b), f[u] = b), p[u] = A;
  }
  a.splice(1, 0, p), o.splice(1, 0, f), h = -1;
  const m = [];
  for (; ++h < a.length; ) {
    const y = a[h], x = o[h];
    u = -1;
    const _ = [];
    for (; ++u < c; ) {
      const b = y[u] || "";
      let A = "", $ = "";
      if (t.alignDelimiters !== !1) {
        const P = l[u] - (x[u] || 0), T = i[u];
        T === 114 ? A = " ".repeat(P) : T === 99 ? P % 2 ? (A = " ".repeat(P / 2 + 0.5), $ = " ".repeat(P / 2 - 0.5)) : (A = " ".repeat(P / 2), $ = A) : $ = " ".repeat(P);
      }
      t.delimiterStart !== !1 && !u && _.push("|"), t.padding !== !1 && // Don’t add the opening space if we’re not aligning and the cell is
      // empty: there will be a closing space.
      !(t.alignDelimiters === !1 && b === "") && (t.delimiterStart !== !1 || u) && _.push(" "), t.alignDelimiters !== !1 && _.push(A), _.push(b), t.alignDelimiters !== !1 && _.push($), t.padding !== !1 && _.push(" "), (t.delimiterEnd !== !1 || u !== c - 1) && _.push("|");
    }
    m.push(
      t.delimiterEnd === !1 ? _.join("").replace(/ +$/, "") : _.join("")
    );
  }
  return m.join(`
`);
}
function cc(n) {
  return n == null ? "" : String(n);
}
function Ur(n) {
  const e = typeof n == "string" ? n.codePointAt(0) : 0;
  return e === 67 || e === 99 ? 99 : e === 76 || e === 108 ? 108 : e === 82 || e === 114 ? 114 : 0;
}
function uc(n, e, t, r) {
  const s = t.enter("blockquote"), i = t.createTracker(r);
  i.move("> "), i.shift(2);
  const a = t.indentLines(
    t.containerFlow(n, i.current()),
    hc
  );
  return s(), a;
}
function hc(n, e, t) {
  return ">" + (t ? "" : " ") + n;
}
function fc(n, e) {
  return Wr(n, e.inConstruct, !0) && !Wr(n, e.notInConstruct, !1);
}
function Wr(n, e, t) {
  if (typeof e == "string" && (e = [e]), !e || e.length === 0)
    return t;
  let r = -1;
  for (; ++r < e.length; )
    if (n.includes(e[r]))
      return !0;
  return !1;
}
function zr(n, e, t, r) {
  let s = -1;
  for (; ++s < t.unsafe.length; )
    if (t.unsafe[s].character === `
` && fc(t.stack, t.unsafe[s]))
      return /[ \t]/.test(r.before) ? "" : " ";
  return `\\
`;
}
function dc(n, e) {
  const t = String(n);
  let r = t.indexOf(e), s = r, i = 0, a = 0;
  if (typeof e != "string")
    throw new TypeError("Expected substring");
  for (; r !== -1; )
    r === s ? ++i > a && (a = i) : i = 1, s = r + e.length, r = t.indexOf(e, s);
  return a;
}
function pc(n, e) {
  return !!(e.options.fences === !1 && n.value && // If there’s no info…
  !n.lang && // And there’s a non-whitespace character…
  /[^ \r\n]/.test(n.value) && // And the value doesn’t start or end in a blank…
  !/^[\t ]*(?:[\r\n]|$)|(?:^|[\r\n])[\t ]*$/.test(n.value));
}
function mc(n) {
  const e = n.options.fence || "`";
  if (e !== "`" && e !== "~")
    throw new Error(
      "Cannot serialize code with `" + e + "` for `options.fence`, expected `` ` `` or `~`"
    );
  return e;
}
function gc(n, e, t, r) {
  const s = mc(t), i = n.value || "", a = s === "`" ? "GraveAccent" : "Tilde";
  if (pc(n, t)) {
    const u = t.enter("codeIndented"), p = t.indentLines(i, wc);
    return u(), p;
  }
  const o = t.createTracker(r), l = s.repeat(Math.max(dc(i, s) + 1, 3)), c = t.enter("codeFenced");
  let h = o.move(l);
  if (n.lang) {
    const u = t.enter(`codeFencedLang${a}`);
    h += o.move(
      t.safe(n.lang, {
        before: h,
        after: " ",
        encode: ["`"],
        ...o.current()
      })
    ), u();
  }
  if (n.lang && n.meta) {
    const u = t.enter(`codeFencedMeta${a}`);
    h += o.move(" "), h += o.move(
      t.safe(n.meta, {
        before: h,
        after: `
`,
        encode: ["`"],
        ...o.current()
      })
    ), u();
  }
  return h += o.move(`
`), i && (h += o.move(i + `
`)), h += o.move(l), c(), h;
}
function wc(n, e, t) {
  return (t ? "" : "    ") + n;
}
function ir(n) {
  const e = n.options.quote || '"';
  if (e !== '"' && e !== "'")
    throw new Error(
      "Cannot serialize title with `" + e + "` for `options.quote`, expected `\"`, or `'`"
    );
  return e;
}
function yc(n, e, t, r) {
  const s = ir(t), i = s === '"' ? "Quote" : "Apostrophe", a = t.enter("definition");
  let o = t.enter("label");
  const l = t.createTracker(r);
  let c = l.move("[");
  return c += l.move(
    t.safe(t.associationId(n), {
      before: c,
      after: "]",
      ...l.current()
    })
  ), c += l.move("]: "), o(), // If there’s no url, or…
  !n.url || // If there are control characters or whitespace.
  /[\0- \u007F]/.test(n.url) ? (o = t.enter("destinationLiteral"), c += l.move("<"), c += l.move(
    t.safe(n.url, { before: c, after: ">", ...l.current() })
  ), c += l.move(">")) : (o = t.enter("destinationRaw"), c += l.move(
    t.safe(n.url, {
      before: c,
      after: n.title ? " " : `
`,
      ...l.current()
    })
  )), o(), n.title && (o = t.enter(`title${i}`), c += l.move(" " + s), c += l.move(
    t.safe(n.title, {
      before: c,
      after: s,
      ...l.current()
    })
  ), c += l.move(s), o()), a(), c;
}
function bc(n) {
  const e = n.options.emphasis || "*";
  if (e !== "*" && e !== "_")
    throw new Error(
      "Cannot serialize emphasis with `" + e + "` for `options.emphasis`, expected `*`, or `_`"
    );
  return e;
}
function st(n) {
  return "&#x" + n.toString(16).toUpperCase() + ";";
}
function jt(n) {
  if (n === null || X(n) || Ie(n))
    return 1;
  if (Zt(n))
    return 2;
}
function Bt(n, e, t) {
  const r = jt(n), s = jt(e);
  return r === void 0 ? s === void 0 ? (
    // Letter inside:
    // we have to encode *both* letters for `_` as it is looser.
    // it already forms for `*` (and GFMs `~`).
    t === "_" ? { inside: !0, outside: !0 } : { inside: !1, outside: !1 }
  ) : s === 1 ? (
    // Whitespace inside: encode both (letter, whitespace).
    { inside: !0, outside: !0 }
  ) : (
    // Punctuation inside: encode outer (letter)
    { inside: !1, outside: !0 }
  ) : r === 1 ? s === void 0 ? (
    // Letter inside: already forms.
    { inside: !1, outside: !1 }
  ) : s === 1 ? (
    // Whitespace inside: encode both (whitespace).
    { inside: !0, outside: !0 }
  ) : (
    // Punctuation inside: already forms.
    { inside: !1, outside: !1 }
  ) : s === void 0 ? (
    // Letter inside: already forms.
    { inside: !1, outside: !1 }
  ) : s === 1 ? (
    // Whitespace inside: encode inner (whitespace).
    { inside: !0, outside: !1 }
  ) : (
    // Punctuation inside: already forms.
    { inside: !1, outside: !1 }
  );
}
Hi.peek = _c;
function Hi(n, e, t, r) {
  const s = bc(t), i = t.enter("emphasis"), a = t.createTracker(r), o = a.move(s);
  let l = a.move(
    t.containerPhrasing(n, {
      after: s,
      before: o,
      ...a.current()
    })
  );
  const c = l.charCodeAt(0), h = Bt(
    r.before.charCodeAt(r.before.length - 1),
    c,
    s
  );
  h.inside && (l = st(c) + l.slice(1));
  const u = l.charCodeAt(l.length - 1), p = Bt(r.after.charCodeAt(0), u, s);
  p.inside && (l = l.slice(0, -1) + st(u));
  const f = a.move(s);
  return i(), t.attentionEncodeSurroundingInfo = {
    after: p.outside,
    before: h.outside
  }, o + l + f;
}
function _c(n, e, t) {
  return t.options.emphasis || "*";
}
function kc(n, e, t, r) {
  let s, i, a;
  typeof e == "function" && typeof t != "function" ? (i = void 0, a = e, s = t) : (i = e, a = t, s = r), Bi(n, i, o, s);
  function o(l, c) {
    const h = c[c.length - 1], u = h ? h.children.indexOf(l) : void 0;
    return a(l, u, h);
  }
}
const xc = {};
function Ji(n, e) {
  const t = xc, r = typeof t.includeImageAlt == "boolean" ? t.includeImageAlt : !0, s = typeof t.includeHtml == "boolean" ? t.includeHtml : !0;
  return Ki(n, r, s);
}
function Ki(n, e, t) {
  if (Cc(n)) {
    if ("value" in n)
      return n.type === "html" && !t ? "" : n.value;
    if (e && "alt" in n && n.alt)
      return n.alt;
    if ("children" in n)
      return qr(n.children, e, t);
  }
  return Array.isArray(n) ? qr(n, e, t) : "";
}
function qr(n, e, t) {
  const r = [];
  let s = -1;
  for (; ++s < n.length; )
    r[s] = Ki(n[s], e, t);
  return r.join("");
}
function Cc(n) {
  return !!(n && typeof n == "object");
}
function Sc(n, e) {
  let t = !1;
  return kc(n, function(r) {
    if ("value" in r && /\r?\n|\r/.test(r.value) || r.type === "break")
      return t = !0, Tn;
  }), !!((!n.depth || n.depth < 3) && Ji(n) && (e.options.setext || t));
}
function vc(n, e, t, r) {
  const s = Math.max(Math.min(6, n.depth || 1), 1), i = t.createTracker(r);
  if (Sc(n, t)) {
    const h = t.enter("headingSetext"), u = t.enter("phrasing"), p = t.containerPhrasing(n, {
      ...i.current(),
      before: `
`,
      after: `
`
    });
    return u(), h(), p + `
` + (s === 1 ? "=" : "-").repeat(
      // The whole size…
      p.length - // Minus the position of the character after the last EOL (or
      // 0 if there is none)…
      (Math.max(p.lastIndexOf("\r"), p.lastIndexOf(`
`)) + 1)
    );
  }
  const a = "#".repeat(s), o = t.enter("headingAtx"), l = t.enter("phrasing");
  i.move(a + " ");
  let c = t.containerPhrasing(n, {
    before: "# ",
    after: `
`,
    ...i.current()
  });
  return /^[\t ]/.test(c) && (c = st(c.charCodeAt(0)) + c.slice(1)), c = c ? a + " " + c : a, t.options.closeAtx && (c += " " + a), l(), o(), c;
}
Xi.peek = Ac;
function Xi(n) {
  return n.value || "";
}
function Ac() {
  return "<";
}
Vi.peek = Rc;
function Vi(n, e, t, r) {
  const s = ir(t), i = s === '"' ? "Quote" : "Apostrophe", a = t.enter("image");
  let o = t.enter("label");
  const l = t.createTracker(r);
  let c = l.move("![");
  return c += l.move(
    t.safe(n.alt, { before: c, after: "]", ...l.current() })
  ), c += l.move("]("), o(), // If there’s no url but there is a title…
  !n.url && n.title || // If there are control characters or whitespace.
  /[\0- \u007F]/.test(n.url) ? (o = t.enter("destinationLiteral"), c += l.move("<"), c += l.move(
    t.safe(n.url, { before: c, after: ">", ...l.current() })
  ), c += l.move(">")) : (o = t.enter("destinationRaw"), c += l.move(
    t.safe(n.url, {
      before: c,
      after: n.title ? " " : ")",
      ...l.current()
    })
  )), o(), n.title && (o = t.enter(`title${i}`), c += l.move(" " + s), c += l.move(
    t.safe(n.title, {
      before: c,
      after: s,
      ...l.current()
    })
  ), c += l.move(s), o()), c += l.move(")"), a(), c;
}
function Rc() {
  return "!";
}
Qi.peek = Ic;
function Qi(n, e, t, r) {
  const s = n.referenceType, i = t.enter("imageReference");
  let a = t.enter("label");
  const o = t.createTracker(r);
  let l = o.move("![");
  const c = t.safe(n.alt, {
    before: l,
    after: "]",
    ...o.current()
  });
  l += o.move(c + "]["), a();
  const h = t.stack;
  t.stack = [], a = t.enter("reference");
  const u = t.safe(t.associationId(n), {
    before: l,
    after: "]",
    ...o.current()
  });
  return a(), t.stack = h, i(), s === "full" || !c || c !== u ? l += o.move(u + "]") : s === "shortcut" ? l = l.slice(0, -1) : l += o.move("]"), l;
}
function Ic() {
  return "!";
}
Gi.peek = $c;
function Gi(n, e, t) {
  let r = n.value || "", s = "`", i = -1;
  for (; new RegExp("(^|[^`])" + s + "([^`]|$)").test(r); )
    s += "`";
  for (/[^ \r\n]/.test(r) && (/^[ \r\n]/.test(r) && /[ \r\n]$/.test(r) || /^`|`$/.test(r)) && (r = " " + r + " "); ++i < t.unsafe.length; ) {
    const a = t.unsafe[i], o = t.compilePattern(a);
    let l;
    if (a.atBreak)
      for (; l = o.exec(r); ) {
        let c = l.index;
        r.charCodeAt(c) === 10 && r.charCodeAt(c - 1) === 13 && c--, r = r.slice(0, c) + " " + r.slice(l.index + 1);
      }
  }
  return s + r + s;
}
function $c() {
  return "`";
}
function Yi(n, e) {
  const t = Ji(n);
  return !!(!e.options.resourceLink && // If there’s a url…
  n.url && // And there’s a no title…
  !n.title && // And the content of `node` is a single text node…
  n.children && n.children.length === 1 && n.children[0].type === "text" && // And if the url is the same as the content…
  (t === n.url || "mailto:" + t === n.url) && // And that starts w/ a protocol…
  /^[a-z][a-z+.-]+:/i.test(n.url) && // And that doesn’t contain ASCII control codes (character escapes and
  // references don’t work), space, or angle brackets…
  !/[\0- <>\u007F]/.test(n.url));
}
Zi.peek = Ec;
function Zi(n, e, t, r) {
  const s = ir(t), i = s === '"' ? "Quote" : "Apostrophe", a = t.createTracker(r);
  let o, l;
  if (Yi(n, t)) {
    const h = t.stack;
    t.stack = [], o = t.enter("autolink");
    let u = a.move("<");
    return u += a.move(
      t.containerPhrasing(n, {
        before: u,
        after: ">",
        ...a.current()
      })
    ), u += a.move(">"), o(), t.stack = h, u;
  }
  o = t.enter("link"), l = t.enter("label");
  let c = a.move("[");
  return c += a.move(
    t.containerPhrasing(n, {
      before: c,
      after: "](",
      ...a.current()
    })
  ), c += a.move("]("), l(), // If there’s no url but there is a title…
  !n.url && n.title || // If there are control characters or whitespace.
  /[\0- \u007F]/.test(n.url) ? (l = t.enter("destinationLiteral"), c += a.move("<"), c += a.move(
    t.safe(n.url, { before: c, after: ">", ...a.current() })
  ), c += a.move(">")) : (l = t.enter("destinationRaw"), c += a.move(
    t.safe(n.url, {
      before: c,
      after: n.title ? " " : ")",
      ...a.current()
    })
  )), l(), n.title && (l = t.enter(`title${i}`), c += a.move(" " + s), c += a.move(
    t.safe(n.title, {
      before: c,
      after: s,
      ...a.current()
    })
  ), c += a.move(s), l()), c += a.move(")"), o(), c;
}
function Ec(n, e, t) {
  return Yi(n, t) ? "<" : "[";
}
ea.peek = Pc;
function ea(n, e, t, r) {
  const s = n.referenceType, i = t.enter("linkReference");
  let a = t.enter("label");
  const o = t.createTracker(r);
  let l = o.move("[");
  const c = t.containerPhrasing(n, {
    before: l,
    after: "]",
    ...o.current()
  });
  l += o.move(c + "]["), a();
  const h = t.stack;
  t.stack = [], a = t.enter("reference");
  const u = t.safe(t.associationId(n), {
    before: l,
    after: "]",
    ...o.current()
  });
  return a(), t.stack = h, i(), s === "full" || !c || c !== u ? l += o.move(u + "]") : s === "shortcut" ? l = l.slice(0, -1) : l += o.move("]"), l;
}
function Pc() {
  return "[";
}
function ar(n) {
  const e = n.options.bullet || "*";
  if (e !== "*" && e !== "+" && e !== "-")
    throw new Error(
      "Cannot serialize items with `" + e + "` for `options.bullet`, expected `*`, `+`, or `-`"
    );
  return e;
}
function Tc(n) {
  const e = ar(n), t = n.options.bulletOther;
  if (!t)
    return e === "*" ? "-" : "*";
  if (t !== "*" && t !== "+" && t !== "-")
    throw new Error(
      "Cannot serialize items with `" + t + "` for `options.bulletOther`, expected `*`, `+`, or `-`"
    );
  if (t === e)
    throw new Error(
      "Expected `bullet` (`" + e + "`) and `bulletOther` (`" + t + "`) to be different"
    );
  return t;
}
function Oc(n) {
  const e = n.options.bulletOrdered || ".";
  if (e !== "." && e !== ")")
    throw new Error(
      "Cannot serialize items with `" + e + "` for `options.bulletOrdered`, expected `.` or `)`"
    );
  return e;
}
function ta(n) {
  const e = n.options.rule || "*";
  if (e !== "*" && e !== "-" && e !== "_")
    throw new Error(
      "Cannot serialize rules with `" + e + "` for `options.rule`, expected `*`, `-`, or `_`"
    );
  return e;
}
function Mc(n, e, t, r) {
  const s = t.enter("list"), i = t.bulletCurrent;
  let a = n.ordered ? Oc(t) : ar(t);
  const o = n.ordered ? a === "." ? ")" : "." : Tc(t);
  let l = e && t.bulletLastUsed ? a === t.bulletLastUsed : !1;
  if (!n.ordered) {
    const h = n.children ? n.children[0] : void 0;
    if (
      // Bullet could be used as a thematic break marker:
      (a === "*" || a === "-") && // Empty first list item:
      h && (!h.children || !h.children[0]) && // Directly in two other list items:
      t.stack[t.stack.length - 1] === "list" && t.stack[t.stack.length - 2] === "listItem" && t.stack[t.stack.length - 3] === "list" && t.stack[t.stack.length - 4] === "listItem" && // That are each the first child.
      t.indexStack[t.indexStack.length - 1] === 0 && t.indexStack[t.indexStack.length - 2] === 0 && t.indexStack[t.indexStack.length - 3] === 0 && (l = !0), ta(t) === a && h
    ) {
      let u = -1;
      for (; ++u < n.children.length; ) {
        const p = n.children[u];
        if (p && p.type === "listItem" && p.children && p.children[0] && p.children[0].type === "thematicBreak") {
          l = !0;
          break;
        }
      }
    }
  }
  l && (a = o), t.bulletCurrent = a;
  const c = t.containerFlow(n, r);
  return t.bulletLastUsed = a, t.bulletCurrent = i, s(), c;
}
function Dc(n) {
  const e = n.options.listItemIndent || "one";
  if (e !== "tab" && e !== "one" && e !== "mixed")
    throw new Error(
      "Cannot serialize items with `" + e + "` for `options.listItemIndent`, expected `tab`, `one`, or `mixed`"
    );
  return e;
}
function Lc(n, e, t, r) {
  const s = Dc(t);
  let i = t.bulletCurrent || ar(t);
  e && e.type === "list" && e.ordered && (i = (typeof e.start == "number" && e.start > -1 ? e.start : 1) + (t.options.incrementListMarker === !1 ? 0 : e.children.indexOf(n)) + i);
  let a = i.length + 1;
  (s === "tab" || s === "mixed" && (e && e.type === "list" && e.spread || n.spread)) && (a = Math.ceil(a / 4) * 4);
  const o = t.createTracker(r);
  o.move(i + " ".repeat(a - i.length)), o.shift(a);
  const l = t.enter("listItem"), c = t.indentLines(
    t.containerFlow(n, o.current()),
    h
  );
  return l(), c;
  function h(u, p, f) {
    return p ? (f ? "" : " ".repeat(a)) + u : (f ? i : i + " ".repeat(a - i.length)) + u;
  }
}
function Fc(n, e, t, r) {
  const s = t.enter("paragraph"), i = t.enter("phrasing"), a = t.containerPhrasing(n, r);
  return i(), s(), a;
}
const Nc = (
  /** @type {(node?: unknown) => node is Exclude<PhrasingContent, Html>} */
  tn([
    "break",
    "delete",
    "emphasis",
    // To do: next major: removed since footnotes were added to GFM.
    "footnote",
    "footnoteReference",
    "image",
    "imageReference",
    "inlineCode",
    // Enabled by `mdast-util-math`:
    "inlineMath",
    "link",
    "linkReference",
    // Enabled by `mdast-util-mdx`:
    "mdxJsxTextElement",
    // Enabled by `mdast-util-mdx`:
    "mdxTextExpression",
    "strong",
    "text",
    // Enabled by `mdast-util-directive`:
    "textDirective"
  ])
);
function jc(n, e, t, r) {
  return (n.children.some(function(a) {
    return Nc(a);
  }) ? t.containerPhrasing : t.containerFlow).call(t, n, r);
}
function Bc(n) {
  const e = n.options.strong || "*";
  if (e !== "*" && e !== "_")
    throw new Error(
      "Cannot serialize strong with `" + e + "` for `options.strong`, expected `*`, or `_`"
    );
  return e;
}
na.peek = Uc;
function na(n, e, t, r) {
  const s = Bc(t), i = t.enter("strong"), a = t.createTracker(r), o = a.move(s + s);
  let l = a.move(
    t.containerPhrasing(n, {
      after: s,
      before: o,
      ...a.current()
    })
  );
  const c = l.charCodeAt(0), h = Bt(
    r.before.charCodeAt(r.before.length - 1),
    c,
    s
  );
  h.inside && (l = st(c) + l.slice(1));
  const u = l.charCodeAt(l.length - 1), p = Bt(r.after.charCodeAt(0), u, s);
  p.inside && (l = l.slice(0, -1) + st(u));
  const f = a.move(s + s);
  return i(), t.attentionEncodeSurroundingInfo = {
    after: p.outside,
    before: h.outside
  }, o + l + f;
}
function Uc(n, e, t) {
  return t.options.strong || "*";
}
function Wc(n, e, t, r) {
  return t.safe(n.value, r);
}
function zc(n) {
  const e = n.options.ruleRepetition || 3;
  if (e < 3)
    throw new Error(
      "Cannot serialize rules with repetition `" + e + "` for `options.ruleRepetition`, expected `3` or more"
    );
  return e;
}
function qc(n, e, t) {
  const r = (ta(t) + (t.options.ruleSpaces ? " " : "")).repeat(zc(t));
  return t.options.ruleSpaces ? r.slice(0, -1) : r;
}
const ra = {
  blockquote: uc,
  break: zr,
  code: gc,
  definition: yc,
  emphasis: Hi,
  hardBreak: zr,
  heading: vc,
  html: Xi,
  image: Vi,
  imageReference: Qi,
  inlineCode: Gi,
  link: Zi,
  linkReference: ea,
  list: Mc,
  listItem: Lc,
  paragraph: Fc,
  root: jc,
  strong: na,
  text: Wc,
  thematicBreak: qc
};
function Hc() {
  return {
    enter: {
      table: Jc,
      tableData: Hr,
      tableHeader: Hr,
      tableRow: Xc
    },
    exit: {
      codeText: Vc,
      table: Kc,
      tableData: mn,
      tableHeader: mn,
      tableRow: mn
    }
  };
}
function Jc(n) {
  const e = n._align;
  this.enter(
    {
      type: "table",
      align: e.map(function(t) {
        return t === "none" ? null : t;
      }),
      children: []
    },
    n
  ), this.data.inTable = !0;
}
function Kc(n) {
  this.exit(n), this.data.inTable = void 0;
}
function Xc(n) {
  this.enter({ type: "tableRow", children: [] }, n);
}
function mn(n) {
  this.exit(n);
}
function Hr(n) {
  this.enter({ type: "tableCell", children: [] }, n);
}
function Vc(n) {
  let e = this.resume();
  this.data.inTable && (e = e.replace(/\\([\\|])/g, Qc));
  const t = this.stack[this.stack.length - 1];
  t.type, t.value = e, this.exit(n);
}
function Qc(n, e) {
  return e === "|" ? e : n;
}
function Gc(n) {
  const e = n || {}, t = e.tableCellPadding, r = e.tablePipeAlign, s = e.stringLength, i = t ? " " : "|";
  return {
    unsafe: [
      { character: "\r", inConstruct: "tableCell" },
      { character: `
`, inConstruct: "tableCell" },
      // A pipe, when followed by a tab or space (padding), or a dash or colon
      // (unpadded delimiter row), could result in a table.
      { atBreak: !0, character: "|", after: "[	 :-]" },
      // A pipe in a cell must be encoded.
      { character: "|", inConstruct: "tableCell" },
      // A colon must be followed by a dash, in which case it could start a
      // delimiter row.
      { atBreak: !0, character: ":", after: "-" },
      // A delimiter row can also start with a dash, when followed by more
      // dashes, a colon, or a pipe.
      // This is a stricter version than the built in check for lists, thematic
      // breaks, and setex heading underlines though:
      // <https://github.com/syntax-tree/mdast-util-to-markdown/blob/51a2038/lib/unsafe.js#L57>
      { atBreak: !0, character: "-", after: "[:|-]" }
    ],
    handlers: {
      inlineCode: p,
      table: a,
      tableCell: l,
      tableRow: o
    }
  };
  function a(f, m, y, x) {
    return c(h(f, y, x), f.align);
  }
  function o(f, m, y, x) {
    const _ = u(f, y, x), b = c([_]);
    return b.slice(0, b.indexOf(`
`));
  }
  function l(f, m, y, x) {
    const _ = y.enter("tableCell"), b = y.enter("phrasing"), A = y.containerPhrasing(f, {
      ...x,
      before: i,
      after: i
    });
    return b(), _(), A;
  }
  function c(f, m) {
    return lc(f, {
      align: m,
      // @ts-expect-error: `markdown-table` types should support `null`.
      alignDelimiters: r,
      // @ts-expect-error: `markdown-table` types should support `null`.
      padding: t,
      // @ts-expect-error: `markdown-table` types should support `null`.
      stringLength: s
    });
  }
  function h(f, m, y) {
    const x = f.children;
    let _ = -1;
    const b = [], A = m.enter("table");
    for (; ++_ < x.length; )
      b[_] = u(x[_], m, y);
    return A(), b;
  }
  function u(f, m, y) {
    const x = f.children;
    let _ = -1;
    const b = [], A = m.enter("tableRow");
    for (; ++_ < x.length; )
      b[_] = l(x[_], f, m, y);
    return A(), b;
  }
  function p(f, m, y) {
    let x = ra.inlineCode(f, m, y);
    return y.stack.includes("tableCell") && (x = x.replace(/\|/g, "\\$&")), x;
  }
}
function Yc() {
  return {
    exit: {
      taskListCheckValueChecked: Jr,
      taskListCheckValueUnchecked: Jr,
      paragraph: eu
    }
  };
}
function Zc() {
  return {
    unsafe: [{ atBreak: !0, character: "-", after: "[:|-]" }],
    handlers: { listItem: tu }
  };
}
function Jr(n) {
  const e = this.stack[this.stack.length - 2];
  e.type, e.checked = n.type === "taskListCheckValueChecked";
}
function eu(n) {
  const e = this.stack[this.stack.length - 2];
  if (e && e.type === "listItem" && typeof e.checked == "boolean") {
    const t = this.stack[this.stack.length - 1];
    t.type;
    const r = t.children[0];
    if (r && r.type === "text") {
      const s = e.children;
      let i = -1, a;
      for (; ++i < s.length; ) {
        const o = s[i];
        if (o.type === "paragraph") {
          a = o;
          break;
        }
      }
      a === t && (r.value = r.value.slice(1), r.value.length === 0 ? t.children.shift() : t.position && r.position && typeof r.position.start.offset == "number" && (r.position.start.column++, r.position.start.offset++, t.position.start = Object.assign({}, r.position.start)));
    }
  }
  this.exit(n);
}
function tu(n, e, t, r) {
  const s = n.children[0], i = typeof n.checked == "boolean" && s && s.type === "paragraph", a = "[" + (n.checked ? "x" : " ") + "] ", o = t.createTracker(r);
  i && o.move(a);
  let l = ra.listItem(n, e, t, {
    ...r,
    ...o.current()
  });
  return i && (l = l.replace(/^(?:[*+-]|\d+\.)([\r\n]| {1,3})/, c)), l;
  function c(h) {
    return h + a;
  }
}
function nu() {
  return [
    Pl(),
    Yl(),
    nc(),
    Hc(),
    Yc()
  ];
}
function ru(n) {
  return {
    extensions: [
      Tl(),
      Zl(n),
      rc(),
      Gc(n),
      Zc()
    ]
  };
}
function It(n, e, t, r) {
  const s = n.length;
  let i = 0, a;
  if (e < 0 ? e = -e > s ? 0 : s + e : e = e > s ? s : e, t = t > 0 ? t : 0, r.length < 1e4)
    a = Array.from(r), a.unshift(e, t), n.splice(...a);
  else
    for (t && n.splice(e, t); i < r.length; )
      a = r.slice(i, i + 1e4), a.unshift(e, 0), n.splice(...a), i += 1e4, e += 1e4;
}
const Kr = {}.hasOwnProperty;
function su(n) {
  const e = {};
  let t = -1;
  for (; ++t < n.length; )
    iu(e, n[t]);
  return e;
}
function iu(n, e) {
  let t;
  for (t in e) {
    const s = (Kr.call(n, t) ? n[t] : void 0) || (n[t] = {}), i = e[t];
    let a;
    if (i)
      for (a in i) {
        Kr.call(s, a) || (s[a] = []);
        const o = i[a];
        au(
          // @ts-expect-error Looks like a list.
          s[a],
          Array.isArray(o) ? o : o ? [o] : []
        );
      }
  }
}
function au(n, e) {
  let t = -1;
  const r = [];
  for (; ++t < e.length; )
    (e[t].add === "after" ? n : r).push(e[t]);
  It(n, 0, 0, r);
}
const ou = {
  tokenize: du,
  partial: !0
}, sa = {
  tokenize: pu,
  partial: !0
}, ia = {
  tokenize: mu,
  partial: !0
}, aa = {
  tokenize: gu,
  partial: !0
}, lu = {
  tokenize: wu,
  partial: !0
}, oa = {
  name: "wwwAutolink",
  tokenize: hu,
  previous: ca
}, la = {
  name: "protocolAutolink",
  tokenize: fu,
  previous: ua
}, he = {
  name: "emailAutolink",
  tokenize: uu,
  previous: ha
}, ie = {};
function cu() {
  return {
    text: ie
  };
}
let be = 48;
for (; be < 123; )
  ie[be] = he, be++, be === 58 ? be = 65 : be === 91 && (be = 97);
ie[43] = he;
ie[45] = he;
ie[46] = he;
ie[95] = he;
ie[72] = [he, la];
ie[104] = [he, la];
ie[87] = [he, oa];
ie[119] = [he, oa];
function uu(n, e, t) {
  const r = this;
  let s, i;
  return a;
  function a(u) {
    return !On(u) || !ha.call(r, r.previous) || or(r.events) ? t(u) : (n.enter("literalAutolink"), n.enter("literalAutolinkEmail"), o(u));
  }
  function o(u) {
    return On(u) ? (n.consume(u), o) : u === 64 ? (n.consume(u), l) : t(u);
  }
  function l(u) {
    return u === 46 ? n.check(lu, h, c)(u) : u === 45 || u === 95 || sr(u) ? (i = !0, n.consume(u), l) : h(u);
  }
  function c(u) {
    return n.consume(u), s = !0, l;
  }
  function h(u) {
    return i && s && rt(r.previous) ? (n.exit("literalAutolinkEmail"), n.exit("literalAutolink"), e(u)) : t(u);
  }
}
function hu(n, e, t) {
  const r = this;
  return s;
  function s(a) {
    return a !== 87 && a !== 119 || !ca.call(r, r.previous) || or(r.events) ? t(a) : (n.enter("literalAutolink"), n.enter("literalAutolinkWww"), n.check(ou, n.attempt(sa, n.attempt(ia, i), t), t)(a));
  }
  function i(a) {
    return n.exit("literalAutolinkWww"), n.exit("literalAutolink"), e(a);
  }
}
function fu(n, e, t) {
  const r = this;
  let s = "", i = !1;
  return a;
  function a(u) {
    return (u === 72 || u === 104) && ua.call(r, r.previous) && !or(r.events) ? (n.enter("literalAutolink"), n.enter("literalAutolinkHttp"), s += String.fromCodePoint(u), n.consume(u), o) : t(u);
  }
  function o(u) {
    if (rt(u) && s.length < 5)
      return s += String.fromCodePoint(u), n.consume(u), o;
    if (u === 58) {
      const p = s.toLowerCase();
      if (p === "http" || p === "https")
        return n.consume(u), l;
    }
    return t(u);
  }
  function l(u) {
    return u === 47 ? (n.consume(u), i ? c : (i = !0, l)) : t(u);
  }
  function c(u) {
    return u === null || wl(u) || X(u) || Ie(u) || Zt(u) ? t(u) : n.attempt(sa, n.attempt(ia, h), t)(u);
  }
  function h(u) {
    return n.exit("literalAutolinkHttp"), n.exit("literalAutolink"), e(u);
  }
}
function du(n, e, t) {
  let r = 0;
  return s;
  function s(a) {
    return (a === 87 || a === 119) && r < 3 ? (r++, n.consume(a), s) : a === 46 && r === 3 ? (n.consume(a), i) : t(a);
  }
  function i(a) {
    return a === null ? t(a) : e(a);
  }
}
function pu(n, e, t) {
  let r, s, i;
  return a;
  function a(c) {
    return c === 46 || c === 95 ? n.check(aa, l, o)(c) : c === null || X(c) || Ie(c) || c !== 45 && Zt(c) ? l(c) : (i = !0, n.consume(c), a);
  }
  function o(c) {
    return c === 95 ? r = !0 : (s = r, r = void 0), n.consume(c), a;
  }
  function l(c) {
    return s || r || !i ? t(c) : e(c);
  }
}
function mu(n, e) {
  let t = 0, r = 0;
  return s;
  function s(a) {
    return a === 40 ? (t++, n.consume(a), s) : a === 41 && r < t ? i(a) : a === 33 || a === 34 || a === 38 || a === 39 || a === 41 || a === 42 || a === 44 || a === 46 || a === 58 || a === 59 || a === 60 || a === 63 || a === 93 || a === 95 || a === 126 ? n.check(aa, e, i)(a) : a === null || X(a) || Ie(a) ? e(a) : (n.consume(a), s);
  }
  function i(a) {
    return a === 41 && r++, n.consume(a), s;
  }
}
function gu(n, e, t) {
  return r;
  function r(o) {
    return o === 33 || o === 34 || o === 39 || o === 41 || o === 42 || o === 44 || o === 46 || o === 58 || o === 59 || o === 63 || o === 95 || o === 126 ? (n.consume(o), r) : o === 38 ? (n.consume(o), i) : o === 93 ? (n.consume(o), s) : (
      // `<` is an end.
      o === 60 || // So is whitespace.
      o === null || X(o) || Ie(o) ? e(o) : t(o)
    );
  }
  function s(o) {
    return o === null || o === 40 || o === 91 || X(o) || Ie(o) ? e(o) : r(o);
  }
  function i(o) {
    return rt(o) ? a(o) : t(o);
  }
  function a(o) {
    return o === 59 ? (n.consume(o), r) : rt(o) ? (n.consume(o), a) : t(o);
  }
}
function wu(n, e, t) {
  return r;
  function r(i) {
    return n.consume(i), s;
  }
  function s(i) {
    return sr(i) ? t(i) : e(i);
  }
}
function ca(n) {
  return n === null || n === 40 || n === 42 || n === 95 || n === 91 || n === 93 || n === 126 || X(n);
}
function ua(n) {
  return !rt(n);
}
function ha(n) {
  return !(n === 47 || On(n));
}
function On(n) {
  return n === 43 || n === 45 || n === 46 || n === 95 || sr(n);
}
function or(n) {
  let e = n.length, t = !1;
  for (; e--; ) {
    const r = n[e][1];
    if ((r.type === "labelLink" || r.type === "labelImage") && !r._balanced) {
      t = !0;
      break;
    }
    if (r._gfmAutolinkLiteralWalkedInto) {
      t = !1;
      break;
    }
  }
  return n.length > 0 && !t && (n[n.length - 1][1]._gfmAutolinkLiteralWalkedInto = !0), t;
}
function yu(n, e, t) {
  const r = [];
  let s = -1;
  for (; ++s < n.length; ) {
    const i = n[s].resolveAll;
    i && !r.includes(i) && (e = i(e, t), r.push(i));
  }
  return e;
}
function ue(n, e, t, r) {
  const s = r ? r - 1 : Number.POSITIVE_INFINITY;
  let i = 0;
  return a;
  function a(l) {
    return ce(l) ? (n.enter(t), o(l)) : e(l);
  }
  function o(l) {
    return ce(l) && i++ < s ? (n.consume(l), o) : (n.exit(t), e(l));
  }
}
const bu = {
  partial: !0,
  tokenize: _u
};
function _u(n, e, t) {
  return r;
  function r(i) {
    return ce(i) ? ue(n, s, "linePrefix")(i) : s(i);
  }
  function s(i) {
    return i === null || Ne(i) ? e(i) : t(i);
  }
}
const ku = {
  tokenize: $u,
  partial: !0
};
function xu() {
  return {
    document: {
      91: {
        name: "gfmFootnoteDefinition",
        tokenize: Au,
        continuation: {
          tokenize: Ru
        },
        exit: Iu
      }
    },
    text: {
      91: {
        name: "gfmFootnoteCall",
        tokenize: vu
      },
      93: {
        name: "gfmPotentialFootnoteCall",
        add: "after",
        tokenize: Cu,
        resolveTo: Su
      }
    }
  };
}
function Cu(n, e, t) {
  const r = this;
  let s = r.events.length;
  const i = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
  let a;
  for (; s--; ) {
    const l = r.events[s][1];
    if (l.type === "labelImage") {
      a = l;
      break;
    }
    if (l.type === "gfmFootnoteCall" || l.type === "labelLink" || l.type === "label" || l.type === "image" || l.type === "link")
      break;
  }
  return o;
  function o(l) {
    if (!a || !a._balanced)
      return t(l);
    const c = ct(r.sliceSerialize({
      start: a.end,
      end: r.now()
    }));
    return c.codePointAt(0) !== 94 || !i.includes(c.slice(1)) ? t(l) : (n.enter("gfmFootnoteCallLabelMarker"), n.consume(l), n.exit("gfmFootnoteCallLabelMarker"), e(l));
  }
}
function Su(n, e) {
  let t = n.length;
  for (; t--; )
    if (n[t][1].type === "labelImage" && n[t][0] === "enter") {
      n[t][1];
      break;
    }
  n[t + 1][1].type = "data", n[t + 3][1].type = "gfmFootnoteCallLabelMarker";
  const r = {
    type: "gfmFootnoteCall",
    start: Object.assign({}, n[t + 3][1].start),
    end: Object.assign({}, n[n.length - 1][1].end)
  }, s = {
    type: "gfmFootnoteCallMarker",
    start: Object.assign({}, n[t + 3][1].end),
    end: Object.assign({}, n[t + 3][1].end)
  };
  s.end.column++, s.end.offset++, s.end._bufferIndex++;
  const i = {
    type: "gfmFootnoteCallString",
    start: Object.assign({}, s.end),
    end: Object.assign({}, n[n.length - 1][1].start)
  }, a = {
    type: "chunkString",
    contentType: "string",
    start: Object.assign({}, i.start),
    end: Object.assign({}, i.end)
  }, o = [
    // Take the `labelImageMarker` (now `data`, the `!`)
    n[t + 1],
    n[t + 2],
    ["enter", r, e],
    // The `[`
    n[t + 3],
    n[t + 4],
    // The `^`.
    ["enter", s, e],
    ["exit", s, e],
    // Everything in between.
    ["enter", i, e],
    ["enter", a, e],
    ["exit", a, e],
    ["exit", i, e],
    // The ending (`]`, properly parsed and labelled).
    n[n.length - 2],
    n[n.length - 1],
    ["exit", r, e]
  ];
  return n.splice(t, n.length - t + 1, ...o), n;
}
function vu(n, e, t) {
  const r = this, s = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
  let i = 0, a;
  return o;
  function o(u) {
    return n.enter("gfmFootnoteCall"), n.enter("gfmFootnoteCallLabelMarker"), n.consume(u), n.exit("gfmFootnoteCallLabelMarker"), l;
  }
  function l(u) {
    return u !== 94 ? t(u) : (n.enter("gfmFootnoteCallMarker"), n.consume(u), n.exit("gfmFootnoteCallMarker"), n.enter("gfmFootnoteCallString"), n.enter("chunkString").contentType = "string", c);
  }
  function c(u) {
    if (
      // Too long.
      i > 999 || // Closing brace with nothing.
      u === 93 && !a || // Space or tab is not supported by GFM for some reason.
      // `\n` and `[` not being supported makes sense.
      u === null || u === 91 || X(u)
    )
      return t(u);
    if (u === 93) {
      n.exit("chunkString");
      const p = n.exit("gfmFootnoteCallString");
      return s.includes(ct(r.sliceSerialize(p))) ? (n.enter("gfmFootnoteCallLabelMarker"), n.consume(u), n.exit("gfmFootnoteCallLabelMarker"), n.exit("gfmFootnoteCall"), e) : t(u);
    }
    return X(u) || (a = !0), i++, n.consume(u), u === 92 ? h : c;
  }
  function h(u) {
    return u === 91 || u === 92 || u === 93 ? (n.consume(u), i++, c) : c(u);
  }
}
function Au(n, e, t) {
  const r = this, s = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
  let i, a = 0, o;
  return l;
  function l(m) {
    return n.enter("gfmFootnoteDefinition")._container = !0, n.enter("gfmFootnoteDefinitionLabel"), n.enter("gfmFootnoteDefinitionLabelMarker"), n.consume(m), n.exit("gfmFootnoteDefinitionLabelMarker"), c;
  }
  function c(m) {
    return m === 94 ? (n.enter("gfmFootnoteDefinitionMarker"), n.consume(m), n.exit("gfmFootnoteDefinitionMarker"), n.enter("gfmFootnoteDefinitionLabelString"), n.enter("chunkString").contentType = "string", h) : t(m);
  }
  function h(m) {
    if (
      // Too long.
      a > 999 || // Closing brace with nothing.
      m === 93 && !o || // Space or tab is not supported by GFM for some reason.
      // `\n` and `[` not being supported makes sense.
      m === null || m === 91 || X(m)
    )
      return t(m);
    if (m === 93) {
      n.exit("chunkString");
      const y = n.exit("gfmFootnoteDefinitionLabelString");
      return i = ct(r.sliceSerialize(y)), n.enter("gfmFootnoteDefinitionLabelMarker"), n.consume(m), n.exit("gfmFootnoteDefinitionLabelMarker"), n.exit("gfmFootnoteDefinitionLabel"), p;
    }
    return X(m) || (o = !0), a++, n.consume(m), m === 92 ? u : h;
  }
  function u(m) {
    return m === 91 || m === 92 || m === 93 ? (n.consume(m), a++, h) : h(m);
  }
  function p(m) {
    return m === 58 ? (n.enter("definitionMarker"), n.consume(m), n.exit("definitionMarker"), s.includes(i) || s.push(i), ue(n, f, "gfmFootnoteDefinitionWhitespace")) : t(m);
  }
  function f(m) {
    return e(m);
  }
}
function Ru(n, e, t) {
  return n.check(bu, e, n.attempt(ku, e, t));
}
function Iu(n) {
  n.exit("gfmFootnoteDefinition");
}
function $u(n, e, t) {
  const r = this;
  return ue(n, s, "gfmFootnoteDefinitionIndent", 5);
  function s(i) {
    const a = r.events[r.events.length - 1];
    return a && a[1].type === "gfmFootnoteDefinitionIndent" && a[2].sliceSerialize(a[1], !0).length === 4 ? e(i) : t(i);
  }
}
function Eu(n) {
  let t = (n || {}).singleTilde;
  const r = {
    name: "strikethrough",
    tokenize: i,
    resolveAll: s
  };
  return t == null && (t = !0), {
    text: {
      126: r
    },
    insideSpan: {
      null: [r]
    },
    attentionMarkers: {
      null: [126]
    }
  };
  function s(a, o) {
    let l = -1;
    for (; ++l < a.length; )
      if (a[l][0] === "enter" && a[l][1].type === "strikethroughSequenceTemporary" && a[l][1]._close) {
        let c = l;
        for (; c--; )
          if (a[c][0] === "exit" && a[c][1].type === "strikethroughSequenceTemporary" && a[c][1]._open && // If the sizes are the same:
          a[l][1].end.offset - a[l][1].start.offset === a[c][1].end.offset - a[c][1].start.offset) {
            a[l][1].type = "strikethroughSequence", a[c][1].type = "strikethroughSequence";
            const h = {
              type: "strikethrough",
              start: Object.assign({}, a[c][1].start),
              end: Object.assign({}, a[l][1].end)
            }, u = {
              type: "strikethroughText",
              start: Object.assign({}, a[c][1].end),
              end: Object.assign({}, a[l][1].start)
            }, p = [["enter", h, o], ["enter", a[c][1], o], ["exit", a[c][1], o], ["enter", u, o]], f = o.parser.constructs.insideSpan.null;
            f && It(p, p.length, 0, yu(f, a.slice(c + 1, l), o)), It(p, p.length, 0, [["exit", u, o], ["enter", a[l][1], o], ["exit", a[l][1], o], ["exit", h, o]]), It(a, c - 1, l - c + 3, p), l = c + p.length - 2;
            break;
          }
      }
    for (l = -1; ++l < a.length; )
      a[l][1].type === "strikethroughSequenceTemporary" && (a[l][1].type = "data");
    return a;
  }
  function i(a, o, l) {
    const c = this.previous, h = this.events;
    let u = 0;
    return p;
    function p(m) {
      return c === 126 && h[h.length - 1][1].type !== "characterEscape" ? l(m) : (a.enter("strikethroughSequenceTemporary"), f(m));
    }
    function f(m) {
      const y = jt(c);
      if (m === 126)
        return u > 1 ? l(m) : (a.consume(m), u++, f);
      if (u < 2 && !t) return l(m);
      const x = a.exit("strikethroughSequenceTemporary"), _ = jt(m);
      return x._open = !_ || _ === 2 && !!y, x._close = !y || y === 2 && !!_, o(m);
    }
  }
}
class Pu {
  /**
   * Create a new edit map.
   */
  constructor() {
    this.map = [];
  }
  /**
   * Create an edit: a remove and/or add at a certain place.
   *
   * @param {number} index
   * @param {number} remove
   * @param {Array<Event>} add
   * @returns {undefined}
   */
  add(e, t, r) {
    Tu(this, e, t, r);
  }
  // To do: add this when moving to `micromark`.
  // /**
  //  * Create an edit: but insert `add` before existing additions.
  //  *
  //  * @param {number} index
  //  * @param {number} remove
  //  * @param {Array<Event>} add
  //  * @returns {undefined}
  //  */
  // addBefore(index, remove, add) {
  //   addImplementation(this, index, remove, add, true)
  // }
  /**
   * Done, change the events.
   *
   * @param {Array<Event>} events
   * @returns {undefined}
   */
  consume(e) {
    if (this.map.sort(function(i, a) {
      return i[0] - a[0];
    }), this.map.length === 0)
      return;
    let t = this.map.length;
    const r = [];
    for (; t > 0; )
      t -= 1, r.push(e.slice(this.map[t][0] + this.map[t][1]), this.map[t][2]), e.length = this.map[t][0];
    r.push(e.slice()), e.length = 0;
    let s = r.pop();
    for (; s; ) {
      for (const i of s)
        e.push(i);
      s = r.pop();
    }
    this.map.length = 0;
  }
}
function Tu(n, e, t, r) {
  let s = 0;
  if (!(t === 0 && r.length === 0)) {
    for (; s < n.map.length; ) {
      if (n.map[s][0] === e) {
        n.map[s][1] += t, n.map[s][2].push(...r);
        return;
      }
      s += 1;
    }
    n.map.push([e, t, r]);
  }
}
function Ou(n, e) {
  let t = !1;
  const r = [];
  for (; e < n.length; ) {
    const s = n[e];
    if (t) {
      if (s[0] === "enter")
        s[1].type === "tableContent" && r.push(n[e + 1][1].type === "tableDelimiterMarker" ? "left" : "none");
      else if (s[1].type === "tableContent") {
        if (n[e - 1][1].type === "tableDelimiterMarker") {
          const i = r.length - 1;
          r[i] = r[i] === "left" ? "center" : "right";
        }
      } else if (s[1].type === "tableDelimiterRow")
        break;
    } else s[0] === "enter" && s[1].type === "tableDelimiterRow" && (t = !0);
    e += 1;
  }
  return r;
}
function Mu() {
  return {
    flow: {
      null: {
        name: "table",
        tokenize: Du,
        resolveAll: Lu
      }
    }
  };
}
function Du(n, e, t) {
  const r = this;
  let s = 0, i = 0, a;
  return o;
  function o(g) {
    let L = r.events.length - 1;
    for (; L > -1; ) {
      const $e = r.events[L][1].type;
      if ($e === "lineEnding" || // Note: markdown-rs uses `whitespace` instead of `linePrefix`
      $e === "linePrefix") L--;
      else break;
    }
    const ae = L > -1 ? r.events[L][1].type : null, fe = ae === "tableHead" || ae === "tableRow" ? T : l;
    return fe === T && r.parser.lazy[r.now().line] ? t(g) : fe(g);
  }
  function l(g) {
    return n.enter("tableHead"), n.enter("tableRow"), c(g);
  }
  function c(g) {
    return g === 124 || (a = !0, i += 1), h(g);
  }
  function h(g) {
    return g === null ? t(g) : Ne(g) ? i > 1 ? (i = 0, r.interrupt = !0, n.exit("tableRow"), n.enter("lineEnding"), n.consume(g), n.exit("lineEnding"), f) : t(g) : ce(g) ? ue(n, h, "whitespace")(g) : (i += 1, a && (a = !1, s += 1), g === 124 ? (n.enter("tableCellDivider"), n.consume(g), n.exit("tableCellDivider"), a = !0, h) : (n.enter("data"), u(g)));
  }
  function u(g) {
    return g === null || g === 124 || X(g) ? (n.exit("data"), h(g)) : (n.consume(g), g === 92 ? p : u);
  }
  function p(g) {
    return g === 92 || g === 124 ? (n.consume(g), u) : u(g);
  }
  function f(g) {
    return r.interrupt = !1, r.parser.lazy[r.now().line] ? t(g) : (n.enter("tableDelimiterRow"), a = !1, ce(g) ? ue(n, m, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(g) : m(g));
  }
  function m(g) {
    return g === 45 || g === 58 ? x(g) : g === 124 ? (a = !0, n.enter("tableCellDivider"), n.consume(g), n.exit("tableCellDivider"), y) : P(g);
  }
  function y(g) {
    return ce(g) ? ue(n, x, "whitespace")(g) : x(g);
  }
  function x(g) {
    return g === 58 ? (i += 1, a = !0, n.enter("tableDelimiterMarker"), n.consume(g), n.exit("tableDelimiterMarker"), _) : g === 45 ? (i += 1, _(g)) : g === null || Ne(g) ? $(g) : P(g);
  }
  function _(g) {
    return g === 45 ? (n.enter("tableDelimiterFiller"), b(g)) : P(g);
  }
  function b(g) {
    return g === 45 ? (n.consume(g), b) : g === 58 ? (a = !0, n.exit("tableDelimiterFiller"), n.enter("tableDelimiterMarker"), n.consume(g), n.exit("tableDelimiterMarker"), A) : (n.exit("tableDelimiterFiller"), A(g));
  }
  function A(g) {
    return ce(g) ? ue(n, $, "whitespace")(g) : $(g);
  }
  function $(g) {
    return g === 124 ? m(g) : g === null || Ne(g) ? !a || s !== i ? P(g) : (n.exit("tableDelimiterRow"), n.exit("tableHead"), e(g)) : P(g);
  }
  function P(g) {
    return t(g);
  }
  function T(g) {
    return n.enter("tableRow"), M(g);
  }
  function M(g) {
    return g === 124 ? (n.enter("tableCellDivider"), n.consume(g), n.exit("tableCellDivider"), M) : g === null || Ne(g) ? (n.exit("tableRow"), e(g)) : ce(g) ? ue(n, M, "whitespace")(g) : (n.enter("data"), O(g));
  }
  function O(g) {
    return g === null || g === 124 || X(g) ? (n.exit("data"), M(g)) : (n.consume(g), g === 92 ? D : O);
  }
  function D(g) {
    return g === 92 || g === 124 ? (n.consume(g), O) : O(g);
  }
}
function Lu(n, e) {
  let t = -1, r = !0, s = 0, i = [0, 0, 0, 0], a = [0, 0, 0, 0], o = !1, l = 0, c, h, u;
  const p = new Pu();
  for (; ++t < n.length; ) {
    const f = n[t], m = f[1];
    f[0] === "enter" ? m.type === "tableHead" ? (o = !1, l !== 0 && (Xr(p, e, l, c, h), h = void 0, l = 0), c = {
      type: "table",
      start: Object.assign({}, m.start),
      // Note: correct end is set later.
      end: Object.assign({}, m.end)
    }, p.add(t, 0, [["enter", c, e]])) : m.type === "tableRow" || m.type === "tableDelimiterRow" ? (r = !0, u = void 0, i = [0, 0, 0, 0], a = [0, t + 1, 0, 0], o && (o = !1, h = {
      type: "tableBody",
      start: Object.assign({}, m.start),
      // Note: correct end is set later.
      end: Object.assign({}, m.end)
    }, p.add(t, 0, [["enter", h, e]])), s = m.type === "tableDelimiterRow" ? 2 : h ? 3 : 1) : s && (m.type === "data" || m.type === "tableDelimiterMarker" || m.type === "tableDelimiterFiller") ? (r = !1, a[2] === 0 && (i[1] !== 0 && (a[0] = a[1], u = wt(p, e, i, s, void 0, u), i = [0, 0, 0, 0]), a[2] = t)) : m.type === "tableCellDivider" && (r ? r = !1 : (i[1] !== 0 && (a[0] = a[1], u = wt(p, e, i, s, void 0, u)), i = a, a = [i[1], t, 0, 0])) : m.type === "tableHead" ? (o = !0, l = t) : m.type === "tableRow" || m.type === "tableDelimiterRow" ? (l = t, i[1] !== 0 ? (a[0] = a[1], u = wt(p, e, i, s, t, u)) : a[1] !== 0 && (u = wt(p, e, a, s, t, u)), s = 0) : s && (m.type === "data" || m.type === "tableDelimiterMarker" || m.type === "tableDelimiterFiller") && (a[3] = t);
  }
  for (l !== 0 && Xr(p, e, l, c, h), p.consume(e.events), t = -1; ++t < e.events.length; ) {
    const f = e.events[t];
    f[0] === "enter" && f[1].type === "table" && (f[1]._align = Ou(e.events, t));
  }
  return n;
}
function wt(n, e, t, r, s, i) {
  const a = r === 1 ? "tableHeader" : r === 2 ? "tableDelimiter" : "tableData", o = "tableContent";
  t[0] !== 0 && (i.end = Object.assign({}, Le(e.events, t[0])), n.add(t[0], 0, [["exit", i, e]]));
  const l = Le(e.events, t[1]);
  if (i = {
    type: a,
    start: Object.assign({}, l),
    // Note: correct end is set later.
    end: Object.assign({}, l)
  }, n.add(t[1], 0, [["enter", i, e]]), t[2] !== 0) {
    const c = Le(e.events, t[2]), h = Le(e.events, t[3]), u = {
      type: o,
      start: Object.assign({}, c),
      end: Object.assign({}, h)
    };
    if (n.add(t[2], 0, [["enter", u, e]]), r !== 2) {
      const p = e.events[t[2]], f = e.events[t[3]];
      if (p[1].end = Object.assign({}, f[1].end), p[1].type = "chunkText", p[1].contentType = "text", t[3] > t[2] + 1) {
        const m = t[2] + 1, y = t[3] - t[2] - 1;
        n.add(m, y, []);
      }
    }
    n.add(t[3] + 1, 0, [["exit", u, e]]);
  }
  return s !== void 0 && (i.end = Object.assign({}, Le(e.events, s)), n.add(s, 0, [["exit", i, e]]), i = void 0), i;
}
function Xr(n, e, t, r, s) {
  const i = [], a = Le(e.events, t);
  s && (s.end = Object.assign({}, a), i.push(["exit", s, e])), r.end = Object.assign({}, a), i.push(["exit", r, e]), n.add(t + 1, 0, i);
}
function Le(n, e) {
  const t = n[e], r = t[0] === "enter" ? "start" : "end";
  return t[1][r];
}
const Fu = {
  name: "tasklistCheck",
  tokenize: ju
};
function Nu() {
  return {
    text: {
      91: Fu
    }
  };
}
function ju(n, e, t) {
  const r = this;
  return s;
  function s(l) {
    return (
      // Exit if there’s stuff before.
      r.previous !== null || // Exit if not in the first content that is the first child of a list
      // item.
      !r._gfmTasklistFirstContentOfListItem ? t(l) : (n.enter("taskListCheck"), n.enter("taskListCheckMarker"), n.consume(l), n.exit("taskListCheckMarker"), i)
    );
  }
  function i(l) {
    return X(l) ? (n.enter("taskListCheckValueUnchecked"), n.consume(l), n.exit("taskListCheckValueUnchecked"), a) : l === 88 || l === 120 ? (n.enter("taskListCheckValueChecked"), n.consume(l), n.exit("taskListCheckValueChecked"), a) : t(l);
  }
  function a(l) {
    return l === 93 ? (n.enter("taskListCheckMarker"), n.consume(l), n.exit("taskListCheckMarker"), n.exit("taskListCheck"), o) : t(l);
  }
  function o(l) {
    return Ne(l) ? e(l) : ce(l) ? n.check({
      tokenize: Bu
    }, e, t)(l) : t(l);
  }
}
function Bu(n, e, t) {
  return ue(n, r, "whitespace");
  function r(s) {
    return s === null ? t(s) : e(s);
  }
}
function Uu(n) {
  return su([
    cu(),
    xu(),
    Eu(n),
    Mu(),
    Nu()
  ]);
}
const Wu = {};
function zu(n) {
  const e = (
    /** @type {Processor<Root>} */
    this
  ), t = n || Wu, r = e.data(), s = r.micromarkExtensions || (r.micromarkExtensions = []), i = r.fromMarkdownExtensions || (r.fromMarkdownExtensions = []), a = r.toMarkdownExtensions || (r.toMarkdownExtensions = []);
  s.push(Uu(t)), i.push(nu()), a.push(ru(t));
}
const qu = `
    You can use Markdown to format your messages, including tables. Keep tables narrow (few columns, short cell content) since they are displayed in a narrow chat window.
    When you suggest a prompt, wrap it in a link using the anchor "run-prompt" like this: [the text of the prompt](#run-prompt). When suggesting multiple prompts, put each on its own line. Do not separate them with pipe characters.
    When referring to content with a _url attribute, always link using this URL: So if a content item has the title 'My Page' and the _url is 'https://example.com/my_page', you can link to it like this: [My Page](https://example.com/my_page).
  When showing or listing a data item of a certain data type (e.g. an order) and there is an _id attribute, always link to each item like this: [text](/_data-item/<the data type>/<the _id>), for example [this order](/_data-item/Order/1234).
  `;
async function Hu(n) {
  return {
    model: n.model,
    temperature: n.temperature,
    systemPrompt: await Ju(n),
    tools: fa(n)
  };
}
async function Ju(n) {
  const e = n.dataClasses && `This is the data model:
      ${await Oa(n.dataClasses)}`, t = `You respond in ${Ku()} unless instructed otherwise.`;
  return `${n.systemPrompt}

      ${t}

      ${e}

      ${qu}`;
}
function Ku() {
  return new Intl.DisplayNames(["en"], { type: "language" }).of(
    Qr() || "en"
  ) || "English";
}
function fa({
  sites: n,
  dataClasses: e,
  dataClassToolVersion: t,
  tools: r = []
}) {
  return [
    ...r.map(me),
    ...(e && Fa(t ?? "v1", e)) ?? [],
    ...(n && [Da(n)]) ?? []
  ];
}
function Xu({
  promptHistory: n,
  runPrompt: e
}) {
  return !n || !n.length ? null : /* @__PURE__ */ C(et, { children: /* @__PURE__ */ C("li", { className: "ai", children: /* @__PURE__ */ J("div", { className: "arrow-box", children: [
    /* @__PURE__ */ C("div", { className: "arrow-box-header", children: /* @__PURE__ */ C("span", { className: "user", children: "History" }) }),
    [...n].reverse().map((t, r) => /* @__PURE__ */ C("button", { type: "button", onClick: () => e(t), children: t }, r))
  ] }) }) });
}
const lr = Sa(null);
function Vu({
  chatLogRef: n,
  isLoading: e,
  showHistory: t,
  messages: r,
  promptHistory: s,
  runPrompt: i,
  config: a,
  systemMessage: o
}) {
  const l = Ra(a.contentBlocks);
  return /* @__PURE__ */ C("div", { ref: n, className: "jr-ai-assist-modal-body", children: /* @__PURE__ */ J("ul", { className: "jr-ai-assist-list-bubble", children: [
    !e && t && !r.length && /* @__PURE__ */ C(
      Xu,
      {
        promptHistory: s,
        runPrompt: (c) => i(c, "freetext")
      }
    ),
    /* @__PURE__ */ C(
      lr.Provider,
      {
        value: {
          onPromptClicked: (c) => i(c, "suggestion"),
          dataClasses: a.dataClasses
        },
        children: r.map((c, h) => /* @__PURE__ */ C(
          Qu,
          {
            config: a,
            message: c,
            renderMap: l
          },
          h
        ))
      }
    ),
    o && /* @__PURE__ */ C(rh, { message: o }),
    e && /* @__PURE__ */ C(nh, {})
  ] }) });
}
function Qu({ config: n, message: e, renderMap: t }) {
  if (e.role === "user")
    return /* @__PURE__ */ C(et, { children: e.content.map((s, i) => /* @__PURE__ */ C("li", { children: /* @__PURE__ */ C("div", { className: "arrow-box", children: s.text }) }, i)) });
  if (e.role === "assistant")
    return /* @__PURE__ */ J(et, { children: [
      e.content.map((s, i) => {
        if (s.type === "text")
          return /* @__PURE__ */ C("li", { className: "ai", children: /* @__PURE__ */ C("div", { className: "arrow-box", children: /* @__PURE__ */ C(da, { children: s.text }) }) }, `text-${i}`);
        const a = t.get(s.blockType);
        return !a || s.data === void 0 ? null : /* @__PURE__ */ C("li", { className: "ai", children: /* @__PURE__ */ C("div", { className: "arrow-box", children: /* @__PURE__ */ C(a, { ...s.data }) }) }, `custom-${i}`);
      }),
      e.tool_calls?.map((s, i) => {
        const a = r(s);
        return a && /* @__PURE__ */ C("li", { className: "ai", children: /* @__PURE__ */ C("div", { className: "arrow-box", children: a }) }, `tool-${i}`);
      })
    ] });
  return null;
  function r(s) {
    return fa(n).find(
      (a) => a.name === s.function.name
    )?.explanation?.(s.function.arguments);
  }
}
function da({ children: n }) {
  return /* @__PURE__ */ C(Aa, { remarkPlugins: [zu], components: { a: Gu }, children: n });
}
function Gu({ href: n, title: e, children: t }) {
  if (n === "#run-prompt")
    return /* @__PURE__ */ J(th, { children: [
      t,
      " "
    ] });
  if (n) {
    const r = eh(n);
    if (r)
      return /* @__PURE__ */ C(Yu, { ...r, children: t });
  }
  return /* @__PURE__ */ C("a", { href: n, target: "_blank", rel: "noreferrer", title: e, children: t });
}
const Yu = it(
  ({
    className: n,
    id: e,
    children: t
  }) => {
    const s = Gr(lr)?.dataClasses?.find(
      (a) => a.name() === n
    );
    if (s)
      try {
        const a = s.get(e);
        if (a)
          return /* @__PURE__ */ C(xa, { to: a, children: t });
      } catch (a) {
        console.error(a);
      }
    return /* @__PURE__ */ C("a", { href: i(), children: t });
    function i() {
      return `#_not_routable/${n}/${e}`;
    }
  }
), Zu = /^\/_data-item\/([^/]+)\/([^/]+)$/;
function eh(n) {
  const e = n.match(Zu);
  return e && e[1] && e[2] ? { className: e[1], id: e[2] } : null;
}
function th({ children: n }) {
  const e = Re(null), t = Gr(lr);
  return /* @__PURE__ */ C("button", { type: "button", ref: e, onClick: r, children: n });
  function r() {
    const s = e.current?.textContent;
    s && t?.onPromptClicked(s);
  }
}
function nh() {
  const [n, e] = ve(0);
  return we(() => {
    const t = () => e(n === 2 ? 0 : n + 1), r = window.setInterval(t, 500);
    return () => clearInterval(r);
  }, [n]), /* @__PURE__ */ C(et, { children: "•".repeat(n + 1) });
}
function rh({ message: n }) {
  const { content: e, onConfirm: t, onCancel: r } = n, s = Re(null);
  return we(() => {
    s.current && s.current.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [e]), /* @__PURE__ */ C("li", { ref: s, className: "ai", children: /* @__PURE__ */ J("div", { className: "arrow-box", children: [
    /* @__PURE__ */ C(da, { children: e }),
    t && /* @__PURE__ */ C("button", { type: "button", onClick: t, children: "Confirm" }),
    r && /* @__PURE__ */ C("button", { type: "button", onClick: r, children: "Cancel" })
  ] }) });
}
const sh = it(function({
  inputRef: e,
  placeholder: t,
  runPromptFromInput: r,
  isLoading: s
}) {
  return /* @__PURE__ */ J("div", { className: "jr-ai-assist-modal-footer", children: [
    /* @__PURE__ */ J("div", { className: "form-group", children: [
      /* @__PURE__ */ C(
        "span",
        {
          contentEditable: !s && "plaintext-only",
          role: "textbox",
          ref: e,
          className: "textarea",
          style: {
            "--placeholder-text": `"${t}"`
          },
          onKeyDown: i
        }
      ),
      /* @__PURE__ */ C("div", { className: "form-group-add", children: /* @__PURE__ */ C(
        "button",
        {
          type: "button",
          onClick: r,
          disabled: s,
          children: /* @__PURE__ */ C(
            "i",
            {
              className: "jr-ai-assist-icon-arrow",
              title: ge("sendNow")
            }
          )
        }
      ) })
    ] }),
    /* @__PURE__ */ C("p", { className: "jr-ai-assist-disclaimer", children: ge("disclaimer") })
  ] });
  function i(a) {
    !s && a.key === "Enter" && !a.shiftKey && (a.preventDefault(), r());
  }
});
function Vr({
  isVisible: n,
  onHide: e,
  displayMode: t,
  headerActions: r,
  children: s,
  inline: i
}) {
  let a = "jr-ai-assist-modal-wrapper";
  const o = i ? "inline" : n ? t : null;
  return o && (a += ` jr-ai-assist-${o}`), /* @__PURE__ */ J("div", { className: a, children: [
    /* @__PURE__ */ C("div", { className: "jr-ai-assist-modal-backdrop", onClick: e }),
    /* @__PURE__ */ J("div", { className: "jr-ai-assist-modal", children: [
      /* @__PURE__ */ C("div", { className: "jr-ai-assist-modal-header", children: /* @__PURE__ */ J("div", { className: "jr-ai-assist-modal-title", children: [
        /* @__PURE__ */ C("span", { className: "headline-5" }),
        r,
        /* @__PURE__ */ C("button", { type: "button", onClick: l, children: /* @__PURE__ */ C("i", { className: "jr-ai-assist-icon-chevron-down" }) })
      ] }) }),
      s
    ] })
  ] });
  function l(c) {
    c.stopPropagation(), e?.();
  }
}
const ih = it(function({
  isOpen: e,
  helpMeGetStarted: t,
  toggleOptions: r,
  resetConversation: s,
  conversationSharing: i,
  shareConversation: a
}) {
  return /* @__PURE__ */ J("ul", { className: `jr-ai-assist-dropdown-menu ${e ? "show" : ""}`, children: [
    /* @__PURE__ */ C("li", { children: /* @__PURE__ */ C(
      gn,
      {
        onClick: t,
        iconClassName: "jr-ai-assist-icon-help",
        title: ge("help")
      }
    ) }),
    /* @__PURE__ */ C("li", { children: /* @__PURE__ */ C(
      gn,
      {
        onClick: o,
        iconClassName: "jr-ai-assist-icon-reset",
        title: ge("resetConversation")
      }
    ) }),
    i && /* @__PURE__ */ C("li", { children: /* @__PURE__ */ C(
      gn,
      {
        onClick: a,
        iconClassName: "jr-ai-assist-icon-share",
        title: ge("shareConversation")
      }
    ) })
  ] });
  function o() {
    r(), s();
  }
});
function gn({
  onClick: n,
  iconClassName: e,
  title: t
}) {
  return /* @__PURE__ */ J(
    "button",
    {
      type: "button",
      className: "jr-ai-assist-dropdown-item",
      onClick: n,
      children: [
        /* @__PURE__ */ C("i", { className: e, title: t }),
        /* @__PURE__ */ C("span", { children: t })
      ]
    }
  );
}
const ah = it(function({
  config: e,
  messages: t,
  getRawApiMessages: r,
  processUserMessage: s,
  startNewConversation: i,
  isLoading: a,
  systemMessage: o,
  setSystemMessage: l,
  isVisible: c,
  onHide: h,
  conversationSharing: u,
  showHistory: p,
  defaultDisplayMode: f,
  inline: m
}) {
  const [y, x] = ve(!1), [_, b] = ve(f), A = Re(null), $ = Re(null), P = xe(() => {
    l(null), i(), A.current?.focus();
  }, [l, i]), T = xe(
    (q) => {
      q.metaKey && q.key === "k" && P();
    },
    [P]
  );
  we(() => (document.addEventListener("keydown", T), () => {
    document.removeEventListener("keydown", T);
  }), [T]), we(() => {
    $.current && $.current.scrollTo({
      top: $.current.scrollHeight,
      behavior: "smooth"
    });
  }, [t.length]);
  const [M, O] = gl("promptHistory"), D = ge("placeholder"), g = xe(
    (q, Z) => {
      l({
        content: q,
        onConfirm: Z,
        onCancel: () => l(null)
      });
    },
    [l]
  );
  if (!e)
    return /* @__PURE__ */ J(
      Vr,
      {
        isVisible: c,
        onHide: h,
        displayMode: _,
        inline: m,
        children: [
          /* @__PURE__ */ C("div", { className: "jr-ai-assist-modal-body", children: /* @__PURE__ */ C("div", { className: "jr-ai-assist-loader" }) }),
          /* @__PURE__ */ C("div", { className: "jr-ai-assist-modal-footer" })
        ]
      }
    );
  return /* @__PURE__ */ J(
    Vr,
    {
      isVisible: c,
      onHide: h,
      displayMode: _,
      inline: m,
      headerActions: /* @__PURE__ */ J(et, { children: [
        /* @__PURE__ */ C("button", { onClick: ye, children: /* @__PURE__ */ C(
          "i",
          {
            className: "jr-ai-assist-icon-dots",
            title: ge("moreOptions")
          }
        ) }),
        /* @__PURE__ */ C(
          ih,
          {
            isOpen: y,
            helpMeGetStarted: fe,
            toggleOptions: ye,
            resetConversation: P,
            conversationSharing: u,
            shareConversation: pa
          }
        ),
        /* @__PURE__ */ C("button", { type: "button", onClick: $e, children: /* @__PURE__ */ C(
          "i",
          {
            className: `jr-ai-assist-icon-${_ === "floating" ? "max" : "min"}`
          }
        ) })
      ] }),
      children: [
        /* @__PURE__ */ C(
          Vu,
          {
            chatLogRef: $,
            isLoading: a,
            showHistory: p,
            messages: t,
            promptHistory: M,
            runPrompt: ae,
            config: e,
            systemMessage: o
          }
        ),
        /* @__PURE__ */ C(
          sh,
          {
            inputRef: A,
            placeholder: D,
            runPromptFromInput: L,
            isLoading: a
          }
        )
      ]
    }
  );
  function L() {
    const q = A.current;
    if (!q) return;
    const Z = q.innerText;
    if (!Z) return;
    q.innerText = "";
    const cr = M ? M.slice(0, 50) : [], ma = cr.some(
      (ga) => ga.toLowerCase() === Z.toLowerCase()
    );
    t.length === 0 && !ma && O([...cr, Z]), ae(Z, "freetext");
  }
  function ae(q, Z) {
    l(null), s(q, Z);
  }
  function fe() {
    ye(), ae(ge("helpPrompt"), "suggestion");
  }
  function $e() {
    b((q) => q === "overlay" ? "floating" : "overlay");
  }
  function ye() {
    x((q) => !q);
  }
  async function pa() {
    ye(), !(!e || t.length === 0) && g(
      "Share this conversation? This will create a permanent link which can be accessed by every registered user of your instance who obtains it.",
      async () => {
        const q = await Fi.create({
          model: e.model,
          messages: r()
        }), Z = `${window.location.origin}${window.location.pathname}?sharedConversationId=${q.id()}`;
        window.navigator.clipboard.writeText(Z), l({
          content: `Conversation shared! [URL](${Z}) copied to clipboard`
        });
      }
    );
  }
}), Ah = it(function({
  config: e,
  isVisible: t = !0,
  onHide: r,
  conversationSharing: s,
  showHistory: i,
  defaultDisplayMode: a = "floating",
  inline: o,
  onSend: l
}) {
  const { initialMessages: c, initialUserPrompt: h } = va(
    M,
    [e]
  ), [u, p] = ve(
    { messages: [], isProcessing: !1 }
  ), [f, m] = ve(
    null
  ), [y, x] = ve(!1), _ = xe(
    (O = c) => new fl(p, O, {
      useAnonymously: e?.useAnonymously,
      contentBlocks: e?.contentBlocks
    }),
    [
      p,
      c,
      e?.useAnonymously,
      e?.contentBlocks
    ]
  ), b = xe(async () => {
    if (!s) return;
    const O = new URLSearchParams(
      window.location.search
    ).get("sharedConversationId");
    if (!O) return;
    x(!0);
    const D = await Ae(
      () => Fi.get(O)
    );
    D ? (P.current = _(
      D.get("messages")
    ), m(null)) : m({
      content: `Shared conversation ${O} not found.`
    }), x(!1);
  }, [s, _]), A = xe(() => {
    P.current = _();
  }, [_]), $ = xe(
    async (O, D) => {
      if (e) {
        l?.(O, {
          conversationDepth: u.messages.filter(
            (g) => g.role === "user"
          ).length,
          source: D
        });
        try {
          await P.current?.processUserMessage(
            Hu(e),
            O
          );
        } catch (g) {
          console.error(g);
          const L = g instanceof Error ? g.toString() : JSON.stringify(g);
          m({ content: L });
        }
      }
    },
    [e, u.messages, l]
  ), P = Re(null);
  e && !P.current && (P.current = _());
  const T = Re(!1);
  return we(() => {
    b();
  }, [b]), we(() => {
    h && !T.current && ($(h, "freetext"), T.current = !0);
  }, [h, $]), /* @__PURE__ */ C(
    ah,
    {
      processUserMessage: $,
      messages: u.messages,
      getRawApiMessages: () => P.current?.getRawApiMessages() ?? [],
      config: e,
      startNewConversation: A,
      isLoading: u.isProcessing || y,
      systemMessage: f,
      setSystemMessage: m,
      conversationSharing: s && Ca()?.email().endsWith("@justrelate.com"),
      showHistory: i,
      isVisible: t,
      onHide: r,
      defaultDisplayMode: a,
      inline: o
    }
  );
  function M() {
    const O = e?.initialMessages || [], D = O.at(-1);
    return D?.role === "user" && typeof D.content == "string" ? {
      initialMessages: O.slice(0, -1),
      initialUserPrompt: D.content
    } : { initialMessages: O, initialUserPrompt: void 0 };
  }
});
export {
  Ah as Chatbot,
  Li as createClient,
  dh as defineContentBlock,
  Pa as formatObj,
  me as resolveTool
};
//# sourceMappingURL=index.js.map
