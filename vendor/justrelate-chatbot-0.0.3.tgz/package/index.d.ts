import { ComponentType } from 'react';
import { ContentBlockDefinition } from '@justrelate/llm-conversation';
import { createClient } from '@justrelate/llm-conversation';
import { DataClass } from 'scrivito';
import { ReactNode } from 'react';
import { ResolvedToolDefinition } from '@justrelate/llm-conversation';
import { z } from 'zod';

export declare const Chatbot: {
    (props: ChatbotProps): ReactNode;
    displayName?: string | undefined;
};

declare interface ChatbotProps {
    config: LlmConfig | null;
    isVisible?: boolean;
    onHide?: () => void;
    conversationSharing?: boolean;
    showHistory?: boolean;
    defaultDisplayMode?: DisplayMode;
    inline?: boolean;
    onSend?: SendCallback;
}

export declare interface ContentBlockType<T extends object = object> extends ContentBlockDefinition<T> {
    render?: ComponentType<T>;
}

export { createClient }

export declare function defineContentBlock<T extends object>(type: ContentBlockType<T>): ContentBlockType<T>;

export declare type DisplayMode = 'floating' | 'overlay';

export declare function formatObj(obj: Record<string, unknown>): Promise<string>;

declare type InitialMessage = {
    role: 'user' | 'assistant';
    content: string;
};

export declare interface LlmConfig {
    systemPrompt: string;
    model?: string;
    temperature?: number;
    useAnonymously?: boolean;
    initialMessages?: InitialMessage[];
    sites?: Record<string, WebsiteConfig>;
    tools?: ToolDefinition<unknown>[];
    contentBlocks?: ContentBlockType[];
    dataClasses?: DataClass[];
    dataClassToolVersion?: 'v1' | 'v2';
}

export declare function resolveTool<T>({ name, run, parameters, description, explanation, }: ToolDefinition<T>): ResolvedToolDefinition;

export declare type SendCallback = (userMessage: string, meta: {
    conversationDepth: number;
    source: UserInputSource;
}) => void;

export declare interface ToolDefinition<T> {
    name: string;
    description: string;
    parameters: z.ZodType<T>;
    explanation?: (args: T) => string;
    run: (args: T) => Promise<unknown>;
}

declare type UserInputSource = 'freetext' | 'suggestion';

declare interface WebsiteConfig {
    instanceId: string;
    baseUrl: string;
    siteId: string;
}

export { }
