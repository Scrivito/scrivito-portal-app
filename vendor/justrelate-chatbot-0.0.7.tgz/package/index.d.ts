import { ComponentType } from 'react';
import { createClient } from '@justrelate/llm-conversation';
import { DataClass } from 'scrivito';
import { JSX } from 'react/jsx-runtime';
import { ResolvedToolDefinition } from '@justrelate/llm-conversation';
import { z } from 'zod';

export declare function Chatbot({ language, ...props }: ChatbotProps): JSX.Element;

declare interface ChatbotProps {
    config: LlmConfig | null;
    language?: Language;
    isVisible?: boolean;
    onHide?: () => void;
    showHistory?: boolean;
    defaultDisplayMode?: DisplayMode;
    inline?: boolean;
    colorScheme?: ColorScheme;
    onSend?: SendCallback;
}

declare type ColorScheme = 'light' | 'dark' | 'system';

export declare interface ComponentToolDefinition<T> {
    name: string;
    description: string;
    parameters: z.ZodObject & z.ZodType<T>;
    render: ComponentType<T & object>;
    run?: never;
    runStreaming?: never;
}

export { createClient }

export declare type DisplayMode = 'floating' | 'overlay';

export declare function formatObj(obj: Record<string, unknown>): Promise<string>;

declare type InitialMessage = {
    role: 'user' | 'assistant';
    content: string;
};

declare type Language = 'de' | 'en' | 'fr';

export declare interface LlmConfig {
    systemPrompt: string;
    dataClasses?: DataClass[];
    dataClassToolVersion?: 'v1' | 'v2';
    initialMessages?: InitialMessage[];
    instanceId?: string;
    model?: string;
    sites?: Record<string, WebsiteConfig>;
    systemNotice?: () => Promise<string | null>;
    temperature?: number;
    tools?: ToolDefinition<unknown>[];
    useAnonymously?: boolean;
}

export declare function resolveTool<T>(tool: ToolDefinition<T>): ResolvedToolDefinition;

export declare type SendCallback = (userMessage: string, meta: {
    conversationDepth: number;
    source: UserInputSource;
}) => void;

export declare interface StreamingToolDefinition {
    name: string;
    description: string;
    parameters: z.ZodObject;
    explanation?: (args: ToolArgsSnapshot) => string | undefined;
    run?: never;
    runStreaming: (argsStream: AsyncIterable<ToolArgsSnapshot>) => Promise<string>;
    render?: never;
}

export declare type ToolArgsSnapshot = Record<string, unknown>;

export declare type ToolDefinition<T = unknown> = TypedToolDefinition<T> | StreamingToolDefinition | ComponentToolDefinition<T>;

declare interface TypedToolDefinition<T> {
    name: string;
    description: string;
    parameters: z.ZodObject & z.ZodType<T>;
    explanation?: (args: T) => string;
    run: (args: T) => Promise<unknown>;
    runStreaming?: never;
    render?: never;
}

declare type UserInputSource = 'freetext' | 'suggestion';

declare interface WebsiteConfig {
    instanceId: string;
    baseUrl: string;
    siteId: string;
}

export { }
