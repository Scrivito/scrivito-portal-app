(function(){"use strict";try{if(typeof document<"u"){var t=document.createElement("style");t.appendChild(document.createTextNode(`[data-tooltip]{position:relative;z-index:11111}[data-tooltip]:after{line-height:1;font-size:12px;pointer-events:none;position:absolute;box-sizing:border-box;opacity:0;transition:all ease-in-out .2s}[data-tooltip]:after{content:attr(data-tooltip);text-align:center;min-width:100px;max-width:240px;line-height:1.5;padding:4px 8px;border-radius:8px;background:#272727;color:#fff;z-index:99;font-size:14px;font-style:normal}[data-tooltip]:hover:after{opacity:1}[data-tooltip][data-flow=top]:before{bottom:100%;border-bottom-width:0;border-top-color:#4d4d4d}[data-tooltip][data-flow=top]:after{bottom:calc(100% - 4px)}[tooltip]:not([data-flow]):after,[data-tooltip][data-flow=top]:after{left:50%;transform:translate(-50%,-4px)}[data-tooltip][data-flow=bottom]:after{top:calc(100% - 5px)}[data-tooltip][data-flow=bottom]:after{left:50%;transform:translate(-50%,8px)}[data-tooltip][data-flow=left]:after{top:50%;right:calc(100% + 5px);transform:translate(-8px,-50%)}[data-tooltip][data-flow=right]:after{top:50%;left:calc(100% + 5px);transform:translate(8px,-50%)}[data-tooltip=""]:after{display:none!important}[data-tooltip]:not([data-flow]):after,[data-tooltip][data-flow=topleft]:after{bottom:calc(100% + 5px)}[tooltip]:not([data-flow]):after,[data-tooltip][data-flow=topleft]:after{left:0}.jr-ai-assist-icon-chevron-down{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='32'%20height='32'%20viewBox='0%200%2032%2032'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M10%2013.1035L15.2929%2018.3964C15.6262%2018.7297%2015.7929%2018.8964%2016%2018.8964C16.2071%2018.8964%2016.3738%2018.7297%2016.7071%2018.3964L22%2013.1035'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-min{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='32'%20height='32'%20viewBox='0%200%2032%2032'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M23%2014L18%2014L18%209'%20stroke='%23141B34'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M9%2018L14%2018L14%2023'%20stroke='%23141B34'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M18%2014L25%207'%20stroke='%23141B34'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M7%2025L14%2018'%20stroke='%23141B34'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-max{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='32'%20height='32'%20viewBox='0%200%2032%2032'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M20%207L25%207L25%2012'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M12%2025L7%2025L7%2020'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M25%207L18%2014'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M14%2018L7%2025'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-help{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='20'%20height='20'%20viewBox='0%200%2020%2020'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M9.99643%201.0415C14.944%201.0415%2018.9548%205.05229%2018.9548%209.99984C18.9548%2014.9474%2014.944%2018.9582%209.99643%2018.9582C5.04887%2018.9582%201.03809%2014.9474%201.03809%209.99984C1.03809%205.05229%205.04887%201.0415%209.99643%201.0415ZM9.99643%202.2915C5.73923%202.2915%202.28809%205.74265%202.28809%209.99984C2.28809%2014.257%205.73923%2017.7082%209.99643%2017.7082C14.2536%2017.7082%2017.7048%2014.257%2017.7048%209.99984C17.7048%205.74265%2014.2536%202.2915%209.99643%202.2915ZM10.0038%2013.4178C10.4179%2013.4178%2010.7541%2013.7539%2010.7541%2014.1682C10.7541%2014.5823%2010.4179%2014.9184%2010.0038%2014.9184H9.99643C9.58218%2014.9184%209.24609%2014.5823%209.24609%2014.1682C9.24609%2013.7539%209.58218%2013.4178%209.99643%2013.4178H10.0038ZM9.99643%205.20817C11.4922%205.20817%2012.7048%206.42073%2012.7048%207.9165C12.7048%208.84542%2012.2368%209.66509%2011.5263%2010.152C11.2593%2010.3351%2011.0201%2010.5272%2010.8518%2010.7298C10.6858%2010.9296%2010.6214%2011.0987%2010.6214%2011.2498C10.6214%2011.595%2010.3416%2011.8748%209.99643%2011.8748C9.65126%2011.8748%209.37143%2011.595%209.37143%2011.2498C9.37143%2010.7107%209.61076%2010.2684%209.89059%209.9315C10.168%209.59759%2010.5169%209.32809%2010.8192%209.12092C11.2041%208.85709%2011.4548%208.41584%2011.4548%207.9165C11.4548%207.1111%2010.8018%206.45817%209.99643%206.45817C9.19101%206.45817%208.53809%207.1111%208.53809%207.9165C8.53809%208.26168%208.25826%208.5415%207.91309%208.5415C7.56791%208.5415%207.28809%208.26168%207.28809%207.9165C7.28809%206.42073%208.50068%205.20817%209.99643%205.20817Z'%20fill='black'%20fill-opacity='0.95'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-history{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='20'%20height='20'%20viewBox='0%200%2020%2020'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M11.9552%202.55746C8.35768%201.59746%204.67851%203.31413%203.05101%206.47579L4.24518%206.54829C4.58935%206.56913%204.85185%206.86579%204.83101%207.20996C4.81018%207.55496%204.51351%207.81663%204.16935%207.79579L2.07685%207.66913C1.87851%207.65663%201.69851%207.55079%201.59018%207.38413C1.48268%207.21746%201.46018%207.00913%201.53101%206.82329C3.14351%202.56663%207.77018%200.146625%2012.2777%201.34996C17.0785%202.63246%2019.9368%207.54329%2018.651%2012.3233C17.366%2017.1033%2012.4285%2019.9316%207.62851%2018.65C4.06268%2017.6975%201.57018%2014.745%201.04935%2011.3316C0.996847%2010.99%201.23101%2010.6716%201.57268%2010.6191C1.91351%2010.5675%202.23268%2010.8016%202.28518%2011.1425C2.73351%2014.08%204.87851%2016.6216%207.95101%2017.4425C12.091%2018.5475%2016.3393%2016.1066%2017.4435%2011.9991C18.5477%207.89246%2016.0952%203.66329%2011.9552%202.55746ZM10.6252%206.66663V9.74079L12.1093%2011.225C12.3535%2011.4691%2012.3535%2011.8641%2012.1093%2012.1083C11.8652%2012.3525%2011.4693%2012.3525%2011.2252%2012.1083L9.55851%2010.4416C9.44101%2010.325%209.37518%2010.1658%209.37518%209.99996V6.66663C9.37518%206.32163%209.65518%206.04163%2010.0002%206.04163C10.346%206.04163%2010.6252%206.32163%2010.6252%206.66663Z'%20fill='black'%20fill-opacity='0.95'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-reset{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='20'%20height='20'%20viewBox='0%200%2020%2020'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M10.4828%201.48975C10.7796%201.49054%2011.038%201.4945%2011.2604%201.51429C11.5556%201.54041%2011.8308%201.59741%2012.098%201.73437C12.2044%201.789%2012.3052%201.85154%2012.4004%201.922C12.642%202.10012%2012.8132%202.3202%2012.966%202.57195C13.11%202.80866%2013.2556%203.10712%2013.4276%203.45783L13.8212%204.26058H17.4004C17.7316%204.26058%2018.0004%204.52658%2018.0004%204.85433C18.0004%205.18208%2017.7316%205.44808%2017.4004%205.44808H16.7644L16.3012%2012.8581C16.2396%2013.8461%2016.1908%2014.6298%2016.0908%2015.256C15.9876%2015.8981%2015.8228%2016.4332%2015.4932%2016.9011C15.1916%2017.3286%2014.8036%2017.6904%2014.3532%2017.9612C13.8612%2018.258%2013.3116%2018.3879%2012.6572%2018.4504C12.0196%2018.5106%2011.226%2018.5106%2010.2252%2018.5106H10.1636C9.16199%2018.5106%208.36759%2018.5106%207.72839%2018.4504C7.07399%2018.3879%206.52359%2018.258%206.03159%2017.9604C5.58039%2017.6888%205.19239%2017.327%204.89079%2016.898C4.56119%2016.4293%204.39719%2015.8941%204.29479%2015.2505C4.19559%2014.6235%204.14759%2013.839%204.08679%2012.8494L3.63559%205.44808H3.00039C2.66919%205.44808%202.40039%205.18208%202.40039%204.85433C2.40039%204.52658%202.66919%204.26058%203.00039%204.26058H6.65719L6.99239%203.53304C7.15959%203.16887%207.30199%202.86012%207.44359%202.6147C7.59399%202.35425%207.76439%202.12466%208.00919%201.93941C8.10519%201.86658%208.20759%201.80087%208.31559%201.74466C8.58759%201.60137%208.86839%201.54279%209.17079%201.51508C9.45479%201.48975%209.79799%201.48975%2010.202%201.48975H10.4828ZM15.562%205.44808H4.83799L5.28279%2012.7472C5.34599%2013.774%205.39079%2014.5024%205.48039%2015.0668C5.56839%2015.621%205.69159%2015.9582%205.87559%2016.2203C6.08199%2016.5132%206.34759%2016.761%206.65639%2016.947C6.93079%2017.1125%207.27879%2017.2146%207.84359%2017.2677C8.41799%2017.3223%209.15479%2017.3231%2010.1948%2017.3231C11.2324%2017.3231%2011.9692%2017.3223%2012.5428%2017.2685C13.1068%2017.2146%2013.454%2017.1133%2013.7284%2016.947C14.0372%2016.7618%2014.3028%2016.5148%2014.5092%2016.2219C14.6932%2015.9606%2014.8164%2015.6242%2014.9052%2015.07C14.9956%2014.5063%2015.042%2013.7796%2015.106%2012.7544L15.562%205.44808ZM8.20039%208.21891C8.53159%208.21891%208.80039%208.48491%208.80039%208.81266V13.5627C8.80039%2013.8904%208.53159%2014.1564%208.20039%2014.1564C7.86919%2014.1564%207.60039%2013.8904%207.60039%2013.5627V8.81266C7.60039%208.48491%207.86919%208.21891%208.20039%208.21891ZM12.2004%208.21891C12.5316%208.21891%2012.8004%208.48491%2012.8004%208.81266V13.5627C12.8004%2013.8904%2012.5316%2014.1564%2012.2004%2014.1564C11.8692%2014.1564%2011.6004%2013.8904%2011.6004%2013.5627V8.81266C11.6004%208.48491%2011.8692%208.21891%2012.2004%208.21891ZM10.5596%202.67804H9.92679C9.65079%202.67883%209.44679%202.68279%209.27959%202.69783C9.06679%202.71683%208.95879%202.75087%208.87879%202.79283C8.82999%202.81895%208.78359%202.84825%208.73959%202.8815C8.66759%202.93612%208.59159%203.02004%208.48599%203.20291C8.37479%203.39608%208.25479%203.65495%208.07319%204.04841L7.97559%204.26058H12.4876L12.3588%203.99854C12.1732%203.61854%2012.05%203.36916%2011.9372%203.18312C11.83%203.00658%2011.7548%202.92662%2011.6828%202.87358C11.6396%202.84191%2011.594%202.81341%2011.546%202.78808C11.4668%202.7477%2011.3604%202.71525%2011.1532%202.69704C10.9972%202.68358%2010.81%202.67883%2010.5596%202.67804Z'%20fill='black'%20fill-opacity='0.95'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-dots{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='32'%20height='32'%20viewBox='0%200%2032%2032'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3ccircle%20cx='16'%20cy='16'%20r='1.5'%20fill='%233A3A3A'/%3e%3ccircle%20cx='9.5'%20cy='16'%20r='1.5'%20fill='%233A3A3A'/%3e%3ccircle%20cx='22.5'%20cy='16'%20r='1.5'%20fill='%233A3A3A'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-dots.active{background:#ddd url("data:image/svg+xml,%3csvg%20width='32'%20height='32'%20viewBox='0%200%2032%2032'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3ccircle%20cx='16'%20cy='16'%20r='1.5'%20fill='%233A3A3A'/%3e%3ccircle%20cx='9.5'%20cy='16'%20r='1.5'%20fill='%233A3A3A'/%3e%3ccircle%20cx='22.5'%20cy='16'%20r='1.5'%20fill='%233A3A3A'/%3e%3c/svg%3e") no-repeat center / contain;border-radius:6px}.jr-ai-assist-icon-sticky-on{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='32'%20height='32'%20viewBox='0%200%2032%2032'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M7%2025L12%2020'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M17.2585%2022.8714C13.5152%2022.0215%209.97844%2018.4848%209.12853%2014.7415C8.99399%2014.1489%208.92672%2013.8527%209.12161%2013.372C9.3165%2012.8913%209.55457%2012.7426%2010.0307%2012.4451C11.107%2011.7727%2012.2725%2011.5589%2013.4821%2011.6659C15.1793%2011.816%2016.0279%2011.891%2016.4512%2011.6705C16.8746%2011.4499%2017.1622%2010.9342%2017.7376%209.90269L18.4664%208.59604C18.9465%207.73528%2019.1866%207.3049%2019.7513%207.10202C20.316%206.89913%2020.6558%207.02199%2021.3355%207.26771C22.9249%207.84236%2024.1576%209.07505%2024.7323%2010.6645C24.978%2011.3442%2025.1009%2011.684%2024.898%2012.2487C24.6951%2012.8134%2024.2647%2013.0535%2023.4039%2013.5336L22.0672%2014.2792C21.0376%2014.8534%2020.5229%2015.1406%2020.3024%2015.568C20.0819%2015.9955%2020.162%2016.8256%2020.3221%2018.4859C20.4399%2019.7068%2020.2369%2020.88%2019.5555%2021.9697C19.2577%2022.4458%2019.1088%2022.6839%2018.6283%2022.8786C18.1477%2023.0733%2017.8513%2023.006%2017.2585%2022.8714Z'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-sticky-off{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='32'%20height='32'%20viewBox='0%200%2032%2032'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M11.5%2012C10.9586%2012.1281%2010.4993%2012.1424%209.99268%2012.4589C9.07234%2013.0339%208.85108%2013.7167%209.08821%2014.7612C9.94028%2018.5139%2013.486%2022.0596%2017.2388%2022.9117C18.2834%2023.1489%2018.9661%2022.928%2019.5416%2022.0077C19.8411%2021.5288%2019.8716%2021.0081%2020%2020.5'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M16%2011.7991C16.1776%2011.7779%2016.3182%2011.7403%2016.4295%2011.6823C17.3997%2011.1769%2017.9291%209.53361%2018.4498%208.60009C18.9311%207.73715%2019.1718%207.30567%2019.7379%207.10227C20.3041%206.89888%2020.6448%207.02205%2021.3262%207.26839C22.9197%207.8445%2024.1555%209.08032%2024.7316%2010.6738C24.9779%2011.3552%2025.1011%2011.6959%2024.8977%2012.262C24.6943%2012.8282%2024.2628%2013.0688%2023.3999%2013.5502C22.4608%2014.074%2020.7954%2014.6108%2020.2905%2015.5898C20.2345%2015.6983%2020.1978%2015.8327%2020.1769%2016'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M7%2025L12%2020'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M7%207L25%2025'%20stroke='%233A3A3A'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-refresh{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='24'%20height='24'%20viewBox='0%200%2024%2024'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M20.0092%202V5.13219C20.0092%205.42605%2019.6418%205.55908%2019.4537%205.33333C17.6226%203.2875%2014.9617%202%2012%202C6.47715%202%202%206.47715%202%2012C2%2017.5228%206.47715%2022%2012%2022C17.5228%2022%2022%2017.5228%2022%2012'%20stroke='%23141B34'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-share{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='20'%20height='20'%20viewBox='0%200%2020%2020'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20fill-rule='evenodd'%20clip-rule='evenodd'%20d='M9.40326%2012.4952C9.40326%2012.8368%209.6866%2013.1202%2010.0283%2013.1202H10.0448C10.3865%2013.1202%2010.6698%2012.8368%2010.6698%2012.4952V3.71181C11.5101%204.57397%2012.5489%205.83969%2012.8034%206.14976C12.8392%206.19335%2012.8595%206.21805%2012.8615%206.2201C13.0782%206.48677%2013.4698%206.52848%2013.7365%206.31181C14.0032%206.09515%2014.0449%205.70349%2013.8283%205.43682C13.8231%205.43068%2013.8115%205.41655%2013.794%205.39523C13.5267%205.06947%2011.8814%203.06483%2010.9116%202.22011C10.6616%202.00344%2010.3698%201.88679%2010.0615%201.87013C9.71151%201.85346%209.38651%201.97844%209.10318%202.22011C8.09731%203.0892%206.38427%205.19388%206.20026%205.41996C6.19371%205.428%206.18911%205.43367%206.18653%205.43682C5.96986%205.70349%206.01157%206.09515%206.27824%206.31181C6.54491%206.52848%206.93656%206.48677%207.15322%206.2201C7.15523%206.2181%207.17536%206.19362%207.21091%206.15039C7.47056%205.83465%208.55293%204.51841%209.40326%203.65347V12.4952ZM7.50358%2018.1201H12.5036L12.4953%2018.1284C14.5619%2018.1284%2015.7036%2018.1284%2016.4953%2017.3367C17.2869%2016.5451%2017.2869%2015.4034%2017.2869%2013.3367V12.5034C17.2869%2011.2369%2017.2869%2010.6034%2016.9953%2010.0201C16.7369%209.51175%2016.3286%209.09508%2015.8119%208.83675C15.2369%208.54508%2014.6037%208.54508%2013.3372%208.54508C12.9955%208.54508%2012.7119%208.82841%2012.7119%209.17008C12.7119%209.51175%2012.9953%209.79508%2013.3369%209.79508C14.3619%209.79508%2014.9369%209.79508%2015.2453%209.95341C15.5286%2010.0951%2015.7453%2010.3201%2015.8869%2010.5951C16.0453%2010.9034%2016.0453%2011.4701%2016.0453%2012.5034V13.3367C16.0453%2015.2534%2016.0286%2016.0451%2015.6203%2016.4534C15.2119%2016.8617%2014.4119%2016.8784%2012.5036%2016.8784H7.50358C5.58691%2016.8784%204.79526%2016.8617%204.38692%2016.4534C3.97859%2016.0451%203.96191%2015.2451%203.96191%2013.3367V12.5034C3.96191%2011.4784%203.96192%2010.9034%204.12026%2010.5951C4.26192%2010.3117%204.48693%2010.0951%204.76193%209.95341C5.07026%209.79508%205.63691%209.79508%206.67025%209.79508C7.01191%209.79508%207.29525%209.51175%207.29525%209.17008C7.29525%208.82841%207.01191%208.54508%206.67025%208.54508C5.40376%208.54508%204.77022%208.54508%204.18693%208.83675C3.6786%209.09508%203.2619%209.50341%203.00356%2010.0201C2.71191%2010.5951%202.71191%2011.2283%202.71191%2012.4948V13.3284C2.71191%2015.3951%202.71193%2016.5367%203.5036%2017.3284C4.29526%2018.1201%205.43691%2018.1201%207.50358%2018.1201Z'%20fill='black'%20fill-opacity='0.95'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-x{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='24'%20height='24'%20viewBox='0%200%2024%2024'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M19.0005%204.99988L5.00049%2018.9999M5.00049%204.99988L19.0005%2018.9999'%20stroke='%23141B34'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-arrow{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20width='25'%20height='24'%20viewBox='0%200%2025%2024'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M18.3965%209.79297L13.1036%204.50007C12.7703%204.16677%2012.6036%204.00007%2012.3965%204.00007C12.1894%204.00007%2012.0227%204.16677%2011.6894%204.50007L6.39648%209.79297'%20stroke='white'%20stroke-width='1.5'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M12.293%204L12.293%2020'%20stroke='white'%20stroke-width='1.5'%20stroke-linecap='round'/%3e%3c/svg%3e") no-repeat center / contain}.jr-ai-assist-icon-bubble-grey{display:inline-block;width:32px;height:32px;background:url("data:image/svg+xml,%3csvg%20viewBox='0%200%2030%2030'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M5.70789%2025.6344C4.952%2025.7962%204.3062%2025.0758%204.54933%2024.3421L5.21695%2022.3271C5.31422%2022.0335%205.26681%2021.7133%205.10976%2021.4469C4.12478%2019.7758%203.78892%2017.8537%204.16477%2015.9856C4.57213%2013.9609%205.78784%2012.1374%207.58585%2010.8541C9.38386%209.57082%2011.6418%208.91508%2013.9399%209.00882C16.238%209.10256%2018.4198%209.9394%2020.0797%2011.3637C21.7396%2012.7881%2022.7647%2014.703%2022.9642%2016.7525C23.1638%2018.8019%2022.5243%2020.8465%2021.1646%2022.5059C19.805%2024.1654%2017.8177%2025.3268%2015.5723%2025.7744C13.442%2026.1989%2011.2169%2025.9535%209.27022%2025.0851C9.06584%2024.9939%208.83832%2024.9644%208.61947%2025.0112L5.70789%2025.6344Z'%20fill='%23333333'/%3e%3cpath%20d='M15.5%204C15.5%204.39782%2015.658%204.77936%2015.9393%205.06066C16.2206%205.34196%2016.6022%205.5%2017%205.5C16.6022%205.5%2016.2206%205.65804%2015.9393%205.93934C15.658%206.22064%2015.5%206.60218%2015.5%207C15.5%206.60218%2015.342%206.22064%2015.0607%205.93934C14.7794%205.65804%2014.3978%205.5%2014%205.5C14.3978%205.5%2014.7794%205.34196%2015.0607%205.06066C15.342%204.77936%2015.5%204.39782%2015.5%204Z'%20stroke='%23333333'%20stroke-width='2'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M24%206C24%206.79565%2024.3161%207.55871%2024.8787%208.12132C25.4413%208.68393%2026.2044%209%2027%209C26.2044%209%2025.4413%209.31607%2024.8787%209.87868C24.3161%2010.4413%2024%2011.2044%2024%2012C24%2011.2044%2023.6839%2010.4413%2023.1213%209.87868C22.5587%209.31607%2021.7956%209%2021%209C21.7956%209%2022.5587%208.68393%2023.1213%208.12132C23.6839%207.55871%2024%206.79565%2024%206Z'%20fill='%23333333%20'%20stroke='%23333333'%20stroke-width='2'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e") no-repeat center / contain}@keyframes animation_left{0%,to{opacity:1;transform:translate3d(50%,-50%,0)}50%{opacity:1;transform:translate3d(-150%,-50%,0)}}@keyframes animation_right{0%,to{opacity:1;transform:translate3d(-50%,-50%,0)}50%{opacity:1;transform:translate3d(150%,-50%,0)}}.jr-ai-assist-loader{display:block;width:100%;min-width:30px;min-height:30px;position:relative;top:0;left:0;z-index:998}.jr-ai-assist-loader:before,.jr-ai-assist-loader:after{content:"";display:block;width:8px;height:8px;border-radius:50%;position:absolute;top:50%;opacity:0}.jr-ai-assist-loader:before{background-color:#000c;left:50%;animation:animation_left 2s infinite ease-in-out}.jr-ai-assist-loader:after{background-color:#969696cc;right:50%;animation:animation_right 2s infinite ease-in-out}.jr-ai-assist-modal{--jr-ai-assist-bg-color-bubble-me: #ffe7d9;--jr-ai-assist-text-color-bubble-me: #4a2205;--bg-color-button: #fff;--text-color-button: #141414;--bg-color-bubble-error: #d03131;--text-color-bubble-error: #fff;--focus-input-color: #888}.jr-ai-assist-modal{font-family:Inter,sans-serif;font-weight:400;font-size:16px;border:1px solid rgba(0,0,0,.2);position:fixed;bottom:0;z-index:1000;display:flex;flex-direction:column;width:500px;color:#333;visibility:visible;box-shadow:0 0 55px #00000026;background:#fff;background-clip:padding-box;outline:0;transition:all .4s ease-in-out;height:calc(100% - 30px);margin:auto 15px;border-radius:24px;position:fixed!important;z-index:11112;top:0;right:0;transform:translateY(110%);opacity:0}.jr-ai-assist-modal.show{transform:none;opacity:1}.jr-ai-assist-modal-header{color:#333!important;display:flex;align-items:center;justify-content:space-between;padding:16px 16px 10px;z-index:11111}.jr-ai-assist-modal-header button{background:transparent!important;margin:0!important;border:none!important;box-shadow:none!important}.jr-ai-assist-modal-header .jr-ai-assist-modal-title{display:flex;align-items:center;justify-content:space-between;width:100%;gap:8px;position:relative}.jr-ai-assist-modal-header .headline-5{font-size:20px;font-weight:500;flex:1}.jr-ai-assist-modal-header button{border:none;background:transparent;padding:0!important}.jr-ai-assist-modal-header button i{color:#555;margin:auto;opacity:.7;cursor:pointer;transition:all .2s ease-in-out}.jr-ai-assist-modal-header button:hover i{opacity:1;transform:scale(1.1)}.jr-ai-assist-modal-body{display:flex;flex-grow:1;padding:5px 16px;overflow-y:auto;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;overflow-scrolling:touch;background-image:linear-gradient(to top,#fff,#fff),linear-gradient(to top,#fff,#fff),linear-gradient(to top,#00000040,#74747400),linear-gradient(to bottom,#00000040,#74747400);background-position:bottom center,top center,bottom center,top center;background-color:#fff;background-repeat:no-repeat;background-size:100% 2px,100% 2px,100% 2px,100% 2px;background-attachment:local,local,scroll,scroll}.jr-ai-assist-modal-footer{border-radius:0 0 24px 24px;display:flex;align-items:center;justify-content:space-between;padding:10px 16px;flex-direction:column}.jr-ai-assist-disclaimer{font-size:12px;line-height:150%;margin:10px 0 0;color:#000000b3;text-align:center;max-width:70%}.jr-ai-assist-disclaimer a{color:#141414}.jr-ai-assist-overlay{width:min(80%,1400px);height:calc(90% - 30px);margin:auto auto 0;font-size:20px;font-weight:400;left:0;box-shadow:0 0 0 10000px #00000080;border-radius:24px 24px 0 0;background:#fff}.jr-ai-assist-overlay .btn-chat-max{display:none!important}.jr-ai-assist-overlay button{font-size:20px}.jr-ai-assist-overlay .form-group .textarea{font-size:20px!important}body{transition:all .2s ease-in-out}.website-docked{margin-right:500px}.jr-ai-assist-docked{box-shadow:none;border-radius:0;border-width:0 0 0 1px;height:100%;margin:0}.jr-ai-assist-docked .btn-chat-docked,.jr-ai-assist-floating .btn-chat-min{display:none!important}.jr-ai-assist-modal button{line-height:1.4;display:inline-flex;border-radius:8px;padding:8px 16px;background:var(--bg-color-button);border:1px solid rgba(0,0,0,.2);box-shadow:0 0 6px #0000000d;color:var(--text-color-button)!important;font-size:16px;font-weight:600;cursor:pointer;transition:all .2s ease-in-out;width:fit-content}.jr-ai-assist-modal button:hover{background:var(--bg-color-button);transform:scale(1.02)}.jr-ai-assist-overlay.jr-ai-assist-modal button{font-size:20px}.jr-ai-assist-modal .form-group{position:relative;z-index:1111;display:flex;flex-wrap:wrap;align-items:stretch;background:#fff;width:100%;border-radius:22px;padding:5px 0;box-shadow:0 4px 8px #1111110d;border:1px solid rgba(0,0,0,.2);transition:all .4s ease-in-out}.jr-ai-assist-modal .form-group:focus-within{box-shadow:0 0 0 2px var(--focus-input-color) inset}.jr-ai-assist-modal .form-group .textarea{font-family:Inter,sans-serif;font-weight:400;color:#141414;font-size:16px;line-height:1.6;position:relative;flex:1 1 auto;width:1%;min-width:0;border:none;padding:0 8px 0 14px;margin:auto 0;min-height:24px;max-height:75px;background:transparent;overflow-x:hidden;overflow-y:auto;resize:none;overflow-wrap:break-word}.jr-ai-assist-modal .form-group .textarea:focus-visible{outline:none}.jr-ai-assist-modal .form-group .textarea[contenteditable]:empty:before{content:var(--placeholder-text);color:gray}.jr-ai-assist-modal .form-group textarea:focus{box-shadow:none;outline:none}.jr-ai-assist-modal .form-group button{position:relative;z-index:2;border:none;box-shadow:none;background:transparent;display:flex;cursor:pointer;border-radius:50%;padding:4px;height:32px;width:32px}.jr-ai-assist-modal .form-group button i{color:#141414;height:24px;width:24px;margin:auto;transition:all .2s ease-in-out}.jr-ai-assist-modal .form-group button:hover i{opacity:1;transform:scale(1.1);transform-origin:center}.jr-ai-assist-modal .form-group .form-group-add{display:flex;flex-flow:column-reverse;position:relative;padding-right:6px}.jr-ai-assist-modal .form-group button:has(i.jr-ai-assist-icon-arrow){background:#000;border-radius:50%;padding:4px;height:32px;width:32px;opacity:1}.jr-ai-assist-overlay .form-group{padding:7px 0;border-radius:28px}.jr-ai-assist-overlay .form-group .form-group-add{padding-right:8px}.jr-ai-assist-overlay .form-group button{width:40px!important;height:40px!important}.jr-ai-assist-overlay .form-group .textarea{padding:0 12px 0 20px;min-height:30px}.jr-ai-assist-dropdown-menu{min-width:200px;max-width:300px;padding:3px;margin:0;font-size:14px;border-radius:10px;color:#333;background:#fffc;background-clip:border-box;backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border:1px solid rgba(0,0,0,.2);box-shadow:0 0 55px #00000026,0 8px 9px -5px #1414140f;position:absolute;right:0;overflow:hidden;transition:all .1s ease-out;height:auto;transform-origin:top;top:100%;transform:scaleY(0);opacity:0;z-index:1000}.jr-ai-assist-dropdown-menu.show{transform:scaleY(1);opacity:1}.form-group .jr-ai-assist-dropdown-menu{transform-origin:bottom;top:auto;bottom:100%}.jr-ai-assist-dropdown-item{cursor:pointer;display:flex;padding:0;font-weight:500;color:#333;border-radius:8px!important;white-space:nowrap;width:100%!important;opacity:1!important;padding:0!important;background:transparent!important;height:auto!important}.jr-ai-assist-dropdown-item:hover{color:#111;background:#ddd!important;text-shadow:0 0 1px #fff}.jr-ai-assist-dropdown-item i{display:flex;flex-flow:column;flex:0;font-size:19px;min-width:25px;padding:0 0 0 10px;margin:auto 0!important;opacity:.7!important}.jr-ai-assist-dropdown-item span{color:#555;flex:1;min-width:min-content;text-wrap:balance;padding:8px 5px 8px 2px;font-size:16px;margin:auto;line-height:1.5em;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-box-orient:vertical;line-clamp:3;-webkit-line-clamp:2;text-align:left}.jr-ai-assist-dropdown-item:hover i,.jr-ai-assist-dropdown-item:hover span{color:#111;opacity:1!important}.jr-ai-assist-list-bubble{list-style:none;padding:0;width:100%;display:flex;flex-flow:column;gap:5px;text-align:center}.jr-ai-assist-list-bubble>li{display:flex;flex-flow:row-reverse;margin:0 0 0 auto;padding:0;text-align:left;width:max-content;max-width:80%;min-width:150px}@media(max-width:600px){.jr-ai-assist-list-bubble>li{max-width:95%}}.jr-ai-assist-list-bubble .arrow-box{color:var(--jr-ai-assist-text-color-bubble-me, #222);gap:10px;position:relative;display:flex;flex-direction:column;flex:max-content;background:var(--jr-ai-assist-bg-color-bubble-me, #eee);border-radius:10px;padding:12px 20px;margin:0 0 10px;line-height:1.6;word-break:break-word}.jr-ai-assist-list-bubble .arrow-box pre,.jr-ai-assist-list-bubble .arrow-box code{text-wrap:auto;font-size:15px}.jr-ai-assist-list-bubble li .arrow-box-header{color:var(--jr-ai-assist-text-color-bubble-me, #222);opacity:.8;display:flex;margin:-6px 0}.jr-ai-assist-list-bubble li.ai .arrow-box-header{color:var(--text-color-bubble-ai)}.jr-ai-assist-list-bubble .arrow-box-header .user{flex-grow:1;opacity:.7;font-size:12px;font-weight:700;display:flex;margin:0 auto}.jr-ai-assist-list-bubble .arrow-box-header .action i{flex-grow:0;display:flex;margin:0 auto;opacity:.7;cursor:pointer;width:20px;height:20px;transition:all .2s ease-in-out}.jr-ai-assist-list-bubble .arrow-box-header .action:hover i{opacity:1;transform:scale(1.1)}.jr-ai-assist-list-bubble .arrow-box strong{font-weight:600}.jr-ai-assist-list-bubble .arrow-box p{line-height:1.6;margin:0;gap:15px}.jr-ai-assist-list-bubble .arrow-box ul{padding-left:25px}.jr-ai-assist-list-bubble .arrow-box ul:has(button){list-style-type:none;gap:5px;display:flex;flex-direction:column}.jr-ai-assist-list-bubble .arrow-box .btn{margin-bottom:10px}.jr-ai-assist-list-bubble .arrow-box .btn:last-child{margin-bottom:5px}.jr-ai-assist-list-bubble li.ai{flex-flow:row;margin:0 auto 0 0;max-width:100%}.jr-ai-assist-list-bubble li.ai .arrow-box{margin:0 0 10px;padding:0 4px;background:var(--bg-color-bubble-ai);border:none;box-shadow:none}.jr-ai-assist-list-bubble li.ai .arrow-box,.jr-ai-assist-list-bubble li.ai .arrow-box p,.jr-ai-assist-list-bubble li.ai .arrow-box *{color:var(--text-color-bubble-ai)}.jr-ai-assist-list-bubble li.error .arrow-box{background:var(--bg-color-bubble-error);color:#fff}.jr-ai-assist-list-bubble li.error .arrow-box,.jr-ai-assist-list-bubble li.error .arrow-box p,.jr-ai-assist-list-bubble li.error .arrow-box *{color:var(--text-color-bubble-error)}@media(min-width:1000px){.jr-ai-assist-overlay .jr-ai-assist-modal-body .jr-ai-assist-list-bubble,.jr-ai-assist-overlay .jr-ai-assist-modal-footer .form-group{max-width:700px;margin:0 auto}}@media(max-width:1100px){.jr-ai-assist-modal{width:400px}.jr-ai-assist-overlay{width:90%;height:90%}}@media(max-width:576px){.jr-ai-assist-modal{width:calc(100% - 30px)}.jr-ai-assist-docked{width:100%}.jr-ai-assist-overlay{width:95%;height:95%;margin:auto;border-radius:20px;font-size:16px}.jr-ai-assist-overlay button,.jr-ai-assist-overlay .form-group .textarea{font-size:16px!important}}.jr-ai-assist-modal button:disabled,.jr-ai-assist-overlay button:disabled,.jr-ai-assist-chat-form .form-group button:disabled{cursor:not-allowed;opacity:.4!important;transition:all ease-in-out .2s}.jr-ai-assist-modal .form-group:has(.textarea:not([contenteditable])){background:#eee;opacity:.8}`)),document.head.appendChild(t)}}catch(i){console.error("vite-plugin-css-injected-by-js",i)}})();
import { getInstanceId as Y, isUserLoggedIn as pt, performWithIamToken as gt, load as N, Binary as V, provideDataClass as bt, ClientError as yt, currentLanguage as Q, connect as E, LinkTag as wt } from "scrivito";
import vt from "openai";
import { jsx as i, Fragment as U, jsxs as m } from "react/jsx-runtime";
import { useState as P, useRef as O, useEffect as C, createContext as Ct, useContext as X, useCallback as k } from "react";
import { z as l } from "zod";
import Z from "react-markdown";
const tt = "aws/eu.anthropic.claude-sonnet-4-20250514-v1:0", et = "https://6dyoi7w4yzq2bta2fh5hubtd4a0lnozo.lambda-url.eu-central-1.on.aws";
function nt() {
  return new vt({
    // note: this is a fake key, which is not used
    // we overwrite the authorization header in our fetch implementation
    apiKey: "dont-use-this-key",
    baseURL: `${et}/v1`,
    defaultQuery: { instance_id: Y() },
    defaultHeaders: { Accept: "*/*" },
    dangerouslyAllowBrowser: !0,
    fetch: async (n, t) => {
      const e = jt(t);
      return pt() ? gt(
        "https://api.justrelate.com/ai",
        async (r) => {
          e.set("authorization", `Bearer ${r}`);
          const o = await fetch(n, { ...t, headers: e });
          return o.status === 401 ? { authenticationFailed: await o.json() } : { result: o };
        }
      ) : fetch(n, { ...t, headers: e });
    }
  });
}
function jt(n) {
  const t = new Headers(n?.headers);
  for (const e of t.keys())
    e.toLowerCase().startsWith("x-") && t.delete(e);
  return t.delete("authorization"), t.set("content-type", "application/json"), t;
}
async function kt() {
  const t = await nt().chat.completions.create({
    model: tt,
    messages: [
      {
        role: "user",
        content: "Please tell me who you are."
      }
    ],
    stream: !0
  });
  for await (const e of t)
    console.log(e.choices[0]?.delta?.content || "");
}
typeof window < "u" && (window.runTest = kt);
async function rt(n) {
  const t = n._widget_pool ?? {};
  return await ot(t, n);
}
async function ot(n, t) {
  const e = (await Promise.all(
    Object.entries(t).map(async ([r, o]) => {
      if (r.startsWith("_") || !Array.isArray(o)) return;
      const [s, a] = o;
      switch (s) {
        case "date":
        case "datetime":
        case "datalocator":
        case "link":
        case "linklist":
        case "reference":
        case "referencelist":
        case "boolean":
        case "enum":
        case "multienum":
        case "float":
        case "integer":
        case "stringlist":
        case "widget":
          return;
        case "binary":
          return N(
            () => (
              // @ts-expect-error private API
              new V(a.id).raw().metadata().get("text")
            )
          );
        case "html":
        case "string": {
          const c = String(a);
          return c.length < 4 ? void 0 : c;
        }
        case "widgetlist":
          return Array.isArray(a) ? (await Promise.all(a.map((c) => Pt(n, c)))).join(`
`) : void 0;
      }
    })
  )).filter(Boolean);
  return e.length === 0 ? "" : e.length === 1 ? e[0] : e.join(`
`);
}
async function Pt(n, t) {
  const e = n[t];
  return e === null || typeof e != "object" ? "" : ot(n, e);
}
async function St(n) {
  return await (typeof n == "function" ? (
    // assumption: T is not a function
    n()
  ) : n);
}
class Nt {
  state;
  listener;
  client = nt();
  constructor(t, e = []) {
    this.listener = t, this.state = { messages: e, isProcessing: !1 }, this.listener(this.state);
  }
  async processUserMessage(t, e) {
    console.log("USER PROMPT:"), console.log(e), console.log(""), console.log("PROCESSING...");
    const r = {
      role: "user",
      content: e
    }, o = this.state.messages;
    this.setState({
      messages: [...o, r],
      isProcessing: !0
    });
    const {
      systemPrompt: s,
      tools: a,
      temperature: c,
      model: u = tt
    } = await St(t), h = [
      ...xt(o, s),
      r
    ];
    console.log("messages", h);
    const p = this.createCompletionStream(
      h,
      a,
      u,
      c
    );
    try {
      await this.processStreamChunks(p);
    } catch (T) {
      this.handleStreamingError(T, h);
    }
  }
  setState(t) {
    this.state = t, this.listener(t);
  }
  createCompletionStream(t, e, r, o) {
    const s = { model: r, messages: t, temperature: o, stream: !0 };
    return e.length ? this.client.chat.completions.runTools({
      ...s,
      tools: e.map((a) => ({
        type: "function",
        function: a
      }))
    }) : this.client.chat.completions.stream(s);
  }
  async processStreamChunks(t) {
    for await (const e of t) {
      const r = t.currentChatCompletionSnapshot?.choices[0], o = r && Ot(r), s = o?.content, a = o && s && s.length < 250 ? [...t.messages] : [...t.messages, ...o ? [o] : []];
      this.setState({ messages: a, isProcessing: !0 });
    }
    console.log("Messages", t.messages), this.setState({ messages: [...t.messages], isProcessing: !1 });
  }
  handleStreamingError(t, e) {
    console.error(t);
    const r = t instanceof Error ? t.toString() : JSON.stringify(t);
    this.setState({
      messages: [...e, { content: r, role: "assistant" }],
      isProcessing: !1
    });
  }
}
function Ot(n) {
  const t = n.message;
  if (t.role === "assistant")
    return {
      role: "assistant",
      content: t.content,
      tool_calls: t.tool_calls
    };
}
function xt(n, t) {
  return n.some((e) => e.role === "user") ? Tt(n) : [
    {
      role: "system",
      // TODO move computeSystemMessage up
      content: t
    },
    ...n
  ];
}
function Tt(n) {
  return n.map((t) => t.role !== "assistant" ? t : t.tool_calls && t.tool_calls.length > 0 ? {
    role: t.role,
    content: t.content,
    tool_calls: t.tool_calls
  } : { role: t.role, content: t.content });
}
let W;
function st() {
  return W ||= $t(), W;
}
function $t() {
  return bt("SharedConversation", {
    restApi: {
      url: `${et}/${Y()}/conversations`,
      audience: "https://api.justrelate.com/ai"
    },
    attributes: {}
  });
}
async function _t(n) {
  const { systemData: t, customData: e } = n.getExternalData();
  return {
    _id: t._id,
    // TODO abstract, don't hardcode for activity
    _summary: `${e.activityType}: ${e.subject}`
  };
}
async function L(n) {
  const t = n.getExternalData();
  return {
    _id: t.systemData._id,
    // _url: await load(() => urlForDataItem(item)),
    ...t.customData
  };
}
function Dt(n) {
  return [
    S({
      name: "list",
      description: "Get a list of data for the given data type.",
      parameters: l.object({
        dataType: l.enum(Object.keys(n)).describe("The kind of data to fetch."),
        limit: l.number().describe("how many items to fetch").optional(),
        filter: l.object({
          attribute: l.string().describe("the attribute which must have the given value"),
          value: l.union([l.string(), l.boolean()]).describe("the value that the attribute must have")
        }).optional(),
        order: l.object({
          attribute: l.string().describe("the attribute to sort on"),
          direction: l.enum(["asc", "desc"])
        }).optional(),
        search: l.string().describe("search for keywords in the full text.").optional()
      }),
      run: async (e) => {
        const r = t(e.dataType), o = e.order, s = e.filter, a = r.all().transform({
          filters: s && { [s.attribute]: s.value },
          order: o && [[o.attribute, o.direction]],
          limit: e.limit,
          search: e.search
        }), c = await N(() => a.take()), u = await Promise.all(c.map(L));
        return console.log(u), u;
      }
    }),
    S({
      name: "create",
      description: "Create a new item of the given data type.",
      parameters: l.object({
        dataType: l.enum(Object.keys(n)).describe("The kind of data to fetch."),
        data: l.array(
          l.object({
            attribute: l.string().describe("the name of the attribute"),
            value: l.string().describe("the value to set for the attribute")
          })
        ).describe(
          "an list of attribute values that should be set for the new item."
        )
      }),
      run: async (e) => {
        const r = t(e.dataType), o = Object.fromEntries(
          e.data.map(({ attribute: a, value: c }) => [a, c])
        ), s = await r.create(o);
        return L(s);
      }
    })
  ];
  function t(e) {
    const r = n[e];
    if (!r)
      throw new Error(`unknown data type ${e}`);
    return r;
  }
}
function Et(n) {
  return [
    S({
      name: "get",
      description: "Get the details of a specific data item",
      parameters: l.object({
        dataType: l.enum(Object.keys(n)).describe("The kind of data to fetch."),
        ids: l.array(l.string()).describe("a list of ids for the items to get.")
      }),
      run: async (e) => {
        const r = t(e.dataType), { ids: o } = e, s = await Promise.all(
          o.map((c) => N(() => r.get(c)))
        ), a = await Promise.all(
          s.filter((c) => !!c).map(L)
        );
        return console.log(a), a;
      }
    }),
    S({
      name: "find",
      description: `
        Find data for the given data type.
        The results contain a summary for each item.
        In order to get the details of a specific item, use the 'get' tool.
      `,
      parameters: l.object({
        dataType: l.enum(Object.keys(n)).describe("The kind of data to fetch."),
        filter: l.object({
          attribute: l.string().describe("the attribute which must have the given value"),
          value: l.union([l.string(), l.boolean()]).describe("the value that the attribute must have")
        }).optional(),
        order: l.object({
          attribute: l.string().describe("the attribute to sort on"),
          direction: l.enum(["asc", "desc"])
        }).optional(),
        search: l.string().describe("search for keywords in the full text.").optional()
      }),
      run: async (e) => {
        const r = t(e.dataType), o = e.order, s = e.filter, a = r.all().transform({
          filters: s && { [s.attribute]: s.value },
          order: o && [[o.attribute, o.direction]],
          limit: 200,
          search: e.search
        }), c = await N(() => a.take()), u = await Promise.all(c.map(_t));
        return console.log(u), u;
      }
    }),
    S({
      name: "create",
      description: "Create a new item of the given data type.",
      parameters: l.object({
        dataType: l.enum(Object.keys(n)).describe("The kind of data to fetch."),
        data: l.array(
          l.object({
            attribute: l.string().describe("the name of the attribute"),
            value: l.string().describe("the value to set for the attribute")
          })
        ).describe(
          "an list of attribute values that should be set for the new item."
        )
      }),
      run: async (e) => {
        const r = t(e.dataType), o = Object.fromEntries(
          e.data.map(({ attribute: a, value: c }) => [a, c])
        ), s = await r.create(o);
        return L(s);
      }
    })
  ];
  function t(e) {
    const r = n[e];
    if (!r)
      throw new Error(`unknown data type ${e}`);
    return r;
  }
}
async function It(n) {
  return (await Promise.all(
    Object.entries(n).map(async ([e, r]) => {
      const o = Mt(
        await N(() => r.attributeDefinitions())
      );
      return `Data type ${e} with the attributes:
      ${JSON.stringify(o)}

      `;
    })
  )).join(`
`);
}
function Mt(n) {
  const t = {};
  for (const [e, [r, o]] of Object.entries(n))
    if (o?.values) {
      const { _values: s, ...a } = o;
      t[e] = [r, a];
    } else
      t[e] = [r, o];
  return t;
}
function Rt(n) {
  return S({
    name: "site-search",
    description: "Search various corporate websites for information. ",
    parameters: l.object({
      site: l.enum(Object.keys(n)),
      searchTerm: l.string().describe("The search term should be in english."),
      alternativeSearchTerms: l.array(l.string())
    }),
    run: async ({ searchTerm: t, site: e }) => {
      const r = n[e];
      if (!r)
        throw new Error("Invalid website ${site}");
      const o = r.instanceId, s = await fetch(
        `https://beta-api.scrivito.com/tenants/${o}/perform`,
        {
          method: "PUT",
          headers: { "content-type": "application/json; charset=utf-8" },
          body: JSON.stringify({
            path: "workspaces/published/objs/search",
            verb: "GET",
            params: {
              query: [
                {
                  field: "_site_id",
                  operator: "equals",
                  value: [r.siteId]
                },
                { field: "*", operator: "matches", value: [t] }
              ],
              options: { site_aware: !0 },
              size: 10,
              include_objs: !0
            }
          }),
          mode: "cors",
          credentials: "omit"
        }
      ), { objs: a } = await s.json(), c = await Promise.all(
        a.map(async (u) => {
          const { _id: h, ...p } = u;
          return {
            _url: `${r.baseUrl}/${h}`,
            text: await rt({ ...p })
          };
        })
      );
      return console.log("pages", c), c;
    }
  });
}
function S({
  name: n,
  run: t,
  parameters: e,
  description: r,
  explanation: o
}) {
  return {
    name: n,
    description: r,
    explanation: (s) => {
      try {
        const a = e.parse(JSON.parse(s));
        return o?.(a) ?? `bot calls ${n}`;
      } catch {
        return "";
      }
    },
    parameters: At(e),
    function: async (s) => {
      console.log(`[model performs '${n}' with ${s}]`);
      try {
        const a = e.parse(JSON.parse(s)), c = await t(a);
        return typeof c == "string" ? c : JSON.stringify(c);
      } catch (a) {
        if (!(a instanceof yt)) {
          const u = `Error: ${a}`;
          return console.log("some error", a), u;
        }
        const c = `Error: ${a.message}, ${a.code}, ${JSON.stringify(a.details)}`;
        return console.log("client error", c), c;
      }
    }
  };
}
function At(n) {
  return l.toJSONSchema(n);
}
function Lt(n, t) {
  return n === "v1" ? Dt(t) : Et(t);
}
const Ut = `
    You can use Markdown to format your messages.
    When you suggest a prompt, wrap it in a link using the anchor "run-prompt" like this: [the text of the prompt](#run-prompt).
    When referring to content with a _url attribute, always link using this URL: So if a content item has the title 'My Page' and the _url is 'https://example.com/my_page', you can link to it like this: [My Page](https://example.com/my_page).
  When showing or listing a data item of a certain data type (e.g. an order) and there is an _id attribute, always link to each item like this: [text](/_data-item/<the data type>/<the _id>), for example [this order](/_data-item/Order/1234).
  `;
async function Ht(n) {
  return {
    model: n.model,
    temperature: n.temperature,
    systemPrompt: await zt(n),
    tools: at(n)
  };
}
async function zt(n) {
  const t = n.dataTypes && `This is the data model:
      ${await It(n.dataTypes)}`, e = `You respond in ${Bt()} unless instructed otherwise.`;
  return `${n.systemPrompt}

      ${e}

      ${t}

      ${Ut}`;
}
function Bt() {
  return new Intl.DisplayNames(["en"], { type: "language" }).of(
    Q() || "en"
  ) || "English";
}
function at({
  sites: n,
  dataTypes: t,
  dataTypeToolVersion: e,
  functions: r = []
}) {
  return [
    ...r.map(S),
    ...(t && Lt(e ?? "v1", t)) ?? [],
    ...(n && [Rt(n)]) ?? []
  ];
}
const it = {
  de: {
    placeholder: "Stelle eine Frage",
    helpPrompt: "Sag mir was du tun kannst, und mache Vorschläge für Fragen.",
    moreOptions: "Weitere Optionen",
    sendNow: "Absenden",
    disclaimer: "KI-generierte Antworten können ungenau sein. Überprüfen Sie wichtige Informationen.",
    help: "Hilfe",
    resetConversation: "Chat zurücksetzen",
    shareConversation: "Chat teilen"
  },
  en: {
    placeholder: "Ask anything",
    helpPrompt: "Please tell me what you can do, and suggest prompts to use.",
    moreOptions: "More options",
    sendNow: "Send now",
    disclaimer: "AI generated responses can be inaccurate. Check important information.",
    help: "Help",
    resetConversation: "Reset conversation",
    shareConversation: "Share conversation"
  },
  fr: {
    placeholder: "Posez une question",
    helpPrompt: "Dis-moi ce que tu peux faire et suggère des questions.",
    moreOptions: "Plus d'options",
    sendNow: "Envoyer",
    disclaimer: "Les réponses générées par l'IA peuvent être inexactes. Vérifiez les informations importantes.",
    help: "Aide",
    resetConversation: "Réinitialiser le chat",
    shareConversation: "Partager le chat"
  }
};
function v(n) {
  const t = Q(), e = Jt(t) ? t : "en";
  return it[e][n];
}
function Jt(n) {
  return !!n && n in it;
}
const Vt = (n) => {
  const t = P(), [e, r] = t, o = O(!1);
  return C(() => {
    const s = localStorage.getItem(n);
    if (s) {
      const a = JSON.parse(s);
      r({ value: a });
    }
    o.current = !0;
  }, [n, r]), C(() => {
    if (e === void 0) return;
    const s = e.value;
    localStorage.setItem(n, JSON.stringify(s));
  }, [n, e]), [e?.value, (s) => r({ value: s })];
};
function qt({
  promptHistory: n,
  runPrompt: t
}) {
  return !n || !n.length ? null : /* @__PURE__ */ i(U, { children: /* @__PURE__ */ i("li", { className: "ai", children: /* @__PURE__ */ m("div", { className: "arrow-box", children: [
    /* @__PURE__ */ i("div", { className: "arrow-box-header", children: /* @__PURE__ */ i("span", { className: "user", children: "History" }) }),
    [...n].reverse().map((e, r) => /* @__PURE__ */ i("button", { type: "button", onClick: () => t(e), children: e }, r))
  ] }) }) });
}
const q = Ct(null);
function Ft({
  chatLogRef: n,
  isLoading: t,
  showHistory: e,
  messages: r,
  promptHistory: o,
  runPrompt: s,
  config: a,
  debugTools: c,
  systemMessage: u
}) {
  return /* @__PURE__ */ i("div", { ref: n, className: "jr-ai-assist-modal-body", children: /* @__PURE__ */ m("ul", { className: "jr-ai-assist-list-bubble", children: [
    !t && e && !r.length && /* @__PURE__ */ i(qt, { promptHistory: o, runPrompt: s }),
    /* @__PURE__ */ i(
      q.Provider,
      {
        value: {
          onPromptClicked: s,
          dataTypes: a.dataTypes
        },
        children: r.map((h, p) => /* @__PURE__ */ i(
          Wt,
          {
            debugTools: !!c,
            config: a,
            message: h
          },
          p
        ))
      }
    ),
    u && /* @__PURE__ */ i(Zt, { message: u }),
    t && /* @__PURE__ */ i(Xt, {})
  ] }) });
}
function Wt({ config: n, message: t, debugTools: e }) {
  if (t.role === "user")
    return /* @__PURE__ */ i("li", { children: /* @__PURE__ */ i("div", { className: "arrow-box", children: typeof t.content == "string" && t.content }) });
  if (t.role === "assistant")
    return /* @__PURE__ */ m(U, { children: [
      typeof t.content == "string" && (t.content.length >= 250 || !t.tool_calls || t.tool_calls.length === 0) ? /* @__PURE__ */ i("li", { className: "ai", children: /* @__PURE__ */ i("div", { className: "arrow-box", children: /* @__PURE__ */ i(Z, { components: { a: ct }, children: t.content }) }) }, "message") : null,
      t.tool_calls && e ? t.tool_calls.map((o, s) => /* @__PURE__ */ i("li", { className: "ai", children: /* @__PURE__ */ i("div", { className: "arrow-box", children: r(n, o) }, s) }, s)) : null
    ] });
  return null;
  function r(o, s) {
    if (!("function" in s))
      throw new Error("custom tools are not supported");
    const a = at(o).find(
      (c) => c.name === s.function.name
    );
    return a ? a.explanation(s.function.arguments) : `bot calls ${s.function.name}`;
  }
}
function ct({ href: n, title: t, children: e }) {
  if (n === "#run-prompt")
    return /* @__PURE__ */ m(Qt, { children: [
      e,
      " "
    ] });
  if (n) {
    const r = Yt(n);
    if (r)
      return /* @__PURE__ */ i(Gt, { ...r, children: e });
  }
  return /* @__PURE__ */ i("a", { href: n, target: "_blank", rel: "noreferrer", title: t, children: e });
}
const Gt = E(
  ({
    className: n,
    id: t,
    children: e
  }) => {
    const o = X(q)?.dataTypes?.[n];
    if (o)
      try {
        const a = o.get(t);
        if (a)
          return /* @__PURE__ */ i(wt, { to: a, children: e });
      } catch (a) {
        console.error(a);
      }
    return /* @__PURE__ */ i("a", { href: s(), children: e });
    function s() {
      return `#_not_routable/${n}/${t}`;
    }
  }
), Kt = /^\/_data-item\/([^/]+)\/([^/]+)$/;
function Yt(n) {
  const t = n.match(Kt);
  return t && t[1] && t[2] ? { className: t[1], id: t[2] } : null;
}
function Qt({ children: n }) {
  const t = O(null), e = X(q);
  return /* @__PURE__ */ i("button", { type: "button", ref: t, onClick: r, children: n });
  function r() {
    const o = t.current?.textContent;
    o && (console.log("clicked", o), e?.onPromptClicked(o));
  }
}
function Xt() {
  const [n, t] = P(0);
  return C(() => {
    const r = setInterval(() => t(n === 2 ? 0 : n + 1), 500);
    return () => clearInterval(r);
  }, [n]), /* @__PURE__ */ i(U, { children: "•".repeat(n + 1) });
}
function Zt({ message: n }) {
  const { content: t, onConfirm: e, onCancel: r } = n, o = O(null);
  return C(() => {
    o.current && o.current.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [t]), /* @__PURE__ */ i("li", { ref: o, className: "ai", children: /* @__PURE__ */ m("div", { className: "arrow-box", children: [
    /* @__PURE__ */ i(Z, { components: { a: ct }, children: t }),
    e && /* @__PURE__ */ i("button", { type: "button", onClick: e, children: "Confirm" }),
    r && /* @__PURE__ */ i("button", { type: "button", onClick: r, children: "Cancel" })
  ] }) });
}
const te = E(function({
  inputRef: t,
  placeholder: e,
  runPromptFromInput: r,
  isLoading: o
}) {
  return /* @__PURE__ */ m("div", { className: "jr-ai-assist-modal-footer", children: [
    /* @__PURE__ */ m("div", { className: "form-group", children: [
      /* @__PURE__ */ i(
        "span",
        {
          contentEditable: !o,
          role: "textbox",
          ref: t,
          className: "textarea",
          style: {
            "--placeholder-text": `"${e}"`
          },
          onKeyDown: s
        }
      ),
      /* @__PURE__ */ i("div", { className: "form-group-add", children: /* @__PURE__ */ i(
        "button",
        {
          type: "button",
          onClick: r,
          disabled: o,
          children: /* @__PURE__ */ i(
            "i",
            {
              className: "jr-ai-assist-icon-arrow",
              title: v("sendNow")
            }
          )
        }
      ) })
    ] }),
    /* @__PURE__ */ i("p", { className: "jr-ai-assist-disclaimer", children: v("disclaimer") })
  ] });
  function s(a) {
    !o && a.key === "Enter" && !a.shiftKey && (a.preventDefault(), r());
  }
});
function G({
  isVisible: n,
  hide: t,
  displayMode: e,
  headerActions: r,
  children: o
}) {
  let s = `jr-ai-assist-modal jr-ai-assist-${e}`;
  return n && (s += " show"), /* @__PURE__ */ m("div", { className: s, children: [
    /* @__PURE__ */ i("div", { className: "jr-ai-assist-modal-header", children: /* @__PURE__ */ m("div", { className: "jr-ai-assist-modal-title", children: [
      /* @__PURE__ */ i("span", { className: "headline-5" }),
      r,
      /* @__PURE__ */ i("button", { type: "button", onClick: a, children: /* @__PURE__ */ i("i", { className: "jr-ai-assist-icon-chevron-down" }) })
    ] }) }),
    o
  ] });
  function a(c) {
    c.stopPropagation(), t?.();
  }
}
const ee = E(function({
  isOpen: t,
  helpMeGetStarted: e,
  toggleOptions: r,
  resetConversation: o,
  conversationSharing: s,
  shareConversation: a
}) {
  return /* @__PURE__ */ m("ul", { className: `jr-ai-assist-dropdown-menu ${t ? "show" : ""}`, children: [
    /* @__PURE__ */ i("li", { children: /* @__PURE__ */ i(
      B,
      {
        onClick: e,
        iconClassName: "jr-ai-assist-icon-help",
        title: v("help")
      }
    ) }),
    /* @__PURE__ */ i("li", { children: /* @__PURE__ */ i(
      B,
      {
        onClick: c,
        iconClassName: "jr-ai-assist-icon-reset",
        title: v("resetConversation")
      }
    ) }),
    s && /* @__PURE__ */ i("li", { children: /* @__PURE__ */ i(
      B,
      {
        onClick: a,
        iconClassName: "jr-ai-assist-icon-share",
        title: v("shareConversation")
      }
    ) })
  ] });
  function c() {
    r(), o();
  }
});
function B({
  onClick: n,
  iconClassName: t,
  title: e
}) {
  return /* @__PURE__ */ m(
    "button",
    {
      type: "button",
      className: "jr-ai-assist-dropdown-item",
      onClick: n,
      children: [
        /* @__PURE__ */ i("i", { className: t, title: e }),
        /* @__PURE__ */ i("span", { children: e })
      ]
    }
  );
}
const ne = E(function({
  config: t,
  messages: e,
  processUserMessage: r,
  startNewConversation: o,
  isLoading: s,
  systemMessage: a,
  setSystemMessage: c,
  isVisible: u,
  hide: h,
  debugTools: p,
  conversationSharing: T,
  showHistory: $
}) {
  const [H, I] = P(!1), [g, M] = P(
    "overlay"
  ), _ = O(null), w = O(null), b = k(() => {
    c(null), o(), _.current?.focus();
  }, [c, o]), x = k(
    (d) => {
      d.metaKey && d.key === "k" && b();
    },
    [b]
  );
  C(() => (document.addEventListener("keydown", x), () => {
    document.removeEventListener("keydown", x);
  }), [x]), C(() => {
    w.current && (w.current.scrollTop = w.current.scrollHeight);
  }, [e]);
  const [D, f] = Vt("promptHistory"), j = v("placeholder"), R = k(
    (d, y) => {
      c({
        content: d,
        onConfirm: y,
        onCancel: () => c(null)
      });
    },
    [c]
  );
  if (!t)
    return /* @__PURE__ */ m(G, { isVisible: u, hide: h, displayMode: g, children: [
      /* @__PURE__ */ i("div", { className: "jr-ai-assist-modal-body", children: /* @__PURE__ */ i("div", { className: "jr-ai-assist-loader" }) }),
      /* @__PURE__ */ i("div", { className: "jr-ai-assist-modal-footer" })
    ] });
  return /* @__PURE__ */ m(
    G,
    {
      isVisible: u,
      hide: h,
      displayMode: g,
      headerActions: /* @__PURE__ */ m(U, { children: [
        /* @__PURE__ */ i("button", { onClick: A, children: /* @__PURE__ */ i(
          "i",
          {
            className: "jr-ai-assist-icon-dots",
            title: v("moreOptions")
          }
        ) }),
        /* @__PURE__ */ i(
          ee,
          {
            isOpen: H,
            helpMeGetStarted: ut,
            toggleOptions: A,
            resetConversation: b,
            conversationSharing: T,
            shareConversation: mt
          }
        ),
        /* @__PURE__ */ i("button", { type: "button", onClick: dt, children: /* @__PURE__ */ i(
          "i",
          {
            className: `jr-ai-assist-icon-${g === "floating" ? "max" : "min"}`
          }
        ) })
      ] }),
      children: [
        /* @__PURE__ */ i(
          Ft,
          {
            chatLogRef: w,
            isLoading: s,
            showHistory: $,
            messages: e,
            promptHistory: D,
            runPrompt: z,
            config: t,
            debugTools: p,
            systemMessage: a
          }
        ),
        /* @__PURE__ */ i(
          te,
          {
            inputRef: _,
            placeholder: j,
            runPromptFromInput: lt,
            isLoading: s
          }
        )
      ]
    }
  );
  function lt() {
    const d = _.current;
    if (!d) return;
    const y = d.innerText;
    if (!y) return;
    d.innerText = "";
    const F = D ? D.slice(0, 50) : [], ht = F.some(
      (ft) => ft.toLowerCase() === y.toLowerCase()
    );
    e.length === 0 && !ht && f([...F, y]), z(y);
  }
  function z(d) {
    c(null), r(d);
  }
  function ut() {
    A(), z(v("helpPrompt"));
  }
  function dt() {
    M((d) => d === "overlay" ? "floating" : "overlay");
  }
  function A() {
    I((d) => !d);
  }
  async function mt() {
    A(), !(!t || e.length === 0) && R(
      "Share this conversation? This will create a permanent link which can be accessed by every registered user of your instance who obtains it.",
      async () => {
        const d = await st().create({
          model: t.model,
          messages: e
        }), y = `${window.location.origin}${window.location.pathname}?sharedConversationId=${d.id()}`;
        navigator.clipboard.writeText(y), c({
          content: `Conversation shared! [URL](${y}) copied to clipboard`
        });
      }
    );
  }
}), me = E(function({
  config: t,
  isVisible: e = !0,
  hide: r,
  debugTools: o,
  conversationSharing: s,
  showHistory: a
}) {
  const { initialMessages: c, initialUserPrompt: u } = D(), [h, p] = P(
    { messages: c, isProcessing: !1 }
  ), [T, $] = P(
    null
  ), [H, I] = P(!1), g = k(
    (f = c) => new Nt(p, f),
    [p, c]
  ), M = k(async () => {
    if (!s) return;
    const f = new URLSearchParams(
      window.location.search
    ).get("sharedConversationId");
    if (!f) return;
    I(!0);
    const j = st(), R = await N(
      () => j.get(f)
    );
    R ? (b.current = g(
      R.get(
        "messages"
      )
    ), $(null)) : $({
      content: `Shared conversation ${f} not found.`
    }), I(!1);
  }, [s, g]), _ = k(() => {
    b.current = g();
  }, [g]), w = k(
    (f) => {
      if (t)
        return b.current?.processUserMessage(
          Ht(t),
          f
        );
    },
    [t]
  ), b = O(null);
  t && !b.current && (b.current = g());
  const x = O(!1);
  return C(() => {
    M();
  }, [M]), C(() => {
    u && !x.current && (w(u), x.current = !0);
  }, [u, w]), /* @__PURE__ */ i(
    ne,
    {
      debugTools: o,
      processUserMessage: w,
      messages: h.messages,
      config: t,
      startNewConversation: _,
      isLoading: h.isProcessing || H,
      systemMessage: T,
      setSystemMessage: $,
      conversationSharing: s,
      showHistory: a,
      isVisible: e,
      hide: r
    }
  );
  function D() {
    const f = t?.initialMessages || [], j = f.at(-1);
    return j?.role === "user" && typeof j.content == "string" ? {
      initialMessages: f.slice(0, -1),
      initialUserPrompt: j.content
    } : { initialMessages: f, initialUserPrompt: void 0 };
  }
}), re = /<[a-z/]+>|&[a-z]+;/g;
class he {
  botObj;
  constructor(t) {
    this.botObj = t._scrivitoPrivateContent;
  }
  name() {
    return this.botObj.get("botName", "string") || `Untitled Bot ${this.botObj.id()}`;
  }
  systemPrompt() {
    const t = this.botObj.get("prompt", "widgetlist").map(
      (r) => r.get("text", "string").replace(re, "")
    ).filter(Boolean).join(`
`), e = this.resourcesMetadata().map(
      (r, o) => `[${o + 1}] ${r.title}
${r.context}
`
    ).join(`
`);
    return `${t}

Document List:

${e}`;
  }
  greeting() {
    return this.botObj.get("greeting", "string");
  }
  temperature() {
    return this.botObj.get("temperature", "float") ?? 1;
  }
  resourcesMetadata() {
    return this.botObj.get("resources", "referencelist").map((t) => (J(t), {
      title: K(t),
      context: oe(t)
    }));
  }
  resourcesReadTool() {
    const t = this.botObj.get("resources", "referencelist");
    return {
      name: "read",
      description: "MANDATORY: Read relevant documents before answering questions about topics covered in your knowledge base. Always use this tool first when discussing domain-specific topics.",
      parameters: l.object({
        documentNumbers: l.array(l.number()).describe(
          `Document numbers to read from the document list (1-${t.length}). REQUIRED for domain-specific questions.`
        )
      }),
      explanation: (e) => `Reading ${e.documentNumbers.map((r) => {
        const o = t[r - 1];
        return J(o), K(o);
      }).join(", ")}…`,
      run: async (e) => {
        const r = await N(() => {
          const s = this.botObj.get("resources", "referencelist");
          return e.documentNumbers.map((c) => s[c - 1]).map((c) => {
            J(c);
            const u = c.objData.get();
            if (!u)
              throw new Error(`Object ${c.id()} could not be loaded`);
            return u;
          });
        }), o = await Promise.all(r.map(rt));
        return console.log("bot read", o), o;
      }
    };
  }
}
function K(n) {
  const t = n.get("title", "string");
  if (t) return t;
  const e = n.get("blob", "binary");
  return e instanceof V ? e.original().filename() : "";
}
function oe(n) {
  const t = n.get("tags", "stringlist") || [], e = n.get("description", "string") || n.get("metaDataDescription", "string");
  let r = "";
  t.length && (r += `${t.join(", ")}
`), e && (r += `${e}
`);
  const o = n.get("blob", "binary");
  if (o instanceof V) {
    const s = o.raw().metadata().get("text");
    typeof s == "string" && (r += `${s.slice(0, 300)}
`);
  }
  return r;
}
function J(n) {
  if (n.get === void 0)
    throw new Error("Object unavailable");
}
export {
  he as BotData,
  me as Chatbot,
  nt as createClient,
  rt as formatObj
};
//# sourceMappingURL=index.js.map
