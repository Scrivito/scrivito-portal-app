import { DataClass } from 'scrivito';
import { default as default_2 } from 'openai';
import { Obj } from 'scrivito';
import { ReactNode } from 'react';
import { z } from 'zod';

export declare interface BotConfig {
    name: string;
    systemPrompt: string;
    model?: string;
    temperature?: number;
    useAnonymously?: boolean;
    initialMessages?: default_2.ChatCompletionMessageParam[];
    sites?: Record<string, WebsiteConfig>;
    functions?: FunctionDefinition<unknown>[];
    dataTypes?: Record<string, DataClass>;
    dataTypeToolVersion?: 'v1' | 'v2';
}

export declare class BotData {
    private botObj;
    constructor(botObj: Obj);
    name(): string;
    systemPrompt(): string;
    greeting(): string;
    temperature(): number;
    resourcesMetadata(): {
        title: string;
        context: string;
    }[];
    resourcesReadTool(): FunctionDefinition<unknown>;
    private availableResources;
}

export declare const Chatbot: {
    (props: ChatbotProps): ReactNode;
    displayName?: string | undefined;
};

declare interface ChatbotProps {
    config: BotConfig | null;
    isVisible?: boolean;
    hide?: () => void;
    debugTools?: boolean;
    conversationSharing?: boolean;
    showHistory?: boolean;
    defaultDisplayMode?: DisplayMode;
    inline?: boolean;
}

export declare function createClient({ useAnonymously, }?: {
    useAnonymously?: boolean;
}): default_2;

export declare type DisplayMode = 'floating' | 'overlay';

export declare function formatObj(obj: Record<string, unknown>): Promise<string>;

export declare interface FunctionDefinition<T> {
    name: string;
    description: string;
    parameters: z.ZodType<T>;
    explanation?: (args: T) => string;
    run: (args: T) => Promise<unknown>;
}

declare interface WebsiteConfig {
    instanceId: string;
    baseUrl: string;
    siteId: string;
}

export { }
