import { ChatCompletionMessageParam } from 'openai/resources';
import { DataClass } from 'scrivito';
import { default as default_2 } from 'openai';
import { Obj } from 'scrivito';
import { ReactNode } from 'react';
import { z } from 'zod';

export declare interface BotConfig {
    systemPrompt: string;
    model?: string;
    temperature?: number;
    useAnonymously?: boolean;
    initialMessages?: ChatCompletionMessageParam[];
    sites?: Record<string, WebsiteConfig>;
    tools?: ToolDefinition<unknown>[];
    dataClasses?: DataClass[];
    dataClassToolVersion?: 'v1' | 'v2';
}

export declare class BotData {
    private botObj;
    constructor(botObj: Obj);
    systemPrompt(): string;
    greeting(): string;
    temperature(): number;
    resourcesMetadata(): {
        title: string;
        context: string;
    }[];
    resourcesReadTool(): ToolDefinition<unknown>;
    private availableResources;
}

export declare const Chatbot: {
    (props: ChatbotProps): ReactNode;
    displayName?: string | undefined;
};

declare interface ChatbotProps {
    config: BotConfig | null;
    isVisible?: boolean;
    onHide?: () => void;
    debugTools?: boolean;
    conversationSharing?: boolean;
    showHistory?: boolean;
    defaultDisplayMode?: DisplayMode;
    inline?: boolean;
}

export declare function createClient({ useAnonymously, baseUrl, maxRetries, }?: {
    useAnonymously?: boolean;
    baseUrl?: string;
    maxRetries?: number;
}): default_2;

export declare type DisplayMode = 'floating' | 'overlay';

export declare function formatObj(obj: Record<string, unknown>): Promise<string>;

export declare interface ToolDefinition<T> {
    name: string;
    description: string;
    parameters: z.ZodType<T>;
    explanation?: (args: T) => string;
    run: (args: T) => Promise<unknown>;
}

declare interface WebsiteConfig {
    instanceId: string;
    baseUrl: string;
    siteId: string;
}

export { }
